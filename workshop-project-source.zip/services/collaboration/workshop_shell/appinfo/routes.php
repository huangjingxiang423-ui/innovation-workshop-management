<?php
return ['routes'=>[['name'=>'identity#confirmProject','url'=>'/project-confirm','verb'=>'GET'],['name'=>'identity#show','url'=>'/identity','verb'=>'GET']]];
