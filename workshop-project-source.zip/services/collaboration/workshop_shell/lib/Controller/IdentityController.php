<?php
namespace OCA\WorkshopShell\Controller;
use OCP\AppFramework\Controller;
use OCP\AppFramework\Http\JSONResponse;
use OCP\AppFramework\Http\Attribute\NoAdminRequired;
use OCP\AppFramework\Http\Attribute\NoCSRFRequired;
use OCP\IRequest;
use OCP\IUserSession;
use OCP\IConfig;
/** Authenticated same-origin identity check; never grants or changes access. */
class IdentityController extends Controller
{
    public function __construct(IRequest $request, private IUserSession $session, private IConfig $config){parent::__construct('workshop_shell',$request);}
    #[NoAdminRequired]
    #[NoCSRFRequired]
    public function confirmProject(int $project=0): \OCP\AppFramework\Http\Response
    {
        $user=$this->session->getUser();
        if(!$user||!\OCP\Server::get(\OCP\IGroupManager::class)->isAdmin($user->getUID()))return new JSONResponse([],403);
        if($project<1||$project>2147483647)return new JSONResponse([],400);
        \OCP\Util::addScript('workshop_shell','project-confirm');
        $response=new \OCP\AppFramework\Http\TemplateResponse('workshop_shell','project-confirm',['project'=>$project]);
        $response->addHeader('Cache-Control','no-store');return $response;
    }
    #[NoAdminRequired]
    #[NoCSRFRequired]
    public function show(): JSONResponse
    {
        $user=$this->session->getUser();
        if (!$user) return new JSONResponse([],401,['Cache-Control'=>'no-store']);
        $ids=\OCP\Server::get(\OCA\Theming\Service\ThemesService::class)->getEnabledThemes();
        $mode=in_array('dark',$ids,true)||in_array('dark-highcontrast',$ids,true)?'dark':(in_array('light',$ids,true)||in_array('light-highcontrast',$ids,true)?'light':'system');
        $primary=$this->config->getUserValue($user->getUID(),'theming','primary_color',$this->config->getAppValue('theming','color','#13815f'));
        return new JSONResponse(['email'=>$user->getEMailAddress(),'uid'=>$user->getUID(),'display_name'=>$user->getDisplayName(),'account_administration'=>\OCP\Server::get(\OCP\IGroupManager::class)->isAdmin($user->getUID()),'invitation_mail_ready'=>$this->config->getSystemValue('mail_smtpmode','')==='smtp'&&$this->config->getSystemValue('mail_smtphost','')!==''&&$this->config->getSystemValue('mail_from_address','')!==''&&$this->config->getSystemValue('mail_domain','')!==''&&\OCP\Server::get(\OCP\IAppConfig::class)->getValueBool('core','newUser.sendEmail',true),'avatar_version'=>(int)$this->config->getUserValue($user->getUID(),'avatar','version','0'),'avatar_url'=>'/avatar/'.rawurlencode($user->getUID()).'/64','appearance'=>[
            'theme'=>$mode,'reduce_motion'=>in_array('reduced-motion',$ids,true),
            'contrast'=>in_array('dark-highcontrast',$ids,true)||in_array('light-highcontrast',$ids,true),
            'dyslexia'=>in_array('opendyslexic',$ids,true),
            'primary'=>preg_match('/^#[0-9a-fA-F]{6}$/',$primary)?$primary:'#13815f',
        ]],200,['Cache-Control'=>'no-store']);
    }
}
