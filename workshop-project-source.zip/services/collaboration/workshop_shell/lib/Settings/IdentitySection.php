<?php
namespace OCA\WorkshopShell\Settings;
final class IdentitySection extends PersonalSection {
 protected string $section = 'workshop-identity';
 protected string $title = '工坊身份与管理';
 protected int $priority = 13;
}
