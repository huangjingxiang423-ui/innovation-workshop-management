<?php
namespace OCA\WorkshopShell\Settings;
final class About extends Personal {
 protected string $section = 'workshop-about';
 protected string $area = 'about';
 protected string $title = '关于工坊';
}
