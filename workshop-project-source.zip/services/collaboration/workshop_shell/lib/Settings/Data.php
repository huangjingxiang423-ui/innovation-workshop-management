<?php
namespace OCA\WorkshopShell\Settings;
final class Data extends Personal {
 protected string $section = 'workshop-data';
 protected string $area = 'data';
 protected string $title = '数据与导出';
}
