<?php
namespace OCA\WorkshopShell\Settings;
final class AboutSection extends PersonalSection {
 protected string $section = 'workshop-about';
 protected string $title = '关于工坊';
 protected int $priority = 95;
}
