<?php
namespace OCA\WorkshopShell\Settings;
use OCP\Settings\IIconSection;
use OCP\IURLGenerator;
class PersonalSection implements IIconSection {
 public function __construct(private IURLGenerator $urlGenerator) {}
 protected string $section = 'workshop';
 protected string $title = '外观与交互';
 protected int $priority = 12;
 public function getID() { return $this->section; }
 public function getName() { return $this->title; }
 public function getPriority() { return $this->priority; }
 public function getIcon() { return $this->urlGenerator->imagePath('settings','admin.svg'); }
}
