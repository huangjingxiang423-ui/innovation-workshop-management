<?php
namespace OCA\WorkshopShell\Settings;
use OCP\Settings\ISettings;
use OCP\AppFramework\Http\TemplateResponse;
class Personal implements ISettings {
 protected string $section = 'workshop';
 protected string $area = 'appearance';
 protected string $title = '外观与交互';
 public function getForm() { return new TemplateResponse('workshop_shell','personal',['area'=>$this->area,'title'=>$this->title]); }
 public function getSection() { return $this->section; }
 public function getPriority() { return 10; }
}
