<?php
namespace OCA\WorkshopShell\Settings;
final class DataSection extends PersonalSection {
 protected string $section = 'workshop-data';
 protected string $title = '数据与导出';
 protected int $priority = 18;
}
