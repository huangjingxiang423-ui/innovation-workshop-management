<?php
namespace OCA\WorkshopShell\Settings;
final class Identity extends Personal {
 protected string $section = 'workshop-identity';
 protected string $area = 'identity';
 protected string $title = '工坊身份与管理';
}
