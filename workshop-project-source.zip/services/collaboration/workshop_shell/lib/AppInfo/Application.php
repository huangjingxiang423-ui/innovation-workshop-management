<?php
namespace OCA\WorkshopShell\AppInfo;
use OCP\AppFramework\App;
use OCP\AppFramework\Bootstrap\IBootstrap;
use OCP\AppFramework\Bootstrap\IRegistrationContext;
use OCP\AppFramework\Bootstrap\IBootContext;
class Application extends App implements IBootstrap
{
    public function __construct(){parent::__construct('workshop_shell');}
    public function register(IRegistrationContext $context): void {}
    public function boot(IBootContext $context): void
    {
        \OCP\Util::addHeader('script', ['src' => '/manage/workshop-assets/appearance-seed.js?v=shell-d29a2ca236b6'], '');
        \OCP\Util::addStyle('workshop_shell','shell-6a53c47c9d42');
        \OCP\Util::addScript('workshop_shell','shell-6a53c47c9d42');
    }
}
