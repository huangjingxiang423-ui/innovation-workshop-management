<?php /** Reuses the native password confirmation dialog; no password is handled by workshop code. */ ?>
<section class="section" id="workshop-project-confirm" data-project="<?php p((int)$_['project']); ?>">
 <h2>确认项目空间建置</h2>
 <p>创建项目聊天与共享资料需要管理员维护确认。密码只交给现有账号服务校验，工坊管理程序不接收或保存密码。</p>
 <button id="workshop-confirm-maintenance" class="primary">确认维护操作</button>
 <a href="/manage/workshop?view=projects&amp;project=<?php p((int)$_['project']); ?>">返回项目</a>
 <p role="status" id="workshop-confirm-status"></p>
</section>
