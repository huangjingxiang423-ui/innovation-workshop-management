<?php
/** Workshop settings are registered in the native settings tree. */
?>
<div id="workshop-unified-settings" class="section" data-area="<?php p($_['area']); ?>" aria-busy="true">
 <h2><?php p($_['title']); ?></h2>
 <p class="workshop-settings-status" role="status">正在读取设置…</p>
</div>
