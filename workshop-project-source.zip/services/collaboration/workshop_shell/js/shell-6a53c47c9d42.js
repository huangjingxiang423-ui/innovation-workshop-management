/* Shared navigation metadata. Presentation only; all services retain server authorization. */
(()=>{'use strict';const config={"groups":[{"id":"overview","label":"工坊总览","icon":"overview","items":[["overview","工坊总览"]]},{"id":"messages","label":"消息","icon":"chat","native":true,"items":[["chat","项目聊天"]]},{"id":"work","label":"任务","icon":"tasks","items":[["mine","我的任务"],["tasks","项目任务"],["reviews","待验收成果"],["timeline","任务日历"]]},{"id":"projects","label":"项目","icon":"projects","items":[["projects","项目列表"],["meetings","组会记录"]]},{"id":"resources","label":"资料与知识","icon":"files","items":[["files","共享资料"]]},{"id":"affairs","label":"工坊事务","icon":"reviews","items":[["attendance","考勤"],["equipment","设备预约 · 试用"]]},{"id":"administration","label":"管理","icon":"people","manager":true,"items":[["people","人员与权限"],["configuration","工坊配置"]]}],"icons":{"chat":"<path d=\"M21 11.5a8.5 8.5 0 0 1-8.5 8.5H4l-2 2v-10.5a8.5 8.5 0 1 1 19 0Z\"/><path d=\"M7 10h9M7 14h6\"/>","files":"<path d=\"M3 6h7l2 2h9v13H3Z\"/><path d=\"M3 6V3h7l2 3\"/>","meetings":"<rect x=\"3\" y=\"4\" width=\"18\" height=\"17\" rx=\"2\"/><path d=\"M7 2v4M17 2v4M3 9h18M7 13h10M7 17h7\"/>","timeline":"<path d=\"M5 3v18M9 6h10M9 12h7M9 18h12\"/>","projects":"<rect x=\"3\" y=\"4\" width=\"18\" height=\"17\" rx=\"2\"/><path d=\"M7 4V2M17 4V2M3 9h18\"/>","settings":"<path d=\"m9 3-1 3-3 1v4l-2 1 2 3v3l4 1 3 2 3-2 4-1v-3l2-3-2-1V7l-3-1-1-3Z\"/><circle cx=\"12\" cy=\"12\" r=\"3\"/>","overview":"<rect x=\"3\" y=\"3\" width=\"7\" height=\"7\" rx=\"1\"/><rect x=\"14\" y=\"3\" width=\"7\" height=\"7\" rx=\"1\"/><rect x=\"3\" y=\"14\" width=\"7\" height=\"7\" rx=\"1\"/><rect x=\"14\" y=\"14\" width=\"7\" height=\"7\" rx=\"1\"/>","tasks":"<rect x=\"4\" y=\"4\" width=\"16\" height=\"17\" rx=\"2\"/><path d=\"M9 4V2h6v2M8 10h8M8 14h8M8 18h5\"/>","reviews":"<circle cx=\"12\" cy=\"12\" r=\"9\"/><path d=\"m8 12 3 3 5-6\"/>","people":"<circle cx=\"9\" cy=\"8\" r=\"3\"/><path d=\"M3 21v-3a6 6 0 0 1 12 0v3M16 5a3 3 0 0 1 0 6M21 21v-3a6 6 0 0 0-4-5\"/>"}};
const nativePaths={chat:'/apps/spreed/',meetings:'/apps/collectives/',files:'/apps/files/',configuration:'/settings/user/workshop-identity'};
const groups=(actor={},native=true)=>config.groups.filter(g=>(!g.manager||actor.owner||['manager','teacher'].includes(actor.role))&&(!g.native||native)).map(g=>({...g,items:g.items.filter(([k])=>!(config.hidden_items||[]).includes(k)&&(k!=='equipment'||actor.owner)&&(!['chat','meetings','files','configuration'].includes(k)||native))})).filter(g=>g.items.length);
const groupFor=key=>config.groups.find(g=>g.items.some(([k])=>k===key));
const href=(key,base='/manage')=>key==='equipment'?'http://127.0.0.1:18768/Web/schedule.php':nativePaths[key]||base+'/workshop?view='+key;
const svg=key=>'<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(config.icons[key]||config.icons.tasks)+'</svg>';
window.WorkshopNavigation=Object.freeze({groups,groupFor,href,svg,nativePaths});window.dispatchEvent(new Event("workshop-navigation-ready"));
})();

/* Presentation-only integration. Cookie contains display preferences, never identity or authorization. */
(()=>{
 let prefs={};try{prefs=JSON.parse(decodeURIComponent(document.cookie.split('; ').find(x=>x.startsWith('workshop_ui='))?.slice(12)||'{}'));}catch{}
 let mode=['dark','light','system'].includes(prefs.theme)?prefs.theme:'system';
 let themeTimer,lastDisplayCookie;
 function startThemeTransition(){
  if(document.documentElement.dataset.workshopReducedMotion==='true'||matchMedia('(prefers-reduced-motion:reduce)').matches)return;
  document.documentElement.classList.add('workshop-theme-transition');clearTimeout(themeTimer);
  themeTimer=setTimeout(()=>document.documentElement.classList.remove('workshop-theme-transition'),850);
 }
 function theme(){
  const body=document.body;if(!body)return;body.dataset.workshopNativeAppearance='true';
  const ids=(body.dataset.themes||'default').split(/[,\s]+/);
  mode=ids.some(id=>['dark','dark-highcontrast'].includes(id))?'dark':ids.some(id=>['light','light-highcontrast'].includes(id))?'light':'system';
  const html=document.documentElement;html.dataset.theme=html.dataset.workshopTheme=mode==='system'?(matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light'):mode;
  html.dataset.reduceMotion=html.dataset.workshopReducedMotion=String(ids.includes('reduced-motion'));
  html.dataset.contrast=html.dataset.workshopContrast=String(ids.includes('dark-highcontrast')||ids.includes('light-highcontrast'));
  prefs={...prefs,theme:mode,reduce_motion:ids.includes('reduced-motion'),contrast:html.dataset.workshopContrast==='true',dyslexia:ids.includes('opendyslexic')};
  if(typeof name!=='undefined'){const value=encodeURIComponent(JSON.stringify({...prefs,name}));if(value!==lastDisplayCookie){document.cookie='workshop_ui='+value+'; Path=/; SameSite=Lax; Max-Age=2592000';lastDisplayCookie=value;}}
 }
 let name=typeof prefs.name==='string'?prefs.name.slice(0,40):'创新工坊';
 matchMedia('(prefers-color-scheme:dark)').addEventListener('change',()=>{startThemeTransition();theme();});
 document.addEventListener('click',e=>{if(location.pathname==='/settings/user/theming'&&e.target.closest('label,input,button,[role=radio],[role=checkbox]'))startThemeTransition();},true);
 document.addEventListener('DOMContentLoaded',()=>{theme();new MutationObserver(theme).observe(document.body,{attributes:true,attributeFilter:['data-themes','data-theme-dark','data-theme-light']});});
 const escape=value=>String(value??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let coreContext;
 let identityContextPromise;
 async function coreSettingsContext(refresh=false){
  if(refresh)identityContextPromise=null;
  if(!identityContextPromise)identityContextPromise=(async()=>{
   const [coreResponse,nativeResponse]=await Promise.all([
    fetch('/manage/workshop/settings-context',{credentials:'same-origin',redirect:'error',signal:AbortSignal.timeout(10000),headers:{Accept:'application/json'}}),
    fetch('/index.php/apps/workshop_shell/identity',{credentials:'same-origin',redirect:'error',signal:AbortSignal.timeout(5000),headers:{Accept:'application/json'}})
   ]);
   if(!coreResponse.ok||!nativeResponse.ok)throw new Error('请先从工坊统一登录进入，再管理账号设置。');
   const data=await coreResponse.json(),native=await nativeResponse.json();
   if(!native.email||native.email.toLowerCase()!==data.actor.email.toLowerCase()||!data.csrf_token)throw new Error('当前登录身份未确认，请退出后统一登录。');
   return {data,token:data.csrf_token,native};
  })().catch(error=>{identityContextPromise=null;throw error;});
  return identityContextPromise;
 }
 async function saveCore(action,data,key=crypto.randomUUID()){
  if(!coreContext)throw new Error('设置尚未加载，请稍后重试。');
  const response=await fetch('/manage/workshop/action',{method:'POST',credentials:'same-origin',redirect:'error',signal:AbortSignal.timeout(20000),headers:{'Content-Type':'application/json','Accept':'application/json','X-Requested-With':'XMLHttpRequest','X-CSRF-TOKEN':coreContext.token,'Idempotency-Key':key},body:JSON.stringify({action,data})});
  const body=await response.json();if(!response.ok)throw new Error(body.error||'保存失败，请重试。');return body;
 }
 async function initWorkshopSettings(){
  const el=document.querySelector('#workshop-unified-settings');if(!el||el.dataset.initialized)return;el.dataset.initialized='true';
  try{
   coreContext=await coreSettingsContext();const {data}=coreContext,p=data.workspace.preferences||{};
   const row=(label,value)=>`<div class="workshop-setting-row"><span>${label}</span><strong>${escape(value)}</strong></div>`;
   const area=el.dataset.area||'identity';
   const titles={identity:'工坊身份与管理',data:'数据与导出',about:'关于工坊'};
   const sections={
    identity:`<section class="workshop-setting-block"><h3>工坊身份</h3>${row('姓名',data.actor.name)}${row('邮箱',data.actor.email)}${row('学员编号',data.actor.student_no||'维护管理员')}${row('工坊角色',({member:'普通成员',manager:'总负责人',teacher:'指导老师'})[data.actor.role])}<p>姓名和工坊身份以管理员审核记录为准。</p></section><section class="workshop-setting-block"><h3>项目角色</h3>${data.project_roles.map(m=>row(m.name,m.role==='leader'?'项目组长':'项目组员')).join('')||(data.manager?'<p>你按工坊管理角色查看和管理全部项目，不需要重复加入每个项目。</p>':'<p>尚未分配具体项目。</p>')}<p>各项目分别授权，同一个人在不同项目可以担任不同角色。</p></section>
    ${data.manager?`<section class="workshop-setting-block"><h3>工坊管理</h3><form id="workshop-name-form"><label>工坊名称<input name="name" required maxlength="40" value="${escape(data.workspace.name)}"></label><button type="submit">保存名称</button><p role="status"></p></form><a class="workshop-setting-action" href="/manage/workshop/open/people">人员与项目权限</a></section>`:''}
    `,
    data:`<section class="workshop-setting-block"><h3>数据与导出</h3><p>导出你有权访问的项目任务，不包含附件，也不能代替系统备份。</p><a class="workshop-setting-action" href="/manage/workshop/export">导出任务 CSV</a></section>
    `,
    about:`<p>创新工坊 · 整合试用版。</p><p>用于项目、任务、成果、消息与共享资料管理。</p><h3>运行情况</h3><p>当前为本机试用环境，尚未开放校外访问。已完成本机联合数据备份与隔离恢复核对；正式部署仍需验证恢复后应用启动、实际邮件送达和跨系统权限同步。</p><details class="workshop-license"><summary>开源组件、源代码与许可</summary><p>本平台基于开源软件集成，原作者和各组件许可证保留。</p><ul><li><a href="https://github.com/nextcloud/server" target="_blank" rel="noopener noreferrer">Nextcloud 源代码</a> · <a href="https://www.gnu.org/licenses/agpl-3.0.html" target="_blank" rel="noopener noreferrer">AGPL</a></li><li><a href="https://github.com/nextcloud/spreed" target="_blank" rel="noopener noreferrer">Talk 源代码</a></li><li><a href="https://github.com/Leantime/leantime" target="_blank" rel="noopener noreferrer">Leantime 源代码</a></li><li>项目日历：tui-calendar-hi（MIT），来源与许可随源码保留。</li></ul></details>`
   };
   el.innerHTML='<h2>'+titles[area]+'</h2>'+(sections[area]||sections.identity);
   const nameForm=el.querySelector('#workshop-name-form');if(nameForm)nameForm.addEventListener('submit',async e=>{e.preventDefault();const button=nameForm.querySelector('button'),status=nameForm.querySelector('[role=status]');button.disabled=true;try{const result=await saveCore('workspace_settings',{name:nameForm.elements.name.value.trim(),revision:coreContext.data.workspace.revision});coreContext=await coreSettingsContext(true);name=coreContext.data.workspace.name;document.querySelectorAll('.workshop-brand>span:last-child').forEach(e=>{e.firstChild.textContent=name;});document.querySelectorAll('.workshop-module-heading small').forEach(e=>{e.textContent=name+' / 工作空间';});theme();status.textContent='名称已保存';}catch(error){status.textContent=error.message;}finally{button.disabled=false;}});
   el.setAttribute('aria-busy','false');
  }catch(error){el.innerHTML='<h2>工坊设置</h2><p role="alert">'+escape(error instanceof TypeError?'工坊会话已失效或连接中断，请返回统一登录后重试。':error.message)+'</p><a class="workshop-setting-action" href="/manage/workshop/open/overview">返回工坊统一登录</a>';el.setAttribute('aria-busy','false');}
 }
 function trimNativeAppearance(){
  const panel=document.getElementById('settings-personal-theming');if(!panel)return;
  // Keep the native theme, contrast, reduced-motion and primary-color controls.
  // Background blur, wallpaper and native app-order controls do not drive this fixed workshop shell.
  panel.querySelectorAll('a[href*="nextcloud.com"],a[href*="github.com/nextcloud/server/issues"]').forEach(a=>{const row=a.closest('p');if(row)row.hidden=true;});
  panel.querySelectorAll('h2,h3').forEach(h=>{
   if(['背景与颜色','导航栏设置','其他辅助功能选项'].includes(h.textContent.trim())){
    h.hidden=true;let next=h.nextElementSibling;while(next&&!['H2','H3'].includes(next.tagName)){next.hidden=true;next=next.nextElementSibling;}
   }
  });
 }
 let workshopAccount=null;
 async function loadWorkshopAccount(){
  try{const {data,native}=await coreSettingsContext();workshopAccount=data;workshopAccount.native_uid=native.uid;name=data.workspace.name;mount();}catch{/* Display adapts only after both authenticated identities match. */}
 }
 function unifyAccount(){
  const setText=(el,value)=>{if(el&&el.textContent!==value)el.textContent=value;};
  if(workshopAccount){
   document.querySelectorAll('.workshop-brand>span:last-child').forEach(el=>{if(el.firstChild?.nodeValue!==name)el.firstChild.nodeValue=name;});
   document.querySelectorAll('.workshop-module-heading small').forEach(el=>setText(el,name+' / 工作空间'));
   setText(document.querySelector('#user-menu a#profile .list-item-content__name'),workshopAccount.actor.name);
   const profile=document.querySelector('#user-menu a#profile .list-item-content__main');if(profile){let role=profile.querySelector('.workshop-account-role');if(!role){role=document.createElement('small');role.className='workshop-account-role';profile.append(role);}setText(role,({manager:'总负责人',teacher:'指导老师'})[workshopAccount.actor.role]||(workshopAccount.project_roles.some(m=>m.role==='leader')?'项目组长（按项目授权）':'项目组员'));}
   const desc=document.querySelector('#user-menu .header-menu__description');setText(desc,workshopAccount.actor.name+' 的头像');
   // The dashboard greeting is app chrome; project membership names remain authoritative.
   if(location.pathname.startsWith('/apps/spreed')){const greeting=document.querySelector('h2.talk-dashboard__header');if(greeting?.textContent.startsWith('您好，'))setText(greeting,'您好，'+workshopAccount.actor.name);}
  }
  const labels={accessibility_settings:'外观和辅助功能',settings_personal:'设置',logout:'退出登录'};
  for(const [id,label] of Object.entries(labels))setText(document.querySelector('#user-menu a#'+id+' .list-item-content__name'),label);
  const settings=document.querySelector('#user-menu a#settings_personal');if(settings&&settings.getAttribute('href')!=='/settings/user/workshop-identity')settings.setAttribute('href','/settings/user/workshop-identity');
  const profileRow=document.querySelector('#user-menu a#profile')?.closest('li');if(profileRow?.hidden)profileRow.hidden=false;
  document.querySelectorAll('#user-menu a[href="#"]:not(#profile)').forEach(a=>{const li=a.closest('li');if(li)li.hidden=true;});
 }
 function trimPrivacy(){
  if(location.pathname!=='/settings/user/privacy')return;
  const mission=document.querySelector('#privacy-mission p');const text='本平台用于工坊项目协作。资料访问取决于你的项目授权和共享设置；管理员的实际访问范围、文件保护与部署位置请查看下方信息。';if(mission&&mission.textContent!==text)mission.textContent=text;
  if(workshopAccount)document.querySelectorAll('#privacy-access span').forEach(el=>{if(!el.children.length&&el.textContent===workshopAccount.native_uid)el.textContent=workshopAccount.actor.name;});
  const manifesto=document.querySelector('#privacy-manifesto');if(manifesto)manifesto.hidden=true;
 }
 window.addEventListener("workshop-navigation-ready",()=>mount());
 function groupedNavigation(){
  const sidebar=document.querySelector('#side-menu'),n=window.WorkshopNavigation;if(!sidebar||!n)return;
  const path=location.pathname;
  const key=path.startsWith('/call/')||path.includes('/spreed')?'chat':path.includes('/files')?'files':path.includes('/collectives')?'meetings':path==='/settings/user/workshop-identity'?'configuration':null;
  const actor=workshopAccount?.actor||{};
  // Unknown roles show no administrative link; backend authorization remains authoritative.
  const groups=n.groups(actor),active=n.groupFor(key);
  const signature=JSON.stringify([actor.id,actor.role,actor.owner,key]);
  let nav=sidebar.querySelector('.workshop-primary-navigation');
  if(!nav){nav=document.createElement('nav');nav.className='workshop-primary-navigation';nav.setAttribute('aria-label','主导航');sidebar.append(nav);}
  const link=(k,label,primary,g)=>`<a data-workshop-group="${escape(g.id)}" aria-label="${escape(label)}" href="${escape(n.href(k))}" class="${primary?'workshop-primary-link':'workshop-section-tab'}${(primary?active?.id===g.id:key===k)?' selected':''}" ${(primary?active?.id===g.id:key===k)?'aria-current="page"':''} ${k==='equipment'?'target="_blank" rel="noopener" title="独立试用环境，尚未统一账号"':''}>${primary?n.svg(g.icon):''}<span>${label}</span>${k==='equipment'?'<span aria-hidden="true">↗</span>':''}</a>`;
  if(nav.dataset.signature!==signature){
   // Preserve anchors while identity resolves: replacing innerHTML can detach the
   // pressed link between pointerdown and click, swallowing the first navigation.
   const wanted=new Set(groups.map(g=>g.id));
   nav.querySelectorAll('a[data-workshop-group]').forEach(a=>{if(!wanted.has(a.dataset.workshopGroup))a.remove();});
   groups.forEach((g,index)=>{let anchor=Array.from(nav.children).find(a=>a.dataset.workshopGroup===g.id);const selected=active?.id===g.id;
    if(!anchor){const template=document.createElement('template');template.innerHTML=link(g.items[0][0],g.label,true,g);anchor=template.content.firstElementChild;nav.insertBefore(anchor,nav.children[index]||null);}
    else{anchor.classList.toggle('selected',selected);if(selected)anchor.setAttribute('aria-current','page');else anchor.removeAttribute('aria-current');if(nav.children[index]!==anchor)nav.insertBefore(anchor,nav.children[index]||null);}
   });nav.dataset.signature=signature;
  }
  sidebar.classList.add('workshop-grouped');
  const header=document.querySelector('#header');if(!header)return;
  let tabs=header.querySelector('.workshop-section-navigation');
  const group=groups.find(g=>g.id===active?.id);
  if(group&&group.items.length>1){if(!tabs){tabs=document.createElement('nav');tabs.className='workshop-section-navigation';tabs.setAttribute('aria-label',group.label+'分类');header.append(tabs);}const html=group.items.map(([k,label])=>link(k,label,false,group)).join('');if(tabs.dataset.signature!==signature){if(tabs.dataset.content!==html){tabs.innerHTML=html;tabs.dataset.content=html;}tabs.dataset.signature=signature;}}
  else if(tabs)tabs.remove();
 }
 let meetingTitleObserved=false;
 function meetingGuide(){
  if(!location.pathname.startsWith('/apps/collectives/'))return;
  const title=document.querySelector('title');
  if(title&&!meetingTitleObserved){meetingTitleObserved=true;const normalize=()=>{const value=document.title.replace(/知识库/g,'组会记录').replace(/Nextcloud/g,name);if(value!==document.title)document.title=value;};new MutationObserver(normalize).observe(title,{childList:true,subtree:true,characterData:true});normalize();}
  const header=document.querySelector('#header');if(!header||header.querySelector('.workshop-meeting-guide'))return;
  const guide=document.createElement('details');guide.className='workshop-meeting-guide';
  guide.innerHTML='<summary>组会使用说明 · 转任务</summary><div class="workshop-meeting-help-body"><h2>记录与落实组会</h2><ol><li>在已有空间打开具体会议页，填写日期、主持人、参会人、成果、问题、会议决定与下周安排，留意编辑器保存状态。</li><li>共享前核对空间成员与原有权限；保存文档不会自动公开或正式发布会议。</li><li>先查看本页已关联任务；已有任务可搜索后关联，确需新建时再填写项目、责任人、截止时间和验收要求。</li><li>任务按项目分别授权；关联只保存来源链接，不会改变会议或任务的访问权限。</li></ol><div class="workshop-meeting-actions"><button type="button" data-meeting-mode="manage">关联或新建任务</button><button type="button" data-meeting-mode="linked">查看本页已关联任务</button></div><p class="workshop-meeting-action-status" role="status"></p><p class="workshop-meeting-limits">正式发布、修订审核与自动提取待办尚未接通。</p></div>';
  guide.addEventListener('click',event=>{
   const button=event.target.closest('[data-meeting-mode]');if(!button)return;
   const current=new URL(location.href),path=current.pathname,status=guide.querySelector('[role="status"]');
   if(path==='/apps/collectives/'||path==='/apps/collectives'){status.textContent='请先打开具体的组会页面，再使用此入口。';return;}
   const file=current.searchParams.get('fileId'),source=path+(file&&/^[1-9][0-9]{0,18}$/.test(file)?'?fileId='+file:'');
   const query=new URLSearchParams({view:'tasks',meeting_source:source});
   if(button.dataset.meetingMode==='linked')query.set('filter','meeting');
   location.assign('/manage/workshop?'+query);
  });
  guide.addEventListener('keydown',event=>{if(event.key==='Escape'){guide.open=false;guide.querySelector('summary').focus();}});
  document.addEventListener('click',event=>{if(guide.open&&!guide.contains(event.target))guide.open=false;});
  header.append(guide);
 }
 function mount(){
  theme();groupedNavigation();meetingGuide();
  if(location.pathname.includes('/collectives')){const title=document.title.replace(/知识库/g,'组会记录').replace(/Nextcloud/g,name);if(title!==document.title)document.title=title;}
  if(location.pathname==='/settings/user/workshop'){location.replace('/settings/user/workshop-identity');return;}
  trimNativeAppearance();trimPrivacy();unifyAccount();
  if(document.body.id==='body-login'){
   const error=document.querySelector('.guest-content,.guest-box,#body-login');
   if(error?.textContent.includes('Authorization session expired.')&&!document.querySelector('.workshop-restart-login')){const link=document.createElement('a');link.className='button workshop-restart-login';link.href='/manage/auth/login';link.textContent='登录请求已过期，请重新开始统一登录';error.append(link);}
   const title=document.querySelector('#oidc-logout-confirmation-title');if(title&&title.textContent!=='确认退出工坊账号')title.textContent='确认退出工坊账号';const intro=document.querySelector('#oidc-logout-confirmation p');if(intro&&intro.textContent!=='确认后将退出聊天和资料登录，并返回工坊登录页。')intro.textContent='确认后将退出聊天和资料登录，并返回工坊登录页。';return;}
  if(!['body-user','body-settings'].includes(document.body.id))return;
  const sidebar=document.querySelector('#side-menu');
  if(sidebar&&!sidebar.querySelector('.workshop-brand')){
   const a=document.createElement('a');a.className='workshop-brand';a.href='/manage/workshop/open/overview';
   const mark=document.createElement('span');mark.className='workshop-mark';mark.textContent='W';
   const text=document.createElement('span');text.textContent=name;
   const small=document.createElement('small');small.textContent='创新 · 协作 · 实践';text.append(small);a.append(mark,text);sidebar.prepend(a);
  }
  const header=document.querySelector('#header');
  if(header&&!header.querySelector('.workshop-module-heading')){
   const node=document.createElement('div');node.className='workshop-module-heading';
   const crumb=document.createElement('small');crumb.textContent=name+' / 工作空间';
   const h=document.createElement('h1');h.textContent=location.pathname.startsWith('/call/')||location.pathname.includes('/spreed')?'项目聊天':location.pathname.includes('/files')?'资料与知识库':location.pathname.includes('/collectives')?'组会记录':location.pathname.includes('/oidc/')?'账号授权':'设置';
   node.append(crumb,h);header.prepend(node);
  }
  if(document.body.id==='body-settings'){
   const heading=document.querySelector('#settings-personal_section_heading');if(heading&&heading.textContent!=='个人设置')heading.textContent='个人设置';
   // Remove the retired return shortcuts: settings now live entirely in this native center.
   document.querySelectorAll('.workshop-settings-shortcuts').forEach(e=>e.remove());
   const keep=['profile-contact','language-locale','security','notifications','theming','workshop-identity','workshop-data','workshop-about','sharing','availability','privacy'];
   document.querySelectorAll('#content-vue a[href^="/settings/user/"]').forEach(a=>{
    const key=new URL(a.href).pathname.split('/').pop();const li=a.closest('li');if(li)li.hidden=!keep.includes(key);
   });
   // Server administration is maintenance, not a second workshop settings center.
   document.querySelectorAll('#content-vue a[href^="/settings/admin/"]').forEach(a=>{const li=a.closest('li');if(li)li.hidden=true;});
   const adminHeading=document.querySelector('#settings-admin_section_heading');if(adminHeading){adminHeading.hidden=true;if(adminHeading.nextElementSibling)adminHeading.nextElementSibling.hidden=true;}
   initWorkshopSettings();
   for(const id of ['calendar_notification','contacts_notification','calendar_event_notification','calendar_todo_notification','remote_share_notification','public_links_notification','public_links_upload_notification','circles_as_member_notification','circles_as_moderator_notification','circles_as_non_member_notification']){
    const row=document.getElementById(id)?.closest('tr');if(row)row.hidden=true;
   }
   document.querySelectorAll('#activity-user-settings tr').forEach(row=>{if(row.textContent.includes('日历、联系人和任务'))row.hidden=true;});
  }
  if(location.pathname==='/settings/user/profile-contact'){
   document.querySelectorAll('#app-content-vue a[href^="/u/"],#app-content-vue a[href="/settings/user/profile"]').forEach(a=>{const row=a.closest('.field')||a;row.hidden=true;});
  }
  document.querySelectorAll('.development-notice').forEach(node=>{
   if(node.dataset.workshopTrimmed)return;node.dataset.workshopTrimmed='true';
   node.innerHTML='<details class="workshop-license"><summary>开源组件说明</summary><p>本系统使用 Nextcloud 开源组件。<a href="https://github.com/nextcloud/server" target="_blank" rel="noopener noreferrer">源代码</a>基于<a href="https://www.gnu.org/licenses/agpl-3.0.html" target="_blank" rel="noopener noreferrer">AGPL</a>许可。原作者署名与许可证随源码保留。</p><a href="/settings/user/workshop-about">查看全部组件信息</a></details>';
  });
  document.querySelectorAll('#app-content-vue button,#app-content-vue button span').forEach(e=>{if(e.children.length===0&&e.textContent.trim()==='从 Nextcloud 文件中选择')e.textContent='从工坊文件中选择';});
  // Settings and avatar are two entrances to one settings tree, never two products.
  document.querySelectorAll('#user-menu a[href],#side-menu a[href]').forEach(a=>{
   const u=new URL(a.href,location.origin);
   if(u.pathname.includes('/workshop/open/settings')||u.pathname==='/settings/user'||u.pathname==='/settings/user/'||(a.closest('#side-menu')&&u.pathname==='/settings/user/theming'))a.setAttribute('href','/settings/user/workshop-identity');
  });
  document.querySelectorAll('#user-menu #accessibility_settings').forEach(a=>{if(a.getAttribute('href')!=='/settings/user/theming')a.setAttribute('href','/settings/user/theming');});
  document.querySelectorAll('#user-menu #profile').forEach(a=>{if(a.getAttribute('href')!=='/settings/user/profile-contact')a.setAttribute('href','/settings/user/profile-contact');});
  document.querySelectorAll('#user-menu button[aria-label*="QR code"]').forEach(b=>b.hidden=true);
  document.querySelectorAll('#user-menu a[href]').forEach(a=>{
   const u=new URL(a.href,location.origin);
   if(u.pathname.startsWith('/settings/admin')||['/settings/apps','/settings/users','/settings/help'].includes(u.pathname)||u.hostname.endsWith('nextcloud.com')||u.hostname.endsWith('nextcloud.org')){
    const row=a.closest('li')||a;row.hidden=true;
   }
  });
  document.querySelectorAll('#side-menu .cm-app a').forEach(a=>{
   const path=new URL(a.href,location.origin).pathname;
   let key=path.startsWith('/settings/')?'settings':path.includes('/spreed')?'chat':path.includes('/files')?'files':path.includes('/collectives')?'meetings':path.split('/').pop();
   if(['overview','mine','projects','tasks','timeline','reviews','people','settings','chat','files','meetings','knowledge','attendance'].includes(key))a.dataset.workshopNav=key;
   if(key==='timeline'){if(a.title!=='项目日历')a.title='项目日历';const label=a.querySelector('.cm-app-text');if(label&&label.textContent!=='项目日历')label.textContent='项目日历';}
   if(key==='meetings'){if(a.title!=='组会记录')a.title='组会记录';const label=a.querySelector('.cm-app-text');if(label&&label.textContent!=='组会记录')label.textContent='组会记录';}
   if(location.pathname.startsWith('/settings/')&&key==='settings')a.parentElement.classList.add('active');
  });
 }
 let logoutPending=false;
 document.addEventListener('click',async event=>{
  const link=event.target.closest('#user-menu a#logout');if(!link)return;
  event.preventDefault();event.stopImmediatePropagation();if(logoutPending)return;logoutPending=true;
  try{
   for(const key of Object.keys(sessionStorage))if(key.startsWith('workshop:'))sessionStorage.removeItem(key);
   const response=await fetch('/manage/workshop',{credentials:'same-origin'});
   if(response.redirected||[401,403].includes(response.status)){location.assign(link.href);return;}
   if(!response.ok)throw new Error('unconfirmed');
   const page=new DOMParser().parseFromString(await response.text(),'text/html');
   const token=page.querySelector('meta[name="csrf-token"]')?.content;
   if(!token)throw new Error('unconfirmed');
   const form=document.createElement('form');form.method='post';form.action='/manage/workshop/logout';
   const input=document.createElement('input');input.type='hidden';input.name='_token';input.value=token;form.append(input);document.body.append(form);form.submit();
  }catch{logoutPending=false;alert('暂时无法完成统一退出，请稍后重试。');}
 },true);
 if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>{mount();loadWorkshopAccount();});else{mount();loadWorkshopAccount();}
 // Message streams and document editing must not trigger a full shell scan each frame.
 // Settings content remains observed because its native sections mount asynchronously.
 function affectsShell(record){
  if(document.body?.id==='body-settings')return true;
  if(record.target instanceof Element&&record.target.closest('#header,#side-menu,.development-notice'))return true;
  return [...record.addedNodes].some(node=>node instanceof Element&&(node.matches('#header,#side-menu,.development-notice')||node.querySelector('#header,#side-menu,.development-notice')));
 }
 let scheduled=false;const observer=new MutationObserver(records=>{if(!scheduled&&records.some(affectsShell)){scheduled=true;requestAnimationFrame(()=>{scheduled=false;mount();});}});observer.observe(document.documentElement,{subtree:true,childList:true});
})();
