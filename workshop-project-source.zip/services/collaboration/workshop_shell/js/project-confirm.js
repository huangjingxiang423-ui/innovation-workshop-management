/* Native compatibility API backed by @nextcloud/password-confirmation. */
document.addEventListener('DOMContentLoaded',()=>{
 const host=document.getElementById('workshop-project-confirm'),button=document.getElementById('workshop-confirm-maintenance'),status=document.getElementById('workshop-confirm-status');
 if(!host||!button)return;
 button.addEventListener('click',()=>{
  const project=Number(host.dataset.project);if(!Number.isSafeInteger(project)||project<1)return;
  const confirm=window.OC?.PasswordConfirmation?.requirePasswordConfirmation;
  if(typeof confirm!=='function'){status.textContent='原生维护确认尚未加载，请刷新后重试。';return;}
  button.disabled=true;status.textContent='请在账号服务的原生对话框中确认。';
  confirm(()=>{location.assign('/manage/workshop?view=projects&project='+project);},{},()=>{button.disabled=false;status.textContent='维护确认未完成，未继续建置。';});
 });
});
