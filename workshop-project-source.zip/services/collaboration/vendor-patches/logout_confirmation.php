<?php

declare(strict_types=1);

/**
 * SPDX-FileCopyrightText: 2026 Thorsten Jagel <dev@jagel.net>
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * @var array{
 *     action: string,
 *     cancelUrl: string,
 *     confirmationToken: string,
 *     title: string,
 *     message: string,
 *     logoutLabel: string,
 *     cancelLabel: string
 * } $_
 */
?>

<?php
$workshopDisplay = json_decode(rawurldecode((string)($_COOKIE['workshop_ui'] ?? '')), true);
$workshopMode = is_array($workshopDisplay) && in_array($workshopDisplay['theme'] ?? '', ['light','dark','system'], true) ? $workshopDisplay['theme'] : 'system';
?>
<!doctype html>
<html lang="zh-CN" data-theme="<?php p($workshopMode); ?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>确认退出 · 创新工坊</title><link rel="stylesheet" href="/manage/workshop-assets/workshop.css"></head><body><main class="registration"><section class="panel">
<div id="oidc-logout-confirmation" class="guest-box" role="dialog" aria-labelledby="oidc-logout-confirmation-title">
    <h2 id="oidc-logout-confirmation-title">确认退出工坊账号</h2>
    <p>确认后将退出工坊、聊天与资料登录，并返回登录页。</p>

    <form method="post" action="<?php p($_['action']); ?>" autocomplete="off">
        <input type="hidden" name="confirm_logout" value="1">
        <input type="hidden" name="logout_confirmation_token" value="<?php p($_['confirmationToken']); ?>">

        <p class="margin-top">
            <button type="submit" class="primary">确认退出</button>
        </p>
    </form>

    <p>
        <a class="button" href="/manage/auth/login">返回登录入口</a>
    </p>
</div>

</section></main></body></html>
