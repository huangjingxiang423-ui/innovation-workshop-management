<?php

declare(strict_types=1);

/**
 * SPDX-FileCopyrightText: 2026 Thorsten Jagel
 * SPDX-License-Identifier: AGPL-3.0-or-later
 *
 * @var array<string, string> $_
 */

$continueUrl = htmlspecialchars($_['continueUrl'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$continueLabel = htmlspecialchars($_['continueLabel'], ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
?>
<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>正在登录 · 创新工坊</title>
<meta http-equiv="refresh" content="0;url=<?= $continueUrl ?>">
<link rel="stylesheet" href="/manage/workshop-assets/workshop.css"></head><body><main style="max-width:36rem;margin:15vh auto;padding:2rem"><h1>正在进入工坊</h1><p>正在安全地完成登录，请稍候。</p><p><a href="<?= $continueUrl ?>">如果没有自动进入，请继续登录</a></p></main></body></html>
