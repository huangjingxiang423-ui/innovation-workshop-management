<?php
/** SPDX-FileCopyrightText: 2022-2026 Thorsten Jagel <dev@jagel.net>
 * SPDX-License-Identifier: AGPL-3.0-or-later
 * Rendering adapter only; native consent binding, scope ceiling, CSRF and grant/deny controllers remain authoritative.
 */
$display=json_decode(rawurldecode((string)($_COOKIE['workshop_ui']??'')),true);$mode=is_array($display)&&in_array($display['theme']??'',['light','dark','system'],true)?$display['theme']:'system';
$scopes=array_values(array_unique(preg_split('/ +/',trim((string)$_['requestedScopes']),-1,PREG_SPLIT_NO_EMPTY)?:[]));
$labels=['openid'=>'身份验证（必需）','profile'=>'个人资料（姓名、账号与头像）','email'=>'邮箱与邮箱验证状态','groups'=>'项目群组信息','roles'=>'群组与角色信息','phone'=>'电话号码','address'=>'联系地址','offline_access'=>'离线访问'];
?>
<!doctype html><html lang="zh-CN" data-theme="<?php p($mode); ?>"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>确认统一登录 · 创新工坊</title><link rel="stylesheet" href="/manage/workshop-assets/workshop.css"><script nonce="<?php p($_['scriptNonce']); ?>" src="/custom_apps/oidc/js/workshop-consent.js" defer></script></head><body><main class="registration"><section class="panel"><h1>确认统一登录</h1><p><strong><?php p($_['clientName']); ?></strong> 请求使用下列账号信息。</p><p>登录后返回：<?php p($_['redirectTarget']); ?></p><p>请确认你认识这个应用和返回地址。你可以取消可选项目，或拒绝本次登录。</p>
<form id="workshop-consent-grant" method="post" action="<?php p($_['grantUrl']); ?>" accept-charset="UTF-8"><input type="hidden" name="t" value="<?php p($_['consentRequestId']); ?>"><input type="hidden" name="requesttoken" value="<?php p($_['requestToken']); ?>"><input type="hidden" name="scopes" value="">
<?php foreach($scopes as $scope): ?><label><input type="checkbox" data-scope value="<?php p($scope); ?>" checked <?php if($scope==='openid')p('disabled'); ?>> <?php p($labels[$scope]??$scope); ?></label><?php endforeach; ?><p role="status" id="consent-status">授权最长90天，可在账号设置中撤销。身份与邮箱用于匹配已审核的工坊账号。</p><button type="submit" class="primary" disabled>允许并继续登录</button><noscript><p>请启用JavaScript后继续，或拒绝本次登录。</p></noscript></form>
<form method="post" action="<?php p($_['denyUrl']); ?>" accept-charset="UTF-8"><input type="hidden" name="t" value="<?php p($_['consentRequestId']); ?>"><input type="hidden" name="requesttoken" value="<?php p($_['requestToken']); ?>"><button type="submit">拒绝并返回</button></form></section></main></body></html>
