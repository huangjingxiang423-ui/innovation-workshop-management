#!/usr/bin/env bash
set -euo pipefail
# This isolated Docker DB has no TLS listener. Keep the local client compatible.
printf "[client]\nskip-ssl\n" > /home/frappe/.my.cnf
chmod 600 /home/frappe/.my.cnf
export PATH="${NVM_DIR:-/home/frappe/.nvm}/versions/node/v${NODE_VERSION_DEVELOP:-24}/bin:$PATH"
if ! command -v node >/dev/null; then
  nodebin=$(find /home/frappe/.nvm/versions/node -maxdepth 2 -type d -name bin 2>/dev/null | sort -V | tail -1)
  export PATH="$nodebin:$PATH"
fi
if [ ! -f /home/frappe/frappe-bench/apps/frappe/frappe/__init__.py ]; then
  # bench init requires a nonexistent directory; the named volume is kept intact.
  bench init --frappe-branch version-15 --skip-redis-config-generation /home/frappe/setup-bench
  cp -a /home/frappe/setup-bench/. /home/frappe/frappe-bench/
fi
cd /home/frappe/frappe-bench
# Rebind editable package paths after copying the initial bench into its persistent volume.
uv pip install --no-deps -e apps/frappe --python "$PWD/env/bin/python"
bench set-mariadb-host hr-db
bench set-redis-cache-host redis://hr-redis:6379
bench set-redis-queue-host redis://hr-redis:6379
bench set-redis-socketio-host redis://hr-redis:6379
sed -i '/redis/d; /watch/d' Procfile
if ! grep -q -- '--noreload' Procfile; then sed -i '/^web:/s/$/ --noreload/' Procfile; fi
[ -d apps/erpnext ] || bench get-app --branch version-15 erpnext
[ -d apps/hrms ] || bench get-app --branch version-15 hrms
if [ ! -f .workshop-assets-ready ]; then
  bench build
  touch .workshop-assets-ready
fi
if [ ! -f sites/workshop.localhost/site_config.json ]; then
  bench new-site workshop.localhost --mariadb-root-password "$HR_DB_PASSWORD" --admin-password "$HR_ADMIN_PASSWORD" --no-mariadb-socket
fi
bench --site workshop.localhost install-app hrms
bench --site workshop.localhost set-config host_name http://127.0.0.1:18767
bench --site workshop.localhost enable-scheduler
bench use workshop.localhost
exec bench start
