#!/usr/bin/env python3
"""Create local-only secrets for the demo without overwriting existing ones."""
import secrets
from pathlib import Path
p = Path('.env')
if p.exists():
    print('.env 已存在，保留原配置。')
else:
    p.write_text('DB_ROOT_PASSWORD=' + secrets.token_hex(24) + '\nDB_PASSWORD=' + secrets.token_hex(24) + '\nSESSION_PASSWORD=' + secrets.token_hex(32) + '\n')
    p.chmod(0o600)
    print('已创建本地 .env。请勿提交或分享。')
