/* First-paint display preferences only; never identity or authorization. */
(()=>{
 const html=document.documentElement;
 let prefs={};
 try{const value=document.cookie.split('; ').find(x=>x.startsWith('workshop_ui='));const parsed=JSON.parse(decodeURIComponent(value?.slice(12)||'{}'));if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed))prefs=parsed;}catch{}
 const resolve=mode=>mode==='dark'||mode==='light'?mode:matchMedia('(prefers-color-scheme:dark)').matches?'dark':'light';
 function apply(mode,p){
  html.dataset.theme=html.dataset.workshopTheme=resolve(mode);
  html.dataset.reduceMotion=html.dataset.workshopReducedMotion=String(p.reduce_motion===true);
  html.dataset.contrast=html.dataset.workshopContrast=String(p.contrast===true);
  html.dataset.dyslexia=String(p.dyslexia===true);
 }
 apply(prefs.theme,prefs);
 if(!/^\/(?:apps|settings|call)(?:\/|$)/.test(location.pathname))return;
 html.classList.add('workshop-native-frame');
 // The native server-rendered body is authoritative, including its system/default mode.
 // Observe only direct document children until body arrives; no editor/message scanning.
 const nativeBody=()=>{
  const body=document.body;if(!body)return false;
  if(['body-user','body-settings'].includes(body.id)){
   const ids=(body.dataset.themes||'default').split(/[,\s]+/);
   const mode=ids.some(x=>['dark','dark-highcontrast'].includes(x))?'dark':ids.some(x=>['light','light-highcontrast'].includes(x))?'light':'system';
   apply(mode,{reduce_motion:ids.includes('reduced-motion'),contrast:ids.includes('dark-highcontrast')||ids.includes('light-highcontrast'),dyslexia:ids.includes('opendyslexic')});
  }
  return true;
 };
 if(!nativeBody()){const observer=new MutationObserver(()=>{if(nativeBody())observer.disconnect();});observer.observe(html,{childList:true});}
})();
