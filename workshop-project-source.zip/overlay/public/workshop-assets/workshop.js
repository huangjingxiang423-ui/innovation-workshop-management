const base = document.querySelector('meta[name="workshop-base"]').content;
const collaboration = document.querySelector('meta[name="workshop-collaboration"]')?.content || '';
const csrf = document.querySelector('meta[name="csrf-token"]').content;
const root = document.querySelector('#app');
const notice = document.querySelector('#notice');
const registerMode = document.body.dataset.mode === 'register';
const auditLabel = {'task.created':'分配任务','task.meeting_linked':'关联来源组会','task.transition':'更新进度','task.assignment_or_due':'调整责任人或期限','submission.created':'提交新成果','submission.accepted':'成果验收通过','submission.returned':'成果退回修改','file.uploaded':'上传成果附件'};
const labels = {3: '待开展', 4: '进行中', 1: '已阻塞', 2: '待验收', 0: '已完成', '-1': '已取消'};
let state, selected = 0, page = 1, view = 'overview', detail, revision = 0;
let knowledgeProject=0,knowledgeBusy=false;
let meetingSource=new URLSearchParams(location.search).get('meeting_source')||'';
const initialView = new URLSearchParams(location.search).get('view');
selected = Math.max(0, Number(new URLSearchParams(location.search).get('project')) || 0);
if (['overview','mine','projects','tasks','reviews','timeline','people','settings','knowledge','attendance'].includes(initialView)) view = initialView;
let initialData;try{initialData=JSON.parse(document.querySelector('#workshop-initial-data')?.textContent||'null');}catch{}document.querySelector('#workshop-initial-data')?.remove();
let lastFocus;
let taskFilter = 'all';
let theme = 'system';
let nativeAppearance=null,collaborationIdentity=null;
let density = 'comfortable', reduceMotion = false, lastUpdated = '', search = '', settingsTab='profile', chartMode='month';
if (!['system','light','dark'].includes(theme)) theme = 'system';
// URL and visible workspace are committed together only after successful data loading.
let committedRoute=null,committedState=null;
const routeSnapshot=()=>({view,selected,page,taskFilter,search,settingsTab,knowledgeProject,meetingSource});
function applyRoute(route){({view,selected,page,taskFilter,search,settingsTab,knowledgeProject,meetingSource}=route);}
function routeFromLocation(){
 const q=new URLSearchParams(location.search),allowed=['overview','mine','projects','tasks','reviews','timeline','people','settings','knowledge','attendance'];
 return {view:allowed.includes(q.get('view'))?q.get('view'):'overview',selected:Math.max(0,Number(q.get('project'))||0),page:Math.max(1,Math.min(100000,Math.floor(Number(q.get('page'))||1))),taskFilter:['all','review','overdue','done','meeting'].includes(q.get('filter'))?q.get('filter'):'all',search:(q.get('search')||'').slice(0,100),settingsTab:q.get('tab')||'profile',knowledgeProject:Math.max(0,Math.floor(Number(q.get('knowledge_project'))||0)),meetingSource:q.get('meeting_source')||''};
}
function routeUrl(route){
 const q=new URLSearchParams({view:route.view});if(route.selected)q.set('project',route.selected);if(route.page>1)q.set('page',route.page);if(route.taskFilter!=='all')q.set('filter',route.taskFilter);if(route.search)q.set('search',route.search);if(route.view==='settings')q.set('tab',route.settingsTab);if(route.view==='knowledge'&&route.knowledgeProject)q.set('knowledge_project',route.knowledgeProject);
 if(route.view==='tasks'&&route.meetingSource)q.set('meeting_source',route.meetingSource);
 return base+'/workshop?'+q;
}
applyRoute(routeFromLocation());
const initialTab=new URLSearchParams(location.search).get('tab');if(['profile','security','notifications','appearance','data','workspace','about'].includes(initialTab))settingsTab=initialTab;
try{const ui=JSON.parse(decodeURIComponent(document.cookie.split('; ').find(x=>x.startsWith('workshop_ui='))?.slice(12)||'{}'));if(['dark','light','system'].includes(ui.theme))theme=ui.theme;density=ui.density==='compact'?'compact':'comfortable';reduceMotion=!!ui.reduce_motion;nativeAppearance=ui;}catch{}
const colorPreference = matchMedia('(prefers-color-scheme: dark)');
function applyTheme() {
  document.documentElement.dataset.theme = theme === 'system' ? (colorPreference.matches ? 'dark' : 'light') : theme;
  document.documentElement.dataset.workshopTheme=document.documentElement.dataset.theme;
  document.documentElement.dataset.density = density;
  document.documentElement.dataset.reduceMotion = document.documentElement.dataset.workshopReducedMotion = String(reduceMotion);
  document.documentElement.dataset.contrast=document.documentElement.dataset.workshopContrast=String(!!nativeAppearance?.contrast);
  document.documentElement.dataset.dyslexia=String(!!nativeAppearance?.dyslexia);
  if(/^#[0-9a-f]{6}$/i.test(nativeAppearance?.primary||''))document.documentElement.style.setProperty('--accent',nativeAppearance.primary);
  if(state)document.cookie='workshop_ui='+encodeURIComponent(JSON.stringify({...nativeAppearance,theme,density,reduce_motion:reduceMotion,name:state.workspace.name}))+'; Path=/; SameSite=Lax; Max-Age=2592000';
}
applyTheme();
colorPreference.addEventListener('change', applyTheme);
const filterTitles = {all:'全部任务',review:'待验收',overdue:'逾期未完成',done:'已完成',meeting:'本组会已关联任务'};
const esc = (value) => String(value ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const date = (value) => value ? new Intl.DateTimeFormat('zh-CN', {month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit',timeZone:'Asia/Shanghai'}).format(new Date(value.replace(' ', 'T') + 'Z')) : '未设置';
const localDate = (value) => value ? new Date(new Date(value.replace(' ','T')+'Z').getTime()+8*3600000).toISOString().slice(0,16) : '';
let noticeTimer;
function message(text, error = false) { clearTimeout(noticeTimer);notice.textContent = text; notice.classList.toggle('error', error); notice.hidden = false; if(!error)noticeTimer=setTimeout(()=>{notice.hidden=true;},5000); }
async function request(path, options = {}) {
  const controller = new AbortController();
  const {timeoutMs=20000,signal:externalSignal,...fetchOptions}=options;
  const abortExternal=()=>controller.abort();
  if(externalSignal?.aborted)abortExternal();else externalSignal?.addEventListener('abort',abortExternal,{once:true});
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(base + path, {...fetchOptions, signal:controller.signal, credentials:'same-origin',
      headers:{'Accept':'application/json','X-Requested-With':'XMLHttpRequest','X-CSRF-TOKEN':csrf,...options.headers}});
    if (response.redirected || response.status === 401) throw new Error('登录已失效，请重新登录。输入不会因本次错误被清空。');
    let body;
    try { body = await response.json(); } catch { throw new Error('服务暂不可用，保存结果尚未确认；请保留输入并重试。'); }
    if (!response.ok) { const error = new Error(body.error || body.message || `操作失败（${response.status}）`); error.confirmed = true; error.status=response.status; throw error; }
    return body;
  } catch (error) {
    if (error.name === 'AbortError' || error instanceof TypeError) throw new Error('网络中断或超时，保存结果待确认。请保留输入并重试同次操作，系统会防止重复保存。');
    throw error;
  } finally { clearTimeout(timer); externalSignal?.removeEventListener('abort',abortExternal); }
}
const prefix = () => `workshop:${state?.actor.id ?? 'public'}:`;
const draftId = (form) => form.dataset.kind + ':' + ['task_id','user_id','project_id'].map(k=>form.elements[k]?.value||'').join(':');
function draft(form) {
  const data = {};
  for (const field of form.elements) if (field.name && !['password','file','_token','confirm_meeting_project','meeting_source'].includes(field.name)) data[field.name] = field.value;
  try { sessionStorage.setItem(prefix() + 'draft:' + draftId(form), JSON.stringify(data)); } catch { /* Storage may be disabled. */ }
}
function restore(form) {
  try {
    const data = JSON.parse(sessionStorage.getItem(prefix()+'draft:'+draftId(form)) || '{}');
    for (const [key,value] of Object.entries(data)) if (form.elements[key] && !['revision','task_id','submission_id','project_id','user_id','meeting_source','confirm_meeting_project'].includes(key)) form.elements[key].value = value;
  } catch { /* A draft is not authoritative data. */ }
}
let groupQueueAttempted=false,groupQueueBusy=false,groupQueueMessage='';
async function flushProjectGroupQueue(){
 if(groupQueueBusy||!state?.actor.owner)return;
 groupQueueAttempted=true;groupQueueBusy=true;groupQueueMessage='正在后台核对登记项目组权限；可以继续使用当前页面。';paintGroupQueue();
 try{
  const owner=state.actor.id,started=Date.now();let processed=0,result;
  for(let batch=0;batch<100;batch++){
   result=await request('/workshop/enrollment/groups/flush',{method:'POST',timeoutMs:120000,headers:{'Content-Type':'application/json'},body:'{}'});
   processed+=result.processed;groupQueueMessage=`本次已核对 ${processed} 人，剩余 ${result.remaining} 人。`+(result.reason||'');paintGroupQueue();
   if(result.blocked||!result.remaining||!result.processed||state.actor.id!==owner||!state.actor.owner||Date.now()-started>180000)break;
  }
  if(result&&!result.remaining)groupQueueMessage=`本次已核对 ${processed} 人，登记项目组权限队列已核对完成。`;
  // Refresh only the people data, never redirect or overwrite a newly selected page.
  if(view==='people'&&state.actor.id===owner)await load('replace');
 }catch(error){groupQueueMessage=error.message+' 待同步记录已保留，可稍后重试。';}
 finally{groupQueueBusy=false;paintGroupQueue();}
}
function projectGroupQueueView(){
 const pending=state.people.filter(p=>p.collaboration_group_status==='pending').length;
 const unverified=state.people.filter(p=>p.collaboration_bound&&!['pending','verified'].includes(p.collaboration_group_status)).length;
 if(!state.actor.owner&&!pending&&!unverified)return '';
 return `<div id="project-group-queue" class="section-head" aria-label="消息与资料权限同步"><p class="subtle" role="status"></p>${state.actor.owner?'<button data-flush-project-groups>核对待同步权限</button>':''}</div>`;
}
function paintGroupQueue(){
 const panel=document.querySelector('#project-group-queue');if(!panel)return;
 const pending=state.people.filter(p=>p.collaboration_group_status==='pending').length;
 const unverified=state.people.filter(p=>p.collaboration_bound&&!['pending','verified'].includes(p.collaboration_group_status)).length;
 const explanation=(pending?`有 ${pending} 人的消息与资料项目组权限待核对；主系统权限已按当前成员关系生效，受影响账号暂不能进入消息与资料。`:'')+(unverified?` 有 ${unverified} 个已绑定账号尚无项目组核对记录，不能据此认定权限已经一致。`:'')||'人员入退组后需核对聊天与资料权限；未核对前暂停受影响账号的模块访问。';
 panel.querySelector('[role="status"]').textContent=state.actor.owner?((groupQueueMessage||explanation)+(unverified?` 请使用对应人员行的“同步项目组权限”核对 ${unverified} 个无核对记录账号。`:'')):explanation+' 请联系系统维护管理员完成核对；老师和总负责人无需重复修改成员关系。';
 const button=panel.querySelector('button');if(button){button.disabled=groupQueueBusy;button.textContent=groupQueueBusy?'正在核对…':'核对待同步权限';}
}
async function mutate(action, data, formKey = action) {
  const signature = JSON.stringify({action, data});
  const storageKey = prefix() + 'request:' + formKey;
  let pending;
  try { pending = JSON.parse(sessionStorage.getItem(storageKey)); } catch {}
  if (!pending || pending.signature !== signature) pending = {key:crypto.randomUUID(), signature};
  try { sessionStorage.setItem(storageKey, JSON.stringify(pending)); } catch {}
  const result = await request('/workshop/action', {method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':pending.key},body:JSON.stringify({action,data})});
  // A late acknowledgement must not clear a newer operation using the same form.
  try{if(JSON.parse(sessionStorage.getItem(storageKey)||'null')?.key===pending.key)sessionStorage.removeItem(storageKey);}catch{}
  message(result.message);
  if(['membership','approve','suspend','person_role','import_roster','create_project'].includes(action))groupQueueAttempted=false;
  return result;
}
const navIcon = (name) => {
  const paths = {chat:'<path d="M21 11.5a8.5 8.5 0 0 1-8.5 8.5H4l-2 2v-10.5a8.5 8.5 0 1 1 19 0Z"/><path d="M7 10h9M7 14h6"/>',files:'<path d="M3 6h7l2 2h9v13H3Z"/><path d="M3 6V3h7l2 3"/>',meetings:'<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M7 2v4M17 2v4M3 9h18M7 13h10M7 17h7"/>',timeline:'<path d="M5 3v18M9 6h10M9 12h7M9 18h12"/>',projects:'<rect x="3" y="4" width="18" height="17" rx="2"/><path d="M7 4V2M17 4V2M3 9h18"/>',settings:'<path d="m9 3-1 3-3 1v4l-2 1 2 3v3l4 1 3 2 3-2 4-1v-3l2-3-2-1V7l-3-1-1-3Z"/><circle cx="12" cy="12" r="3"/>',overview:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>',tasks:'<rect x="4" y="4" width="16" height="17" rx="2"/><path d="M9 4V2h6v2M8 10h8M8 14h8M8 18h5"/>',reviews:'<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',people:'<circle cx="9" cy="8" r="3"/><path d="M3 21v-3a6 6 0 0 1 12 0v3M16 5a3 3 0 0 1 0 6M21 21v-3a6 6 0 0 0-4-5"/>'};
  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${paths[name]||paths.tasks}</svg>`;
};
function badge(task) { return `<span class="badge status-${Number(task.status)}">${esc(task.cancelled ? '已取消' : labels[task.status] || '未知状态')}</span>`; }
function canLead(projectId) { return state.manager || state.memberships.some((m) => +m.project_id === +projectId && +m.user_id === +state.actor.id && +m.active === 1 && m.role === 'leader'); }
function projectOptions(value = selected) { return state.projects.map((p) => `<option value="${+p.project_id}" ${+value===+p.project_id?'selected':''}>${esc(p.name)}${p.archived_at?'（已归档）':''}</option>`).join(''); }
function memberOptions(projectId, value) { return state.memberships.filter((m) => +m.project_id===+projectId && +m.active===1 && m.status==='approved').map((m) => `<option value="${+m.user_id}" ${+value===+m.user_id?'selected':''}>${esc(m.name)}${m.role==='leader'?' · 组长':''}</option>`).join(''); }
function field(name,label,type='text',value='',extra='') { return `<label>${esc(label)}<input name="${name}" type="${type}" value="${esc(value)}" ${extra}></label>`; }
function area(name,label,value='',extra='') { return `<label>${esc(label)}<textarea name="${name}" rows="4" ${extra}>${esc(value)}</textarea></label>`; }
const hidden = (name,value) => `<input type="hidden" name="${name}" value="${esc(value)}">`;
function modal(title, html) {
  closeModal(); lastFocus = document.activeElement;
  const dialog = document.createElement('dialog'); dialog.id = 'drawer';
  dialog.innerHTML = `<header class="dialog-head"><h2>${esc(title)}</h2><button class="icon" data-action="close" aria-label="关闭详情">×</button></header><div class="dialog-body">${html}</div>`;
  document.body.append(dialog); dialog.showModal();
  dialog.addEventListener('close', () => { dialog.remove(); lastFocus?.focus(); });
  dialog.querySelectorAll('form').forEach(restore);
}
function closeModal() { cancelTaskRead();document.querySelector('#drawer')?.close(); }
async function load(historyMode='push') {
  // A newer local navigation supersedes pending module handoffs and task drawers.
  nativeNavigationTicket++;cancelTaskRead();
  if(openCollaboration.readController){openCollaboration.readController.abort();notice.hidden=true;}
  const ticket = ++revision;
  load.readController?.abort();load.readController=new AbortController();const readSignal=load.readController.signal;
  root.setAttribute('aria-busy','true');
  document.querySelectorAll('[data-action="refresh"]').forEach(b=>{b.disabled=true;b.innerHTML='<span class="spinner" aria-hidden="true"></span> 正在刷新…';});
  const nativeIdentity = !load.nativeAppearanceChecked && collaboration ? fetch(collaboration+'/index.php/apps/workshop_shell/identity',{credentials:'same-origin',signal:AbortSignal.timeout(5000)}).then(r=>r.ok?r.json():null).catch(()=>null) : null;
  try {
    const bootstrap=initialData;initialData=null;
    const next = bootstrap || await request(`/workshop/data?project_id=${selected}&page=${page}&view=${view}&filter=${taskFilter}&mine=${view==='mine'?1:0}&search=${encodeURIComponent(search)}${taskFilter==='meeting'?'&meeting_source='+encodeURIComponent(meetingSource):''}`,{signal:readSignal});
    if (ticket !== revision) return;
    state = next;
    if(!load.meetingSourceRestored){load.meetingSourceRestored=true;try{meetingSource=meetingSource||sessionStorage.getItem(prefix()+'meeting-source')||'';if(meetingSource)sessionStorage.setItem(prefix()+'meeting-source',meetingSource);}catch{}}
    if(view==='knowledge'&&typeof knowledgeLibraries!=='undefined')knowledgeLibraries.clear();
    const prefs=state.workspace?.preferences||{};
    density=prefs.density||'comfortable';
    if(!load.nativeAppearanceChecked&&collaboration){
      load.nativeAppearanceChecked=true;
      const actorId=state.actor.id,actorEmail=state.actor.email.toLowerCase(),displayKey='workshop:display-identity:'+actorId;
      // Cached avatar is presentation only. All navigation and business authorization still use live sessions.
      try{const cached=JSON.parse(sessionStorage.getItem(displayKey)||'null');if(cached?.email?.toLowerCase()===actorEmail)collaborationIdentity=cached;}catch{}
      nativeIdentity.then(identity=>{
        if(!identity||state.actor.id!==actorId||identity.email?.toLowerCase()!==actorEmail)return;
        collaborationIdentity=identity;nativeAppearance=identity.appearance;
        try{sessionStorage.setItem(displayKey,JSON.stringify({email:identity.email,uid:identity.uid,avatar_url:identity.avatar_url,avatar_version:identity.avatar_version}));}catch{}
        theme=nativeAppearance.theme||theme;reduceMotion=!!nativeAppearance.reduce_motion;applyTheme();
        document.querySelectorAll('.account-menu>summary,.sidebar-bottom>.user-avatar').forEach(el=>{el.innerHTML=actorAvatar();});
      });
    }
    if(nativeAppearance){theme=nativeAppearance.theme||theme;reduceMotion=!!nativeAppearance.reduce_motion;}
    if(view==='people'&&!state.manager)view='overview';
    lastUpdated=new Intl.DateTimeFormat('zh-CN',{hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false}).format(new Date());

    if(view==='attendance'){try{attendanceState=await request('/workshop/attendance',{signal:readSignal});}catch(error){attendanceState={error:error.message};}if(ticket!==revision)return;}
    applyTheme();if(view==='settings'){await openCollaboration(collaboration+'/settings/user/workshop-identity');return;}render();
    const nextRoute=routeSnapshot(),url=routeUrl(nextRoute);
    if(!committedRoute||historyMode==='replace'||url===location.pathname+location.search)history.replaceState({workshop:true},'',url);
    else history.pushState({workshop:true},'',url);
    committedRoute=nextRoute;committedState=state;
    if(view==='people'){
      paintGroupQueue();
      if(state.actor.owner&&!groupQueueAttempted&&state.people.some(p=>p.collaboration_group_status==='pending'))void flushProjectGroupQueue();
    }
  } catch(error){
    if(ticket!==revision)return;
    if(committedRoute){applyRoute(committedRoute);state=committedState;history.replaceState({workshop:true},'',routeUrl(committedRoute));}
    throw error;
  } finally {
    if(ticket===revision){root.setAttribute('aria-busy','false');document.querySelectorAll('[data-action="refresh"]').forEach(b=>{b.disabled=false;b.textContent='↻ 刷新数据';});}
  }
}
let nativeNavigationTicket=0;
let taskReadTicket=0,taskReadController;
function cancelTaskRead(){taskReadTicket++;taskReadController?.abort();taskReadController=null;}
async function readTaskForCurrentPage(id){
 cancelTaskRead();const ticket=taskReadTicket,pageRevision=revision,navigationTicket=nativeNavigationTicket;
 const controller=new AbortController();taskReadController=controller;
 const current=()=>ticket===taskReadTicket&&pageRevision===revision&&navigationTicket===nativeNavigationTicket;
 try{const data=await request('/workshop/data?task_id='+Number(id),{signal:controller.signal});return current()?data:null;}
 catch(error){if(current())throw error;return null;}
 finally{if(taskReadController===controller)taskReadController=null;}
}
async function openCollaboration(url){
 const destination=new URL(url,location.href),origin=new URL(collaboration,location.href).origin;
 if(destination.origin!==origin)throw new Error('无法打开未配置的工坊服务。');
 const ticket=++nativeNavigationTicket;cancelTaskRead();
 openCollaboration.readController?.abort();
 const controller=new AbortController();openCollaboration.readController=controller;
 const timer=setTimeout(()=>controller.abort(),10000);
 message('正在进入工坊模块…');
 try{
  let response;try{response=await fetch(base+'/workshop/collaboration-access',{credentials:'same-origin',redirect:'error',headers:{Accept:'application/json'},signal:controller.signal});}catch{if(ticket!==nativeNavigationTicket)return;throw new Error('网络中断或统一服务响应超时，请稍后重试。当前页面已保留。');}
  if(ticket!==nativeNavigationTicket)return;
  if(!response.ok){let body={};try{body=await response.json();}catch{}if(ticket!==nativeNavigationTicket)return;throw new Error(body.error||'暂时无法核对统一账号，请稍后重试。');}
  // The stable-UID gateway still checks the destination; cancellation never skips authorization.
  location.assign(destination.href);
 }finally{clearTimeout(timer);if(openCollaboration.readController===controller)openCollaboration.readController=null;}
}
const projectStat = p => state.overview.projects.find(x=>+x.projectId===+p.project_id)||{total:0,done:0,review:0,overdue:0,blocked:0};
const projectProgress = p => {const x=projectStat(p);return +x.active_total?Math.round(x.done/x.active_total*100):0;};
const projectPeople = p => state.memberships.filter(m=>+m.project_id===+p.project_id&&+m.active&&m.status==='approved');
const leaderNames = p => projectPeople(p).filter(m=>m.role==='leader').map(m=>m.name).join('、')||'待任命组长';
const projectRisk = p => {const x=projectStat(p);return p.archived_at?'已归档':+x.blocked?'有阻塞':+x.overdue?'有逾期':+x.review?'待验收':'正常推进';};
const navigation=window.WorkshopNavigation;
function navLink(key,label,primary=false,group){
 const current=primary?navigation.groupFor(view)?.id===group.id:view===key;
 const attrs=key==='equipment'?'target="_blank" rel="noopener" title="独立试用环境，尚未统一账号"':navigation.nativePaths[key]?`data-collaboration="${key}"`:`data-view="${key}"`;
 const href=navigation.href(key,base)+(!primary&&selected&&['tasks','reviews','timeline'].includes(key)?'&project='+selected:'');
 return `<a href="${esc(href)}" ${attrs} class="${primary?'nav-item':'section-tab'}${current?' selected':''}" ${current?'aria-current="page"':''}>${primary?`<span class="nav-icon">${navigation.svg(group.icon)}</span>`:''}<span>${label}</span>${key==='equipment'?'<span aria-hidden="true">↗</span>':''}</a>`;
}
function mainNavigation(){return navigation.groups(state.actor,!!collaboration).map(g=>navLink(g.items[0][0],g.label,true,g)).join('');}
function sectionNavigation(){const g=navigation.groups(state.actor,!!collaboration).find(g=>g.items.some(([key])=>key===view));return !g||g.items.length<2?'':`<nav class="section-navigation" aria-label="${g.label}分类">${g.items.map(([key,label])=>navLink(key,label)).join('')}</nav>`;}
function actorRole(){
 if(state.manager)return ({manager:'总负责人',teacher:'指导老师'})[state.actor.role]||'总负责人';
 const roles=state.memberships.filter(m=>+m.user_id===+state.actor.id&&+m.active);
 if(selected)return roles.find(m=>+m.project_id===selected)?.role==='leader'?'项目组长':'项目组员';
 return roles.some(m=>m.role==='leader')?'项目组长（按项目授权）':'项目组员';
}
function actorAvatar(){
 if(!collaborationIdentity?.avatar_url)return esc(state.actor.name.slice(0,1));
 const url=collaborationIdentity.avatar_url+(document.documentElement.dataset.theme==='dark'?'/dark':'')+'?guestFallback=true&v='+Number(collaborationIdentity.avatar_version||0);
 return `<img src="${esc(url)}" alt="" width="32" height="32">`;
}
const accountLink=(path,label,icon)=>`<a data-collaboration="account" href="${esc(collaboration+path)}"><img src="${esc(collaboration+icon)}" alt="">${label}</a>`;
function accountMenu(){return `<details class="account-menu"><summary aria-label="账号菜单" title="账号菜单">${actorAvatar()}</summary><div class="account-menu-panel"><a class="account-identity" data-collaboration="profile" href="${esc(collaboration)}/settings/user/profile-contact"><strong>${esc(state.actor.name)}</strong><small>${esc(actorRole())}</small></a>${accountLink('/settings/user/theming','外观和辅助功能','/apps/theming/img/accessibility-dark.svg')}${accountLink('/settings/user/workshop-identity','设置','/apps/settings/img/personal.svg')}<form action="${base}/workshop/logout" method="post">${hidden('_token',csrf)}<button><span aria-hidden="true">↪</span>退出登录</button></form></div></details>`;}
// Preserve in-progress text only for a refresh of the same actor and route.
function refreshingPageState(){
 if(!committedRoute||committedState?.actor.id!==state.actor.id||['view','selected','taskFilter','search','knowledgeProject'].some(key=>committedRoute[key]!==routeSnapshot()[key]))return null;
 const active=document.activeElement,saved={x:window.scrollX,y:window.scrollY,inputs:[]};
 for(const el of root.querySelectorAll('input,textarea')){
  if(el.disabled||el.readOnly||!['text','search','email','tel','url','textarea'].includes(el.type))continue;
  const selector=el.id?'#'+CSS.escape(el.id):el.name&&el.form?.id?'#'+CSS.escape(el.form.id)+' [name="'+CSS.escape(el.name)+'"]':null;
  if(selector)saved.inputs.push({selector,value:el.value,focused:el===active,start:el.selectionStart,end:el.selectionEnd,direction:el.selectionDirection,scrollTop:el.scrollTop});
 }
 if(active?.matches('button[data-action="refresh"]'))saved.focusSelector='[data-action="refresh"]';
 return saved;
}
function restoreRefreshingPage(saved){
 if(!saved)return;
 for(const i of saved.inputs){const el=root.querySelector(i.selector);if(!el||el.disabled||el.readOnly)continue;el.value=i.value;if(i.focused){el.focus({preventScroll:true});if(Number.isInteger(i.start)&&Number.isInteger(i.end))el.setSelectionRange(i.start,i.end,i.direction||'none');}el.scrollTop=i.scrollTop;}
 if(saved.focusSelector)root.querySelector(saved.focusSelector)?.focus({preventScroll:true});
 window.scrollTo(saved.x,saved.y);
}
function updateWorkspace(html) {
  const template=document.createElement('template');template.innerHTML=html;
  const current=root.querySelector('.layout'),next=template.content.querySelector('.layout');
  const sidebar=current?.querySelector('.sidebar'),nextSidebar=next?.querySelector('.sidebar');
  const main=current?.querySelector('.main'),nextMain=next?.querySelector('.main');
  if(!sidebar||!nextSidebar||!main||!nextMain){root.replaceChildren(template.content);return;}
  const attributes=(old,fresh)=>{
    for(const attr of Array.from(old.attributes))if(!fresh.hasAttribute(attr.name))old.removeAttribute(attr.name);
    for(const attr of Array.from(fresh.attributes))if(old.getAttribute(attr.name)!==attr.value)old.setAttribute(attr.name,attr.value);
  };
  // Preserve the actual navigation anchors, including focus and an in-progress click.
  const nav=sidebar.querySelector('#main-navigation'),nextNav=nextSidebar.querySelector('#main-navigation');
  if(nav&&nextNav){
    const existing=Array.from(nav.children),wanted=new Set();
    Array.from(nextNav.children).forEach((fresh,index)=>{
      const key=new URL(fresh.getAttribute('href'),location.href).href;let anchor=existing.find(a=>new URL(a.getAttribute('href'),location.href).href===key);
      if(anchor){attributes(anchor,fresh);if(anchor.innerHTML!==fresh.innerHTML)anchor.innerHTML=fresh.innerHTML;}
      else anchor=fresh;
      wanted.add(anchor);if(nav.children[index]!==anchor)nav.insertBefore(anchor,nav.children[index]||null);
    });
    existing.forEach(anchor=>{if(!wanted.has(anchor))anchor.remove();});
    attributes(nav,nextNav);
  }
  for(const selector of ['.brand','.mobile-nav-toggle','.nav-caption','.sidebar-bottom']){
    const old=sidebar.querySelector(selector),fresh=nextSidebar.querySelector(selector);
    if(old&&fresh){attributes(old,fresh);if(old.innerHTML!==fresh.innerHTML)old.innerHTML=fresh.innerHTML;}
  }
  attributes(sidebar,nextSidebar);main.replaceWith(nextMain);
}
function render() {
  const refreshing=refreshingPageState();
  const titles={overview:'工坊总览',projects:selected?'项目详情':'项目中心',tasks:'项目任务',timeline:'项目日历',mine:'我的任务',reviews:'成果验收',people:'人员与权限',settings:'设置',knowledge:'智能知识助手',attendance:'考勤管理'};
  const subtitles={overview:'掌握项目进展，聚焦需要你关注的事项。',projects:'项目档案、成员与阶段目标。',tasks:'分配、推进与交付每一项具体任务。',timeline:'沿时间查看交付安排，点击任务查看详情。',mine:'专注你负责的任务与交付。',reviews:'查看成果版本，完成验收闭环。',people:'核实身份，维护人员与各项目角色。',settings:'管理个人偏好与工坊配置。',knowledge:'基于项目已发布资料提问，查看回答依据。',attendance:'记录自己的签到、签退，查看考勤异常。'};
  document.title=(titles[view]||'工作台')+' · '+state.workspace.name;
  updateWorkspace(`<div class="layout"><aside class="sidebar"><a class="brand" href="${base}/workshop" data-action="home"><span class="brand-mark">W</span><span>${esc(state.workspace.name)}<small>创新 · 协作 · 实践</small></span></a>
    <button class="mobile-nav-toggle" data-action="toggle-nav" aria-expanded="false" aria-controls="main-navigation">功能菜单</button><p class="nav-caption">工作空间</p><nav id="main-navigation" aria-label="主导航">${mainNavigation()}</nav>
    <div class="sidebar-bottom"><span class="user-avatar">${actorAvatar()}</span><div><strong>${esc(state.actor.name)}</strong><small>${esc(actorRole())}</small></div><form action="${base}/workshop/logout" method="post" id="logout">${hidden('_token',csrf)}<button class="quiet" aria-label="退出登录">退出</button></form></div></aside>
    <main class="main"><header class="page-head"><div><p class="eyebrow">${esc(state.workspace.name)} <span>/</span> 工作空间</p><h1>${titles[view]}</h1><p class="subtle">${subtitles[view]}</p></div><div class="head-actions">${!['settings','people','knowledge','attendance'].includes(view)?`<form class="quick-search" id="task-search"><span aria-hidden="true">⌕</span><input name="search" aria-label="搜索任务" placeholder="搜索任务…" value="${esc(search)}" maxlength="100"><button aria-label="开始搜索">搜索</button></form>`:''}${state.manager&&['overview','projects'].includes(view)?'<button class="primary" data-action="new-project">＋ 建立项目</button>':''}${accountMenu()}</div></header>
    ${sectionNavigation()}<div class="sync-bar"><span class="sync-dot"></span><span role="status">数据更新于 ${lastUpdated}</span><button data-action="refresh">↻ 刷新数据</button></div>
    ${view==='settings'?'<section class="panel"><h2>正在进入统一设置…</h2><p class="subtle">个人、安全、通知和工坊设置均在同一设置中心。</p></section>':view==='attendance'?attendanceView():view==='knowledge'?knowledgeView():view==='people'?peopleView():view==='overview'?overviewView():view==='projects'?projectsView():view==='timeline'?timelineView():workspaceView()}
    <footer class="footnote">北京时间 · ${esc(state.workspace.name)} · 保存以服务器确认为准</footer></main></div>`);
  renderTimeline();
  if(view==='projects'&&selected&&collaboration)void loadProjectSpace();
  restoreRefreshingPage(refreshing);
}
function metricsView(){
 const rows=state.overview.projects;
 const active=state.projects.filter(p=>!p.archived_at).length;
 const overdue=rows.reduce((v,x)=>v+Number(x.overdue),0),review=rows.reduce((v,x)=>v+Number(x.review),0),done=rows.reduce((v,x)=>v+Number(x.done),0);
 return `<section class="metrics" aria-label="工坊状态统计">${[['进行中项目',active,'projects','overview'],['待验收成果',review,'review','reviews'],['逾期未完成',overdue,'overdue','tasks'],['已完成任务',done,'done','tasks']].map(([label,num,key,target],i)=>`<button class="metric metric-${i}" ${key==='projects'?'data-view="projects"':`data-filter="${key}"`}><div><span>${label}</span><span class="metric-symbol" aria-hidden="true">${['◫','√','!','↗'][i]}</span></div><strong>${num}<small>${i===0?'个项目':'项任务'}</small></strong><small>查看${label} →</small></button>`).join('')}</section>`;
}


let attendanceState=null,attendanceBusy=false,attendancePendingMemory=null;
function attendancePending(){
 try{const p=JSON.parse(sessionStorage.getItem(prefix()+'attendance-pending'));if(p&&['IN','OUT'].includes(p.event_type)&&/^[a-zA-Z0-9_-]{16,80}$/.test(p.key))return p;}catch{}
 return attendancePendingMemory;
}
function attendanceView(){
 const a=attendanceState,pending=attendancePending();
 const hasPendingCorrection=a?.corrections?.some(c=>c.user_id===state.actor.id&&['pending','processing'].includes(c.status));
 if(!a)return '<section class="panel"><h2>正在读取考勤记录…</h2></section>';
 if(a.error)return `<section class="panel"><h2>考勤暂不可用</h2><p class="pre">${esc(a.error)}</p><p class="subtle">可使用上方刷新数据重试，未确认的操作编号会保留。</p></section>`;
 if(!a.connected)return `<section class="panel"><h2>尚未绑定考勤档案</h2><p class="pre">${esc(a.message)}</p></section>${a.can_review?attendanceCorrectionsView(a):''}${attendanceReportView(a)}`;
 return `${attendanceReportView(a)}<section class="panel attendance-panel"><div class="section-head"><div><h2><i></i>我的考勤</h2><p class="subtle">${esc(a.employee_name)} · 北京时间</p></div><span class="risk ${a.needs_correction?'risk-warning':''}">${a.needs_correction?'需要补正':a.checked_in?'已签到，待签退':'当前未签到'}</span></div><p class="pre">${esc(a.message)}</p>
 <div class="row-actions attendance-actions">${a.needs_correction?`<button data-correction-request="true" ${hasPendingCorrection?'disabled':''}>${hasPendingCorrection?'补正申请待处理':'申请补签退'}</button>`:''}${pending?`<button class="primary" data-attendance-type="${pending.event_type}" ${attendanceBusy?'disabled':''}>${attendanceBusy?'正在核对…':pending.event_type==='IN'?'重试并核对签到':'重试并核对签退'}</button><span class="subtle">有一项保存结果待确认，请先核对这次操作。</span>`:`<button class="primary" data-attendance-type="IN" ${attendanceBusy||a.checked_in||a.needs_correction?'disabled':''}>签到</button><button data-attendance-type="OUT" ${attendanceBusy||!a.checked_in||a.needs_correction?'disabled':''}>签退</button>`}</div>
 <p class="subtle">已支持跨日漏签退申请与人工审核；已提供原始记录周汇总；请假、其他补签及正式出勤考核仍待接通，不自动计算考核结果。</p></section>
 ${attendanceWeeklyView(a)}${attendanceCorrectionsView(a)}<section class="panel attendance-panel"><div class="section-head"><h2><i></i>最近记录</h2><span class="subtle">最近50条 · 北京时间</span></div><div class="table-scroll"><table><thead><tr><th>操作</th><th>记录时间</th></tr></thead><tbody>${a.records.map(x=>`<tr><td>${x.event_type==='IN'?'签到':a.corrections?.some(c=>c.record_id===x.id&&c.status==='approved')?'签退（审核补正）':'签退'}</td><td>${esc(x.time)}</td></tr>`).join('')||'<tr><td colspan="2" class="empty">尚无签到签退记录。</td></tr>'}</tbody></table></div></section>`;
}
function attendanceReportView(a){
 if(!a.can_review)return '';
 if(a.report_error)return `<section class="panel"><h2>工坊考勤记录查询</h2><p role="alert">${esc(a.report_error)}</p></section>`;
 const people=a.report_people||[];
 return `<section class="panel attendance-panel"><h2><i></i>工坊考勤记录查询</h2><p class="subtle">仅查询已绑定的 ${people.length} 个账号，未绑定人员不在本报告范围。按周查看原始签到签退，不自动判断达标或退出。</p><form id="attendance-report-query" class="head-actions"><label>所在周（任选一天）<input type="date" name="week" value="${esc(a.report_week)}" required></label><label>人员<select name="user_id"><option value="0">全部已绑定人员</option>${people.map(p=>`<option value="${p.user_id}">${esc(p.name)}${p.student_no?' · '+esc(p.student_no):''}</option>`).join('')}</select></label><button type="submit" ${people.length?'':'disabled'}>查询记录</button></form><div id="attendance-report-results" role="status"><p class="subtle">选择条件后点击查询；每页50条，可导出同一周和人员条件下的记录。</p></div></section>`;
}
function attendanceReportRows(data){
 const q=new URLSearchParams({week:data.start,user_id:String(data.user_id)});
 return `<div class="section-head"><p>${esc(data.start)} 至 ${esc(data.end)} · 北京时间 · 原始记录</p><a class="button" href="${base}/workshop/attendance/export?${q}">导出本周记录 CSV</a></div><p class="subtle">导出沿用当前查询条件，不限于当前页；单次最多5000条，超过后请按人员分别导出。用 Excel 导入时，请将学员编号列设为文本以保留前导零。</p><div class="table-scroll"><table><thead><tr><th>姓名</th><th>学员编号</th><th>操作</th><th>北京时间</th><th>审核补正</th></tr></thead><tbody>${data.records.map(r=>`<tr><td>${esc(r.name)}</td><td>${esc(r.student_no)||'—'}</td><td>${esc({IN:'签到',OUT:'签退'}[r.event_type]||'未知类型')}</td><td>${esc(r.time)}</td><td>${r.corrected?'是':'—'}</td></tr>`).join('')||'<tr><td colspan="5" class="empty">本周没有符合条件的签到签退记录。</td></tr>'}</tbody></table></div><div class="pagination"><button data-attendance-report-page="${data.page-1}" ${data.page<=1?'disabled':''}>上一页</button><span>第 ${data.page} 页 · 每页50条</span><button data-attendance-report-page="${data.page+1}" ${data.has_more?'':'disabled'}>下一页</button></div>`;
}
async function readAttendanceReport(week,user,page=1){
 const host=document.querySelector('#attendance-report-results'),form=document.querySelector('#attendance-report-query');if(!host||!form)return;
 const ticket=(readAttendanceReport.ticket||0)+1;readAttendanceReport.ticket=ticket;readAttendanceReport.controller?.abort();const controller=new AbortController();readAttendanceReport.controller=controller;
 const buttons=[...form.querySelectorAll('button'),...host.querySelectorAll('button')];buttons.forEach(b=>b.disabled=true);host.setAttribute('aria-busy','true');
 let status=host.querySelector('.report-loading');if(!status){status=document.createElement('p');status.className='report-loading subtle';host.prepend(status);}status.textContent='正在读取原始考勤记录…';
 try{const data=await request('/workshop/attendance/report?'+new URLSearchParams({week,user_id:String(user),page:String(page)}),{signal:controller.signal});if(!host.isConnected||readAttendanceReport.ticket!==ticket)return;host.innerHTML=attendanceReportRows(data);host.dataset.week=data.start;host.dataset.user=String(data.user_id);}
 catch(error){if(host.isConnected&&readAttendanceReport.ticket===ticket)host.innerHTML=`<p role="alert">${esc(error.message)}</p><p class="subtle">请重新查询，不会修改已有考勤。</p>`;}
 finally{if(host.isConnected&&readAttendanceReport.ticket===ticket){host.setAttribute('aria-busy','false');form.querySelector('button').disabled=false;}}
}
document.addEventListener('submit',event=>{const form=event.target;if(form.id!=='attendance-report-query')return;event.preventDefault();void readAttendanceReport(form.elements.week.value,form.elements.user_id.value);});
function attendanceWeeklyView(a){
 const duration=seconds=>seconds===null?'暂不汇总':`${Math.floor(seconds/3600)}小时${Math.floor(seconds%3600/60)}分`;
 return (a.weekly_summaries||[]).map((w,index)=>`<section class="panel attendance-panel"><div class="section-head"><div><h2><i></i>${index===0?'本周记录汇总':'上周记录汇总'}</h2><p class="subtle">${esc(w.start)} 至 ${esc(w.end)} · 北京时间</p></div><strong>${duration(w.seconds)}</strong></div><p class="subtle">仅汇总已完成签到与签退的实际时段；未签退与顺序异常不计时长。跨日时段按每天拆分，不代表考勤达标。</p>${!w.complete?'<p role="alert">记录超过单次读取上限，时长暂不汇总，请联系管理员核对。</p>':''}<div class="table-scroll"><table><thead><tr><th>日期</th><th>签到记录</th><th>完整时段时长</th><th>异常</th></tr></thead><tbody>${w.days.map(d=>`<tr><td>${esc(d.date)}</td><td>${d.sign_ins}</td><td>${duration(d.seconds)}</td><td>${d.issues.length?esc(d.issues.join('；')):'—'}</td></tr>`).join('')}</tbody></table></div></section>`).join('');
}
function attendanceCorrectionsView(a){
 const names={pending:'待审核',processing:'同步待核对',approved:'已通过',rejected:'已退回'};
 return `<section class="panel attendance-panel"><div class="section-head"><h2><i></i>${a.can_review?'补正申请与审核':'我的补正申请'}</h2></div><p class="subtle">申请人填写实际签退时间和原因，由另一位老师或总负责人核实。审核通过后追加记录，原始签到保留。</p><div class="correction-list">${(a.corrections||[]).map(c=>`<article class="correction-item"><div class="section-head"><strong>${esc(c.name)}</strong><span class="badge">${names[c.status]||esc(c.status)}</span></div><p>签到：${esc(c.source_time)}<br>申请签退：${esc(c.requested_time)}</p><p class="pre">${esc(c.reason)}</p>${c.review_comment?`<p class="subtle">审核人：${esc(c.reviewer_name)}<br>意见：${esc(c.review_comment)}</p>`:''}${a.can_review&&c.user_id!==state.actor.id&&['pending','processing'].includes(c.status)?`<button data-correction-review="${c.id}" ${c.status==='processing'&&c.reviewer_id!==state.actor.id?'disabled':''}>${c.status==='processing'?'重试并核对同步':'审核申请'}</button>`:a.can_review&&c.user_id===state.actor.id&&c.status==='pending'?'<p class="subtle">本人申请需由另一位老师或总负责人审核。</p>':''}</article>`).join('')||'<p class="empty">暂无补正申请。</p>'}</div></section>`;
}
function requestCorrectionForm(){
 const source=attendanceState?.correction_source;if(!source)throw new Error('当前没有可申请的跨日漏签退，请刷新后核对。');
 modal('申请补签退',`<p>原始签到：${esc(source.time)}（北京时间）</p><p class="subtle">请填写实际离开时间，不能填写未来时间。记录需审核，不能直接解除异常。</p><form id="attendance-correction-form">${hidden('source_id',source.id)}${field('requested_time','实际签退时间（北京时间）','datetime-local','','required')}${area('reason','漏签原因与核实依据','','required maxlength="1000"')}<button type="submit" class="primary">提交补正申请</button><p class="form-status" role="status"></p></form>`);
 try{const saved=JSON.parse(sessionStorage.getItem(prefix()+'correction-draft:'+source.id)||'null');if(saved){const f=document.querySelector('#attendance-correction-form');f.elements.requested_time.value=saved.requested_time||'';f.elements.reason.value=saved.reason||'';}}catch{}
}
function reviewCorrectionForm(id){
 const c=attendanceState?.corrections?.find(c=>c.id===id);if(!c)throw new Error('申请已变化，请刷新后重试。');
 modal('审核补签退申请',`<p>${esc(c.name)} · 签到 ${esc(c.source_time)}<br>申请签退 ${esc(c.requested_time)}</p><p class="pre">${esc(c.reason)}</p><form id="attendance-review-form">${hidden('id',id)}${c.status==='processing'?hidden('decision','approve'):`<label>审核结果<select name="decision"><option value="approve">通过并追加签退记录</option><option value="reject">退回申请</option></select></label>`}${area('comment','核实说明 / 退回原因',c.review_comment||'','required maxlength="1000"'+(c.status==='processing'?' readonly':''))}<button type="submit" class="primary">${c.status==='processing'?'核对并完成同步':'确认审核'}</button><p class="form-status" role="status"></p></form>`);
}
document.addEventListener('click',event=>{const b=event.target.closest('button');if(!b)return;try{if(b.dataset.correctionRequest)requestCorrectionForm();if(b.dataset.correctionReview)reviewCorrectionForm(+b.dataset.correctionReview);}catch(error){message(error.message,true);}});
document.addEventListener('input',event=>{const f=event.target.closest('#attendance-correction-form');if(!f)return;try{sessionStorage.setItem(prefix()+'correction-draft:'+f.elements.source_id.value,JSON.stringify({requested_time:f.elements.requested_time.value,reason:f.elements.reason.value}));}catch{}});
document.addEventListener('submit',async event=>{
 const form=event.target;if(!['attendance-correction-form','attendance-review-form'].includes(form.id))return;event.preventDefault();if(form.dataset.busy)return;form.dataset.busy='true';const b=form.querySelector('button'),status=form.querySelector('[role=status]');b.disabled=true;status.textContent='正在保存，请稍候…';
 try{
  const data=Object.fromEntries(new FormData(form));let headers={'Content-Type':'application/json'};
  if(form.id==='attendance-correction-form'){
   const keyName=prefix()+'correction-operation:'+data.source_id,signature=JSON.stringify(data);let pending;try{pending=JSON.parse(sessionStorage.getItem(keyName)||'null');}catch{}
   if(!pending||pending.signature!==signature)pending={key:crypto.randomUUID(),signature};sessionStorage.setItem(keyName,JSON.stringify(pending));headers['Idempotency-Key']=pending.key;
  }else data.id=+data.id;
  const result=await request('/workshop/attendance/corrections'+(form.id==='attendance-review-form'?'/review':''),{method:'POST',timeoutMs:20000,headers,body:JSON.stringify(data)});
  if(data.source_id){sessionStorage.removeItem(prefix()+'correction-draft:'+data.source_id);sessionStorage.removeItem(prefix()+'correction-operation:'+data.source_id);}
  closeModal();await load();message(result.message);
 }catch(error){status.textContent=error.message;message(error.message,true);}finally{b.disabled=false;delete form.dataset.busy;}
});
async function recordAttendance(kind){
 if(attendanceBusy)return;attendanceBusy=true;
 let pending=attendancePending();if(pending&&pending.event_type!==kind){attendanceBusy=false;message('请先核对上一次考勤操作。',true);return;}
 if(!pending)pending={event_type:kind,key:crypto.randomUUID()};attendancePendingMemory=pending;
 try{sessionStorage.setItem(prefix()+'attendance-pending',JSON.stringify(pending));}catch{}
 render();
 try{
  const result=await request('/workshop/attendance',{method:'POST',timeoutMs:60000,headers:{'Content-Type':'application/json','Idempotency-Key':pending.key},body:JSON.stringify({event_type:kind})});
  attendancePendingMemory=null;try{sessionStorage.removeItem(prefix()+'attendance-pending');}catch{}
  message(result.message);await load();
 }catch(error){
  if(error.confirmed&&[403,409,419,422].includes(error.status)){attendancePendingMemory=null;try{sessionStorage.removeItem(prefix()+'attendance-pending');}catch{}}
  message(error.message,true);
 }finally{attendanceBusy=false;if(view==='attendance')render();}
}

const knowledgeAnswers=new Map(),knowledgeDrafts=new Map();
const knowledgeLibraries=new Map(),knowledgeUploadKeys=new Map(),knowledgeReplacements=new Map();
async function loadKnowledgeLibrary(project,refresh=false){
 if(!project||(!refresh&&knowledgeLibraries.has(project)))return;
 const previous=knowledgeLibraries.get(project);if(!refresh)knowledgeLibraries.set(project,{loading:true});
 try{const next=await request('/workshop/knowledge/library?project_id='+project);if((previous?.revision!==undefined&&previous.revision!==next.revision)||(knowledgeAnswers.get(project)||[]).some(a=>a.library_revision!==(next.revision||null)))knowledgeAnswers.delete(project);knowledgeLibraries.set(project,next);}catch(error){knowledgeLibraries.set(project,{error:error.message});}
 if(view==='knowledge'&&knowledgeProject===project)render();
}
function knowledgeLibraryView(project){
 if(!project)return '';const replacing=knowledgeReplacements.get(project);const lib=knowledgeLibraries.get(project);if(!lib){loadKnowledgeLibrary(project);return '<p class="subtle">正在读取已发布资料…</p>';}
 if(lib.loading)return '<p class="subtle">正在读取已发布资料…</p>';
 if(lib.error)return `<p role="alert">${esc(lib.error)}</p><button data-knowledge-library-refresh="${project}">重试读取资料</button>`;
 return `<section class="panel" id="knowledge-library"><div class="section-head"><h2><i></i>本项目问答资料</h2><span class="badge">${lib.status==='ready'?'索引已就绪':lib.status==='pending'?'同步待核对':'尚未发布资料'}</span></div><p class="subtle">这里发布的资料供本项目全体成员检索。个人文件、仅分享给部分人的资料不会自动入库。上传或撤回后会核对索引，未确认前暂停问答。</p><div class="correction-list">${(lib.sources||[]).map(d=>`<article class="correction-item"><div class="section-head"><strong>${esc(d.title)}</strong><span>${d.status==='active'?'已发布':'已撤回'} · ${Math.ceil(d.bytes/1024)}KB</span></div>${d.status==='active'?`<div class="row-actions"><a class="button" href="${base}/workshop/knowledge/file/${d.id}">下载原件</a>${lib.can_publish?`<button data-knowledge-replace="${d.id}" data-kb-project="${project}" data-revision="${lib.revision}">替换为新版本</button><button data-knowledge-withdraw="${d.id}" data-kb-project="${project}" data-revision="${lib.revision}">撤回问答资料</button>`:''}</div>`:''}</article>`).join('')||'<p class="empty">尚无正式发布资料；旧的虚构示例仅供测试。</p>'}</div>${lib.can_publish?`<form id="knowledge-publish">${replacing?`<p>正在替换资料 #${replacing.id}；新版本就绪后，旧版本不再参与问答。<button type="button" data-knowledge-cancel-replace="${project}">取消替换</button></p>`:''}<label>发布项目资料（每份≤5MB，最多20份；含历史版本额度${Math.floor((lib.storage_limit_bytes||104857600)/1048576)}MB，已用${Math.ceil((lib.storage_used_bytes||0)/1024)}KB）<input type="file" name="file" accept=".pdf,.docx,.txt,.md" required></label><label><input type="checkbox" name="shared_with_project" required> 我确认这份资料可供本项目全体成员检索，不包含仅部分成员可见的内容。</label><button type="submit" class="primary">上传并发布到本项目问答</button><p role="status" class="form-status"></p></form>${lib.status==='pending'?`<button data-knowledge-sync="${project}">重试同步并核对索引</button>`:''}`:'<p class="subtle">由本项目组长、老师或总负责人维护问答资料。</p>'}</section>`;
}
function knowledgeView(){
 const project=state.projects.find(p=>+p.project_id===knowledgeProject);
 const library=knowledgeLibraries.get(knowledgeProject);const enabled=project&&(library?.status==='pending'?false:(library?.status==='ready'||(state.knowledge_projects||[]).map(Number).includes(knowledgeProject)));
 const answers=knowledgeAnswers.get(knowledgeProject)||[];
 return `<section class="panel knowledge-panel"><div class="section-head"><h2>项目资料问答</h2><label class="knowledge-project-label" for="knowledge-project">当前项目<select id="knowledge-project" aria-label="问答项目"><option value="0">请选择项目</option>${state.projects.map(p=>`<option value="${+p.project_id}" ${+p.project_id===knowledgeProject?'selected':''}>${esc(p.name)}</option>`).join('')}</select></label></div><p class="subtle">只检索当前项目已接入的资料；回答附资料摘录，依据不足时会明确说明。</p>${project?'<a class="knowledge-manage" href="#knowledge-library">查看和管理问答资料 →</a>':''}
 ${!project?'<p class="empty">先选择一个你有权访问的项目。</p>':!enabled?'<p class="empty">这个项目尚未发布资料或正在核对索引。请在上方查看资料状态；由组长、老师或总负责人发布项目资料。</p>':`<div class="knowledge-answers" aria-live="polite">${answers.length?answers.map(a=>`<article class="knowledge-answer"><div class="knowledge-user-question"><span class="knowledge-speaker">你的问题</span><p>${esc(a.question)}</p></div><div class="knowledge-response"><strong class="knowledge-speaker">智能知识助手</strong>${a.library_revision?`<p class="subtle">依据项目资料版本 ${a.library_revision}</p>`:''}<p class="pre">${esc(a.answer)}</p>${a.sources.length?`<details><summary>查看 ${a.sources.length} 条资料来源</summary>${a.sources.map(x=>`<section><strong>${esc(x.title)}</strong><p class="pre">${esc(x.excerpt||'该来源未提供可展示的摘录。')}</p></section>`).join('')}</details>`:''}</div></article>`).join(''):'<p class="empty">可以询问本项目的组会安排、操作说明或提交要求。当前示例资料属于虚构试用规则。</p>'}</div><form id="knowledge-question"><label for="knowledge-question-text">你的问题</label><textarea id="knowledge-question-text" name="question" required maxlength="1500" rows="3" placeholder="输入有关项目资料的问题…">${esc(knowledgeDrafts.get(knowledgeProject)||'')}</textarea><div class="row-actions"><button class="primary" type="submit" ${knowledgeBusy?'disabled':''}>${knowledgeBusy?'正在查阅资料…':'发送'}</button><span role="status" class="subtle">回答用于辅助查阅，正式规则以资料原文为准。</span></div></form>`}</section>${knowledgeLibraryView(project?knowledgeProject:0)}`;
}

function overviewView(){
 return `${metricsView()}<div class="overview-columns"><div><section class="panel"><div class="section-head"><div><h2><i></i>项目进展</h2><p class="subtle">当前阶段、完成情况与下一交付节点</p></div><button class="quiet" data-view="projects">全部项目 →</button></div><div class="project-summary-list">${state.projects.map(p=>{const x=projectStat(p);return `<button class="project-summary" data-project="${p.project_id}"><div class="project-summary-title"><span class="project-initial">${esc(p.name.slice(0,1))}</span><div><strong>${esc(p.name)}</strong><small>${esc(leaderNames(p))} · ${esc(p.stage)}</small></div><span class="risk ${+x.overdue||+x.blocked?'risk-warning':''}">${projectRisk(p)}</span></div><div class="progress-line"><progress max="100" value="${projectProgress(p)}" aria-label="${esc(p.name)}任务完成率"></progress><small>${x.done} / ${x.active_total||0} 已完成（不含取消）</small></div><div class="summary-footer"><span>${projectPeople(p).length} 位成员</span><span>下一截止 ${x.next_due?date(x.next_due):'未安排'}</span></div></button>`;}).join('')||'<p class="empty">还没有项目，入组后会显示这里的进展。</p>'}</div></section>${timelineView(true)}</div><aside class="overview-aside"><section class="panel"><div class="section-head"><h2><i></i>需要关注</h2><span class="count-pill">${state.overview.attention.length}</span></div><p class="subtle">优先查看阻塞、逾期和待验收事项</p><div class="attention-list">${state.overview.attention.map(t=>`<button class="attention-item" data-task="${t.id}"><span class="attention-type">${+t.status===1?'阻塞 · 需要支持':+t.status===2?'等待成果验收':'逾期 · 请跟进'}</span><strong>${esc(t.headline)}</strong><small>${esc(t.project_name)}</small>${t.support_needed?`<p>${esc(t.support_needed)}</p>`:''}</button>`).join('')||'<p class="empty">目前没有需要额外关注的事项。</p>'}</div></section><section class="panel"><h2><i></i>近期成果</h2><div class="recent-list">${state.overview.recent.map(t=>`<button class="recent-item" data-task="${t.id}"><span class="complete-dot" aria-label="已完成">√</span><div><strong>${esc(t.headline)}</strong><small>${esc(t.project_name)}<br>${date(t.created_at)} 验收通过</small></div></button>`).join('')||'<p class="empty">验收通过的成果将在这里展示。</p>'}</div></section></aside></div>`;
}
const projectSpaceBusy=new Set();
function projectSpacePanel(data){
 if(data.status==='ready')return `<p class="subtle" role="status">${data.origin==='legacy'?'已有群聊与共享资料已核对接通；文件和原有权限保持不变。':'项目私有聊天与共享资料已就绪；按项目组授权访问。'}</p><div class="row-actions"><a class="button" data-collaboration="chat" href="${esc(collaboration+data.chat_url)}">进入本项目聊天</a><a class="button" data-collaboration="files" href="${esc(collaboration+data.files_url)}">打开本项目资料</a>${data.can_audit?`<button data-audit-project-space="${selected}">只读核对共享权限</button>`:''}</div><div class="project-access-audit" role="status"></div>`;
 if(data.status==='legacy')return `<p class="subtle" role="status">本项目已登记项目组，专属聊天与资料入口尚未核对。可进入模块查看已有资源，或由维护管理员核对接通。</p><div class="row-actions"><a class="button" data-collaboration="chat" href="${esc(collaboration)}/apps/spreed/">进入消息模块</a><a class="button" data-collaboration="files" href="${esc(collaboration)}/apps/files/">进入资料模块</a>${data.can_prepare?'<button data-action="register-legacy-space">核对并接通已有空间</button>':''}</div>`;
 return `<p class="subtle" role="status">${data.status==='pending'?'空间创建进度已保留，尚未核对完成。重试会先核对已有结果，不能手工重复建群。':'项目已保存，专属聊天与资料空间尚未建置。'}</p>${data.can_prepare?`<button data-prepare-project-space="${selected}">${data.status==='pending'?'继续并核对项目空间':'建立项目聊天与共享资料'}</button>`:'<p class="subtle">请联系账号维护管理员完成建置。</p>'}`;
}
async function loadProjectSpace(){
 const host=document.querySelector('#project-space'),project=selected;if(!host||!project)return;
 try{const data=await request('/workshop/project-space?project_id='+project);if(host.isConnected&&selected===project)host.innerHTML=projectSpacePanel(data);}
 catch(error){if(host.isConnected)host.textContent=error.message;}
}
function projectsView(){
 if(selected){const p=state.projects.find(p=>+p.project_id===selected);if(!p)return '<p class="empty">项目不可访问。</p>';
 return `<section class="panel project-profile"><div class="section-head"><div><span class="eyebrow">项目档案</span><h2>${esc(p.name)}</h2></div><div class="head-actions"><button data-action="all-projects">← 全部项目</button>${canLead(selected)&&!p.archived_at?'<button data-action="edit-project">维护阶段目标</button>':''}${state.manager?`<button data-action="archive">${p.archived_at?'重新开放':'归档项目'}</button>`:''}</div></div><p class="pre">${esc(p.details||'暂无项目介绍')}</p><div class="project-facts"><div><small>当前阶段</small><strong>${esc(p.stage)}</strong></div><div><small>组长</small><strong>${esc(leaderNames(p))}</strong></div><div><small>状态</small><strong>${projectRisk(p)}</strong></div><div><small>任务完成率</small><strong>${projectProgress(p)}%</strong></div></div><h3>阶段目标</h3><p class="pre">${esc(p.goal||'待维护')}</p><h3>项目成员</h3><div class="member-chips">${projectPeople(p).map(m=>`<span>${esc(m.name)}<small>${m.role==='leader'?'组长':'组员'}</small></span>`).join('')||'<span>尚未分配成员</span>'}</div><div class="row-actions project-quick-actions"><button class="primary" data-view="tasks">查看项目任务</button><button data-view="timeline">查看项目日历</button><button data-view="reviews">查看待验收成果</button>${collaboration?`<a class="button" data-collaboration="meetings" href="${esc(collaboration)}/apps/collectives/">组会记录</a>`:''}</div>${collaboration?'<div id="project-space" class="project-space"><p class="subtle" role="status">正在核对项目协作空间…</p></div>':''}</section>`;}
 return `<section class="project-directory">${state.projects.map(p=>{const x=projectStat(p);return `<button class="project-card" data-project="${p.project_id}"><div class="section-head"><span class="project-initial">${esc(p.name.slice(0,1))}</span><span class="risk">${projectRisk(p)}</span></div><h2>${esc(p.name)}</h2><p>${esc(p.details||'项目介绍待维护')}</p><div class="directory-stage"><small>当前阶段</small><strong>${esc(p.stage)}</strong></div><p>${esc(p.goal||'阶段目标待维护')}</p><progress value="${projectProgress(p)}" max="100" aria-label="任务完成率"></progress><div class="summary-footer"><span>${esc(leaderNames(p))}</span><span>${projectPeople(p).length}人 · ${x.total}项任务</span></div><span class="text-link">进入项目 →</span></button>`;}).join('')||'<section class="panel empty">暂无项目。管理员可以建立项目并分配成员。</section>'}</section>`;
}
function timelineState(t){return +t.status===0?'done':+t.status===1?'blocked':+t.status===2?'review':new Date(t.dateToFinish.replace(' ','T')+'Z')<new Date()?'overdue':+t.status===3?'new':'progress';}
const timelineKinds={new:'待开展',progress:'进行中',review:'待验收',done:'已完成',blocked:'已阻塞',overdue:'已逾期'};
let calendarDate=new Date();
function timelineView(overview=false){
 return `<section class="panel calendar-panel"><div class="section-head"><div><h2>项目日历</h2><p class="subtle">按截止日期查看交付安排，点击任务查看详情</p></div><div class="head-actions">${overview?'<button class="quiet" data-view="timeline">展开日历 →</button>':`<select id="project-filter" aria-label="日历项目筛选"><option value="0">全部项目</option>${projectOptions()}</select>`}</div></div><div class="calendar-toolbar"><div class="head-actions"><button data-action="calendar-prev" aria-label="上一周期">‹</button><button data-action="calendar-next" aria-label="下一周期">›</button><button data-action="calendar-today">今天</button><strong id="calendar-range" aria-live="polite"></strong></div><div class="task-filters" role="group" aria-label="日历视图">${[['day','日'],['week','周'],['month','月']].map(([k,v])=>`<button data-calendar-mode="${k}" aria-pressed="${chartMode===k}">${v}</button>`).join('')}</div></div><div id="workshop-calendar" aria-label="项目任务日历"></div><p class="subtle calendar-note">显示已授权项目最近30天至未来120天内有截止日期的任务（最多100项）。未设置截止日期的任务请在项目任务中查看；改期通过任务详情保存。</p></section>`;
}
function timelineTasks(){return state.overview.timeline.filter(t=>!selected||+t.projectId===selected).slice(0,100);}
function updateCalendarRange(){const chart=renderTimeline.chart;if(!chart)return;calendarDate=chart.getDate().toDate();const node=document.querySelector('#calendar-range');if(node)node.textContent=chartMode==='month'?calendarDate.toLocaleDateString('zh-CN',{year:'numeric',month:'long'}):chart.getDateRangeStart().toDate().toLocaleDateString('zh-CN')+' — '+chart.getDateRangeEnd().toDate().toLocaleDateString('zh-CN');}
let calendarAssetsPromise;const calendarAssetReady={};
function ensureCalendarAssets(){
 if(calendarAssetsPromise)return calendarAssetsPromise;
 const asset=(kind)=>new Promise((resolve,reject)=>{
  if(calendarAssetReady[kind]||kind==='js'&&window.tui?.Calendar){resolve();return;}
  const raw=document.querySelector('meta[name="workshop-calendar-'+kind+'"]')?.content;
  const url=new URL(raw||'',location.href),expected=new URL(base+'/workshop-assets/vendor/calendar/toastui-calendar.min.'+kind,location.href);
  if(!raw||url.origin!==expected.origin||url.pathname!==expected.pathname){reject(new Error('Calendar asset configuration invalid'));return;}
  const node=document.createElement(kind==='js'?'script':'link');
  const finish=error=>{clearTimeout(timer);node.onload=null;node.onerror=null;if(error){node.remove();reject(error);}else resolve();};
  const timer=setTimeout(()=>finish(new Error('Calendar asset timed out')),20000);
  node.onload=()=>{if(kind==='js'&&!window.tui?.Calendar){finish(new Error('Calendar did not initialize'));return;}calendarAssetReady[kind]=true;finish();};node.onerror=()=>finish(new Error('Calendar asset unavailable'));
  if(kind==='js'){node.src=url.href;node.async=true;}else{node.rel='stylesheet';node.href=url.href;}
  document.head.append(node);
 });
 calendarAssetsPromise=Promise.all([asset('css'),asset('js')]).then(()=>{if(!window.tui?.Calendar)throw new Error('Calendar did not initialize');}).catch(error=>{calendarAssetsPromise=null;throw error;});
 return calendarAssetsPromise;
}
async function renderTimeline(){
 const ticket=(renderTimeline.ticket||0)+1;renderTimeline.ticket=ticket;
 renderTimeline.chart?.destroy();renderTimeline.chart=null;
 const el=document.querySelector('#workshop-calendar');if(!el)return;
 const panel=el.closest('.calendar-panel'),controls=panel.querySelectorAll('[data-calendar-mode],[data-action^="calendar-"]');
 controls.forEach(button=>button.disabled=true);el.setAttribute('aria-busy','true');el.textContent='正在载入项目日历…';
 try{
  await ensureCalendarAssets();
  if(ticket!==renderTimeline.ticket||!el.isConnected||document.querySelector('#workshop-calendar')!==el)return;
  el.replaceChildren();
 const dark=document.documentElement.dataset.theme==='dark'||theme==='dark',bg=dark?'#121617':'#ffffff',text=dark?'#ecf0f1':'#243039',line=dark?'#293033':'#e1e7e9',soft=dark?'#191e20':'#f6f8f9';
 const dayNames=['日','一','二','三','四','五','六'];
 const chart=new window.tui.Calendar(el,{defaultView:chartMode,isReadOnly:true,useFormPopup:false,useDetailPopup:false,usageStatistics:false,gridSelection:false,week:{dayNames,startDayOfWeek:1,taskView:false,eventView:true},month:{dayNames,startDayOfWeek:1},theme:{common:{backgroundColor:bg,border:'1px solid '+line,dayName:{color:text},today:{color:'#fff'},saturday:{color:text},holiday:{color:dark?'#ee8989':'#b83d3d'}},month:{dayName:{backgroundColor:bg},weekend:{backgroundColor:soft},dayExceptThisMonth:{color:dark?'#66757f':'#abb4bb'}},week:{dayName:{color:text,backgroundColor:bg},timeGrid:{borderRight:'1px solid '+line},timeGridHalfHour:{borderBottom:'1px dotted '+line}}},calendars:[{id:'tasks',name:'项目任务',backgroundColor:dark?'#245e4e':'#dff1e9',borderColor:'#279875',color:text}],template:{allday:event=>esc(event.title),time:event=>esc(event.title),monthGridHeaderExceed:count=>'＋ '+count+' 项'}});
 renderTimeline.chart=chart;chart.setDate(calendarDate);
 chart.createEvents(timelineTasks().map(t=>({id:String(t.id),calendarId:'tasks',title:t.headline,category:'allday',isAllday:true,start:t.dateToFinish.replace(' ','T'),end:t.dateToFinish.replace(' ','T'),isReadOnly:true,backgroundColor:+t.status===0?(dark?'#285641':'#dcefe4'):+t.status===2?(dark?'#484066':'#eae3f6'):undefined,color:text,raw:{project:t.project_name}})));
 chart.on('clickEvent',({event})=>showTask(Number(event.id)).catch(e=>message(e.message,true)));updateCalendarRange();
  controls.forEach(button=>button.disabled=false);
 }catch{
  if(ticket!==renderTimeline.ticket||!el.isConnected)return;
  el.replaceChildren();const status=document.createElement('p');status.setAttribute('role','status');status.textContent='项目日历暂未载入，任务数据仍然保留；可以重试或先查看项目任务。';
  const retry=document.createElement('button');retry.type='button';retry.dataset.action='calendar-retry';retry.textContent='重试载入日历';el.append(status,retry);
 }finally{if(el.isConnected)el.setAttribute('aria-busy','false');}
}

function meetingTaskGuide(){
 if(view!=='tasks'||!meetingSource)return '';
 const project=state.projects.find(p=>+p.project_id===selected),allowed=project&&!project.archived_at&&canLead(selected);
 return `<section class="panel"><h2>将组会待办建立为任务</h2><p class="subtle">先在下方选择待办所属项目，再填写责任人、截止时间和验收要求。已有任务请在下方搜索并点击“关联此任务”，避免重复建立。这里只保存来源链接，不读取会议正文或改变共享权限。</p><div class="row-actions"><button class="primary" data-action="meeting-task" ${allowed?'':'disabled'}>新建组会待办</button><button data-filter="meeting">查看本组会已关联任务</button><button data-action="dismiss-meeting-source">取消本次转任务</button></div>${allowed?'':'<p class="subtle">请选择你有管理权限、且尚未归档的项目；普通组员请联系本项目组长分配。</p>'}</section>`;
}
function workspaceView() {
 const project=state.projects.find(p=>+p.project_id===selected),tasks=state.tasks;
 return `${meetingTaskGuide()}<section class="panel task-workspace"><div class="section-head"><div><h2><i></i>${view==='reviews'?'待验收成果':view==='mine'?'我负责的任务':search?'搜索结果':filterTitles[taskFilter]}</h2><p class="subtle">${project?esc(project.name)+(project.archived_at?' · 归档只读':''):'全部授权项目'}${search?' · '+esc(search):''}</p></div><div class="head-actions"><select id="project-filter" aria-label="筛选项目"><option value="0">全部项目</option>${projectOptions()}</select>${project&&canLead(selected)&&!project.archived_at?'<button class="primary" data-action="new-task">＋ 分配任务</button>':''}</div></div>${view!=='reviews'?`<div class="task-filters" role="group" aria-label="任务状态筛选">${Object.entries(filterTitles).filter(([key])=>key!=='meeting'||meetingSource).map(([key,label])=>`<button data-filter="${key}" aria-pressed="${taskFilter===key}">${label}</button>`).join('')}</div>`:''}<div class="table-wrap"><table><thead><tr><th>任务 / 项目</th><th>责任人</th><th>状态</th><th>截止时间</th><th>优先级</th></tr></thead><tbody>${tasks.map(t=>`<tr><td><button class="task-link" data-task="${t.id}">${esc(t.headline)}</button><small>${esc(t.project_name)}</small>${meetingSource?(t.meeting_source===meetingSource?'<small>已关联当前组会</small>':t.meeting_source?'<small>已有其他来源，请在详情核对</small>':canLead(+t.projectId)&&!state.projects.find(p=>+p.project_id===+t.projectId)?.archived_at?`<button class="quiet" data-link-meeting-task="${t.id}">关联此任务</button>`:''):''}</td><td>${esc(t.assignee_name)}</td><td>${badge(t)}</td><td>${date(t.dateToFinish)}</td><td><span class="priority priority-${t.priority}">${esc(['','紧急','高','普通','低','最低'][+t.priority]||'普通')}</span></td></tr>`).join('')||'<tr><td colspan="5" class="empty">没有符合条件的任务。</td></tr>'}</tbody></table></div><div class="pagination"><button data-action="prev" ${page===1?'disabled':''}>上一页</button><span>第 ${page} 页 · 每页最多50条</span><button data-action="next" ${!state.has_more?'disabled':''}>下一页</button></div></section>`;
}
let peopleSearch='',peopleRole='all',peopleProject=0;
function peopleMatches(p){
 const links=state.memberships.filter(m=>+m.user_id===+p.user_id&&+m.active&&(!peopleProject||+m.project_id===peopleProject));
 return (!peopleProject||links.length)&&(!peopleSearch||[p.name,p.student_no,p.email,...links.map(m=>state.projects.find(x=>+x.project_id===+m.project_id)?.name||'')].join(' ').toLocaleLowerCase().includes(peopleSearch.toLocaleLowerCase()))&&(peopleRole==='all'||peopleRole==='pending'&&p.status==='pending'||links.some(m=>m.role===peopleRole));
}
function filterPeople(){
 let count=0;document.querySelectorAll('[data-person-row]').forEach(row=>{const p=state.people.find(x=>+x.user_id===+row.dataset.personRow);row.hidden=!peopleMatches(p);if(!row.hidden)count++;});
 const status=document.querySelector('#people-count');if(status)status.textContent='找到 '+count+' 人';
 document.querySelectorAll('[data-people-role]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.peopleRole===peopleRole)));
}
let rosterCSV='',rosterPreview=null,rosterKey='';
async function rosterDialog(){
 rosterCSV='';rosterPreview=null;rosterKey='';
 modal('名单导入与核验',`<p class="subtle">可直接上传 Excel .xlsx 或 UTF-8 CSV。学号必须保存为文本以保留前导零；Excel请只保留本次名单一个工作表，公式请先粘贴为值。邮箱由学生注册时自行填写。</p><p>项目名称须与系统中的项目完全一致；也兼容旧模板的项目编号列。每行一个项目关系；同一学号可有多行、分别担任组长或组员。缺席名单的既有成员不会被删除或停用。首次导入后，新注册和待审核账号必须匹配名单；请先准备好本批入组人员。</p><div class="row-actions"><button id="roster-template">下载空白模板</button><button id="roster-current">查看已导入名单</button></div><details><summary>可用项目编号</summary><ul>${state.projects.filter(p=>!p.archived_at).map(p=>`<li>${+p.project_id}：${esc(p.name)}</li>`).join('')||'<li>请先在项目中心建立项目。</li>'}</ul></details><form id="roster-form"><label>选择 Excel / CSV 名单<input id="roster-file" type="file" accept=".xlsx,.csv,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet,text/csv" required></label><button type="submit" class="primary">预检名单</button><p role="status" id="roster-status"></p></form><div id="roster-results"></div><label><input type="checkbox" id="roster-sync-existing"> 同时按本次名单更新已完成审核成员的项目角色（仅本表列出的项目，不会移除其他项目）</label><div class="row-actions"><button id="roster-commit" class="primary" hidden>确认导入名单</button></div><p class="subtle">导入不代表身份核验通过，也不授予老师或总负责人权限。新成员须验证邮箱并接受管理员身份审核；审核通过后按名单入组。勾选同步后可更新本表已审核账号的项目角色；消息与资料权限开通尚未自动同步。</p>`);
}
function rosterTable(rows,preview=false){return `<ul class="roster-mobile">${rows.map(r=>`<li><strong>${esc(r.name)}</strong><small>${esc(r.student_no)}</small><p>${esc(r.project_name)}（${+r.project_id}） · ${r.role==='leader'?'组长':r.role==='member'?'组员':'无效角色'}</p>${preview?`<p>${r.errors.length?esc('第'+r.line+'行：'+r.errors.join('；')):({new:'新增',update:'更新名单',unchanged:'无变化'}[r.change])}</p>`:''}</li>`).join('')||'<li>尚未导入名单。</li>'}</ul><div class="table-wrap roster-table"><table><thead><tr><th>学号</th><th>姓名</th><th>项目</th><th>角色</th>${preview?'<th>预检结果</th>':''}</tr></thead><tbody>${rows.map(r=>`<tr><td>${esc(r.student_no)}</td><td>${esc(r.name)}</td><td>${esc(r.project_name)}<small>编号 ${+r.project_id}</small></td><td>${r.role==='leader'?'组长':r.role==='member'?'组员':'无效角色'}</td>${preview?`<td>${r.errors.length?esc('第'+r.line+'行：'+r.errors.join('；')):({new:'新增',update:'更新名单',unchanged:'无变化'}[r.change])}</td>`:''}</tr>`).join('')||'<tr><td colspan="5">尚未导入名单。</td></tr>'}</tbody></table></div>`;}
document.addEventListener('click',async e=>{
 const id=e.target.closest('button')?.id;
 if(!['roster-template','roster-current','roster-commit'].includes(id))return;
 const status=document.querySelector('#roster-status'),button=e.target.closest('button');
 if(id==='roster-template'){
  const blob=new Blob(['\ufeff学号,姓名,项目名称,项目角色\r\n'],{type:'text/csv;charset=utf-8'}),url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='工坊名单模板.csv';a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);return;
 }
 button.disabled=true;
 try{
  if(id==='roster-current'){const result=await request('/workshop/roster');document.querySelector('#roster-results').innerHTML=`<p>已导入 ${result.people} 人、${result.total} 条项目关系${result.total>1000?'，以下展示前1000条':''}。</p>`+rosterTable(result.rows);document.querySelector('#roster-commit').hidden=true;rosterPreview=null;return;}
  if(!rosterPreview?.valid)throw new Error('请先预检名单。');
  status.textContent='正在保存名单…';
  const result=await request('/workshop/action',{method:'POST',headers:{'Content-Type':'application/json','Idempotency-Key':rosterKey},body:JSON.stringify({action:'import_roster',data:{csv:rosterCSV,digest:rosterPreview.digest,sync_existing:!!document.querySelector('#roster-sync-existing')?.checked}})});
  status.textContent=result.message;message(result.message);button.hidden=true;rosterPreview=null;
 }catch(error){status.textContent=error.message;message(error.message,true);}finally{button.disabled=false;}
});
document.addEventListener('change',e=>{if(e.target.id==='roster-file'){rosterPreview=null;rosterCSV='';document.querySelector('#roster-commit').hidden=true;document.querySelector('#roster-results').replaceChildren();document.querySelector('#roster-status').textContent='已更换文件，请重新预检。';}});
document.addEventListener('submit',async e=>{
 if(e.target.id!=='roster-form')return;e.preventDefault();const button=e.target.querySelector('button'),status=document.querySelector('#roster-status'),file=document.querySelector('#roster-file').files[0];if(button.disabled)return;button.disabled=true;document.querySelector('#roster-commit').hidden=true;rosterPreview=null;
 try{
  const ext=file?.name.toLowerCase().split('.').pop();if(!file||!['csv','xlsx'].includes(ext)||file.size>(ext==='xlsx'?2097152:1048576))throw new Error('请选择2MB以内的 .xlsx，或1MB以内的 UTF-8 CSV。');
  status.textContent='正在解析并预检，尚未写入名单…';const upload=new FormData();upload.append('file',file);
  rosterPreview=await request('/workshop/roster/preview',{method:'POST',body:upload});rosterCSV=rosterPreview.normalized_csv;rosterKey=crypto.randomUUID();
  const r=rosterPreview;status.textContent=r.valid?`预检通过：${r.people} 人，新增 ${r.counts.new}、更新 ${r.counts.update}、不变 ${r.counts.unchanged} 条；其中 ${r.rows.filter(x=>x.sync_eligible).length} 条可同步到已审核账号。请确认后导入。`:`发现 ${r.errors.length} 行错误，请修正文件并重新预检，当前未写入。`;
  document.querySelector('#roster-results').innerHTML=rosterTable(r.rows,true);document.querySelector('#roster-commit').hidden=!r.valid;
 }catch(error){status.textContent=error instanceof TypeError?'文件编码不正确，请在 Excel 中另存为 CSV UTF-8。':error.message;}finally{button.disabled=false;}
});
function enrollmentActions(p){
 if(!state.actor.owner)return '';const uncertain=['creating','creation_uncertain'].includes(p.enrollment_status);
 const open=p.status==='approved'&&p.email_verified_at&&(!p.collaboration_bound||(p.enrollment_status&&p.enrollment_status!=='ready'));
 return (open?`<button data-open-unified-account="${+p.user_id}" ${uncertain||(state.workspace.test_mail&&!p.enrollment_status)?'disabled':''} title="${uncertain?'创建结果待维护人员核对，不能重复建号':state.workspace.test_mail?'正式发信尚未配置；不会创建收不到邀请的账号':'复用现有统一登录账号服务开通'}">${uncertain?'创建结果待核对':p.enrollment_status?'继续账号开通':'开通统一账号'}</button>`:'')+(p.enrollment_status==='ready'?`<button data-resend-unified-invitation="${+p.user_id}" ${state.workspace.test_mail?'disabled':''}>重发激活邀请</button>`:'');
}
function enrollmentSummary(p){const status={creating:'创建结果待核对',creation_uncertain:'创建结果待核对',created:'账号已创建，待完成绑定',awaiting_permissions:'待核对项目组权限',ready:'统一账号已开通'};return p.enrollment_status?`<small>${esc(status[p.enrollment_status]||'开通状态待核对')} · ${p.invitation_status==='accepted'?'邀请已接受发送，送达待确认':'邀请送达未确认'}</small>`:'';}
function peopleView() {
 return `<section class="panel"><div class="section-head"><div><h2>人员与项目权限</h2><p class="subtle">组长负责授权项目的管理，组员处理分配给自己的任务。一个人可在不同项目担任不同角色。</p></div><div class="row-actions"><button data-action="roster">导入 / 查看名单</button><button data-enrollment-readiness>检查账号开通准备</button><a class="button" href="${base}/workshop/register" target="_blank" rel="noopener">学生注册页 ↗</a></div></div>
 ${state.workspace.test_mail?'<p class="subtle" role="status">当前为本机试用，验证邮件尚未发送到邮箱。请先配置发信服务，再开放正式注册。</p>':''}
 <div id="enrollment-readiness" role="status" hidden></div>
 ${projectGroupQueueView()}
 <div class="head-actions people-tools"><label>搜索人员<input id="people-search" type="search" value="${esc(peopleSearch)}" placeholder="姓名、学号、邮箱或项目" aria-label="搜索人员" maxlength="100"></label><label>项目<select id="people-project"><option value="0">全部项目</option>${state.projects.map(p=>`<option value="${+p.project_id}" ${+p.project_id===peopleProject?'selected':''}>${esc(p.name)}</option>`).join('')}</select></label></div>
 <div class="task-filters" role="group" aria-label="人员角色分类">${[['all','全部人员'],['leader','项目组长'],['member','项目组员'],['pending','待审核']].map(([key,label])=>`<button data-people-role="${key}" aria-pressed="${peopleRole===key}">${label}</button>`).join('')}<span id="people-count" role="status">找到 ${state.people.filter(peopleMatches).length} 人</span></div>
 <p class="subtle">按项目分别授权；以下角色筛选不会更改权限。身份核实后才能批准入组。</p>
 <div class="table-wrap"><table><thead><tr><th>姓名 / 学号</th><th>邮箱</th><th>项目与角色</th><th>邮箱核验</th><th>消息与资料账号</th><th>入组状态</th><th>操作</th></tr></thead><tbody>${state.people.map(p=>`<tr data-person-row="${+p.user_id}" ${peopleMatches(p)?'':'hidden'}><td><strong>${esc(p.name)}</strong><small>${esc(p.student_no)}</small></td><td>${esc(p.email)}</td><td>${state.memberships.filter(m=>+m.user_id===+p.user_id&&+m.active).map(m=>`<div class="person-membership"><span>${esc(state.projects.find(x=>+x.project_id===+m.project_id)?.name||'项目')}</span><strong>${m.role==='leader'?'项目组长':'项目组员'}</strong></div>`).join('')||(p.workshop_role==='teacher'?'指导老师 · 全工坊授权':p.workshop_role==='manager'?'总负责人 · 全工坊授权':'尚未分配')}</td><td>${p.email_verified_at?'已验证':'待验证'}</td><td>${p.collaboration_bound?('已绑定 · '+({pending:'项目组权限待同步',verified:'登记项目组已核对'}[p.collaboration_group_status]||'项目组尚未核对')):'尚未开通'}${enrollmentSummary(p)}</td><td>${esc({pending:'待审核',approved:'已入组',suspended:'已停用',rejected:'未通过'}[p.status]||p.status)}</td><td><div class="row-actions">${enrollmentActions(p)}${p.status==='pending'?`<button data-approve="${+p.user_id}" ${!p.email_verified_at?'disabled':''}>核实并批准</button>`:''}${p.status==='approved'?`<button data-member="${+p.user_id}">项目与角色</button>${+p.user_id!==+state.actor.id&&(state.actor.owner||p.workshop_role==='member')?`<button class="danger quiet" data-suspend="${+p.user_id}">停用</button>`:''}`:''}${state.actor.owner&&p.collaboration_bound?`<button data-sync-project-groups="${+p.user_id}">同步项目组权限</button>`:''}${state.actor.owner&&p.status==='approved'?`<button data-person-role="${+p.user_id}">管理权限</button>`:''}</div></td></tr>`).join('')||'<tr><td colspan="7" class="empty">暂无注册申请。</td></tr>'}</tbody></table></div></section>`;
}

function auditDescription(a) {
  let before={},after={};try{before=JSON.parse(a.before_json)||{};after=JSON.parse(a.after_json)||{};}catch{return '';}
  const parts=[];
  if(a.action==='task.assignment_or_due') {
    const person=state.memberships.find(m=>+m.user_id===+after.assignee_id);
    if(person)parts.push('责任人：'+person.name);
    parts.push('截止时间：'+date(before.due)+' → '+date(after.due));
  }
  if(after.state)parts.push('状态：'+({new:'待开展',progress:'进行中',blocked:'已阻塞',cancelled:'已取消',done:'已完成',review:'待验收'}[after.state]||'已更新'));
  if(after.reason)parts.push('说明：'+after.reason);
  if(after.comment)parts.push('验收意见：'+after.comment);
  return parts.join('\n');
}
async function showTask(id) {
  const data=await readTaskForCurrentPage(id);if(!data)return;detail=data;
  const t = detail.task, s = detail.submissions[0];
  const project = state.projects.find((p)=>+p.project_id===+t.projectId);
  const readonly = !!project?.archived_at;
  const controls = readonly ? '<p class="subtle">项目已归档，当前只读。</p>' : `<div class="row-actions">${detail.can_submit&&![0,2].includes(+t.status)&&!t.cancelled?'<button class="primary" data-action="submit-form">提交成果</button>':''}${detail.can_submit?'<button data-action="progress-form">更新进度</button>':''}${detail.can_manage?'<button data-action="edit-form">调整责任人 / 期限</button>':''}${detail.can_manage&&+t.status===2&&s&&(state.manager||+s.user_id!==+state.actor.id)?'<button class="primary" data-action="review-form">验收此版本</button>':''}</div>`;
  modal(t.headline, `${badge(t)}<div class="detail-meta"><span>截止：${date(t.dateToFinish)}</span><span>原始期限：${date(t.baseline_due)}</span><span>版本 ${+t.revision}</span></div>${controls}
    ${detail.origin?.source_type==='meeting'?`<p><a class="button" data-collaboration="meetings" href="${esc(collaboration+detail.origin.source_path)}">查看来源组会</a></p><p class="subtle">来源链接由任务创建者人工确认；组会正文访问仍遵守原有权限。</p>`:''}
    <h3>任务说明</h3><p class="pre">${esc(t.description||'暂无说明')}</p><h3>验收要求</h3><p class="pre">${esc(t.acceptanceCriteria)}</p>${t.block_reason?`<h3>当前阻塞</h3><p class="pre">${esc(t.block_reason)}</p><p class="pre">需要帮助：${esc(t.support_needed||'未填写')}</p>`:''}
    <h3>成果版本与验收</h3>${detail.submissions.map((sub,i) => `<article class="submission"><div class="section-head"><strong>提交 #${+sub.id}${i===0?' · 最新版本':''}</strong><small>${esc(sub.author)} · ${date(sub.created_at)}</small></div><p class="pre">${esc(sub.content)}</p>${sub.links.map((url) => `<a class="resource" href="${esc(url)}" target="_blank" rel="noopener noreferrer">${esc(url)}</a>`).join('')}${sub.files.map((f) => `<a class="resource" href="${base}/workshop/file/${+f.id}">${esc(f.name)} ↗</a>`).join('')}
    ${sub.decision?`<div class="review"><strong>${sub.decision==='accepted'?'验收通过':'已退回'}</strong><p class="pre">${esc(sub.comment)}</p><small>${date(sub.reviewed_at)}</small></div>`:'<small>等待验收</small>'}</article>`).join('')||'<p class="subtle">尚未提交成果。</p>'}
    <h3>操作记录</h3><ol class="history">${detail.audit.map((a) => `<li><strong>${esc(a.actor||'系统')} · ${esc(auditLabel[a.action]||'记录已更新')}</strong><small>${date(a.created_at)}</small>${auditDescription(a)?`<p class="pre">${esc(auditDescription(a))}</p>`:''}</li>`).join('')}</ol>`);
}
function formModal(title, kind, fields, action='保存') { modal(title, `<form data-kind="${kind}">${fields}<div class="form-actions"><button type="button" data-action="close">取消</button><button class="primary" type="submit">${action}</button></div><p class="form-status" role="status"></p></form>`); }
function forms(action, userId) {
  const t = detail?.task;
  if(action==='register-legacy-space')modal('接通已有项目空间',`<form id="legacy-project-space">${hidden('project_id',selected)}<p class="subtle">只核对并登记本项目已有资源，不创建群聊、不更改共享权限。需要原资料保管账号操作。</p>${field('folder_path','已有项目资料夹名称','text','','required maxlength="190" placeholder="填写资料根目录中已有的文件夹名称"')}${field('room_token','已有群聊编号','text','','required pattern="[a-zA-Z0-9]{4,64}" maxlength="64" placeholder="群聊链接中 /call/ 后面的编号"')}<p class="subtle">从现有群聊地址复制 /call/ 后的编号。系统会核对群聊和资料夹均属于本项目登记群组，名称相同不能替代权限核对。</p><p class="form-status" role="status"></p><div class="row-actions"><button type="button" data-action="close">取消</button><button type="submit" class="primary">核对并接通</button></div></form>`);
  if (action==='new-project') formModal('建立工坊项目','create_project',field('name','项目名称','text','','required maxlength="120"')+area('details','项目介绍')+area('goal','阶段目标'));
  if (action==='new-task'||action==='meeting-task') formModal(action==='meeting-task'?'从组会分配任务':'分配任务','create_task',hidden('project_id',selected)+(action==='meeting-task'?hidden('meeting_source',meetingSource)+`<p class="subtle">所属项目：${esc(state.projects.find(p=>+p.project_id===selected)?.name)}</p><label><input type="checkbox" name="confirm_meeting_project" value="1" required>我确认该待办属于此项目，且允许向本项目成员分配。</label>`:'')+field('title','任务名称','text','','required maxlength="200"')+`<label>责任人<select name="assignee_id" required>${memberOptions(selected)}</select></label>`+field('due','截止时间（北京时间）','datetime-local')+`<label>优先级<select name="priority"><option value="3">普通</option><option value="2">高</option><option value="1">紧急</option><option value="4">低</option></select></label>`+area('description','任务说明')+area('criteria','验收要求','','required maxlength="4000"'));
  if (action==='member') {
    const p = state.people.find((p)=>+p.user_id===+userId);
    formModal(`${p.name} · 项目角色`,'membership',hidden('user_id',userId)+`<p class="subtle">已有关系：${esc(state.memberships.filter((m)=>+m.user_id===+userId&&+m.active).map((m)=>(state.projects.find((p)=>+p.project_id===+m.project_id)?.name||'')+' · '+(m.role==='leader'?'组长':'组员')).join('；')||'尚未分配')}</p><label>项目<select name="project_id">${projectOptions()}</select></label><label>此项目角色<select name="role"><option value="member">项目组员</option><option value="leader">项目组长</option></select></label><label>操作<select name="active"><option value="true">加入或更新此项目</option><option value="false">退出此项目，保留历史</option></select></label>`);
  }
  if (action==='person-role') formModal('设置工坊管理权限','person_role',hidden('user_id',userId)+`<p class="subtle">只由系统维护管理员授予。项目组长请在项目角色中设置。</p><label>工坊角色<select name="role"><option value="member">普通成员</option><option value="teacher">指导老师</option><option value="manager">总负责人</option></select></label>`);
  if (action==='edit-form') formModal('调整责任人与期限','edit_task',hidden('task_id',t.id)+hidden('revision',t.revision)+`<label>责任人<select name="assignee_id">${memberOptions(t.projectId,t.editorId)}</select></label>`+field('due','截止时间（北京时间）','datetime-local',localDate(t.dateToFinish))+area('reason','修改原因（保留历史）','','required'));
  if (action==='progress-form') formModal('更新任务进度','transition',hidden('task_id',t.id)+hidden('revision',t.revision)+`<label>目标状态<select name="state"><option value="progress">进行中 / 重新打开</option><option value="blocked">已阻塞</option><option value="new">待开展</option>${detail.can_manage?'<option value="cancelled">取消任务</option>':''}</select></label>`+area('reason','说明 / 阻塞原因（取消、阻塞或重开时必填）')+area('support_needed','需要什么帮助'));
  if (action==='submit-form') formModal('提交一个新的成果版本','submit',hidden('task_id',t.id)+hidden('revision',t.revision)+area('content','成果说明','','required maxlength="20000"')+area('links','成果链接（每行一个 http/https 地址）')+`<label>成果附件（PDF、图片、TXT、CSV、ZIP，每个≤10MB）<input type="file" name="file" multiple accept=".pdf,.png,.jpg,.jpeg,.txt,.csv,.zip"></label><div class="uploaded" id="uploaded"></div><p class="subtle">附件上传成功后，再确认本次成果提交。</p>`,'提交验收');
  if (action==='review-form') formModal('验收最新成果版本','review',hidden('task_id',t.id)+hidden('revision',t.revision)+hidden('submission_id',detail.submissions[0].id)+`<label>验收结论<select name="decision"><option value="accepted">验收通过</option><option value="returned">退回修改</option></select></label>`+area('comment','验收意见','','required maxlength="4000"'),'确认验收');
}
function registration() {
  root.innerHTML = `<main class="registration"><a class="brand" href="${base}/auth/login"><span class="brand-mark">W<span class="brand-dot"></span></span><span>创新工坊<small>注册与身份审核</small></span></a><section class="panel"><h1>申请加入工坊</h1><p class="subtle">现场填写邮箱即可。验证邮箱后，由管理员核实身份并分配项目。</p>${new URLSearchParams(location.search).has('verified')?'<p class="success-box">邮箱已验证。请等待管理员核实身份、批准入组，再登录。</p>':''}
    <form data-kind="register">${field('name','姓名','text','','required maxlength="60" autocomplete="name"')}${field('student_no','学号 / 学员编号','text','','required pattern="[a-zA-Z0-9_-]{3,64}"')}${field('email','本人邮箱','email','','required maxlength="190" autocomplete="email"')}${field('password','设置密码（至少12位，含字母和数字）','password','','required minlength="12" maxlength="128" autocomplete="new-password"')}<button class="primary" type="submit">注册并发送验证邮件</button><p class="form-status" role="status"></p></form>
    <details><summary>没有收到验证邮件？</summary><form data-kind="resend">${field('email','注册时填写的邮箱','email','','required')}<button>重发验证邮件</button><p class="form-status" role="status"></p></form></details><a class="text-link" href="${base}/auth/login">已有获批账号？进入登录 →</a></section><p class="footnote">邮箱验证只确认邮箱归属，不能代替身份审核。一个账号可以加入多个项目。</p></main>`;
}
document.addEventListener('input',(event)=>{ if(event.target.id==='people-search'){peopleSearch=event.target.value.trim();filterPeople();return;} const form=event.target.closest('form[data-kind]'); if(form&&!['register','resend'].includes(form.dataset.kind)) draft(form); });
document.addEventListener('change', async(event)=>{
  if(event.target.id==='people-project'){peopleProject=+event.target.value;filterPeople();return;}
  if(event.target.id==='timeline-mode'){chartMode=event.target.value;render();return;}
  if(event.target.id==='project-filter'){ nativeNavigationTicket++;selected=+event.target.value;page=1;try{await load();}catch(e){message(e.message,true);} }
});
document.addEventListener('click',async(event)=>{
  if(event.defaultPrevented||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
  const button=event.target.closest('button,a[data-action],a[data-collaboration],a[data-view]'); if(!button||button.disabled)return;
  try {
    if(button.dataset.linkMeetingTask){
      const data=await readTaskForCurrentPage(button.dataset.linkMeetingTask);if(!data)return;const t=data.task;
      if(!data.can_manage)throw new Error('只有该项目的任务管理者可以关联来源。');
      formModal('关联到已有任务','link_meeting_task',hidden('task_id',t.id)+hidden('revision',t.revision)+hidden('meeting_source',meetingSource)+`<p><strong>${esc(t.headline)}</strong></p><p class="subtle">${esc(state.projects.find(p=>+p.project_id===+t.projectId)?.name)}。保留原责任人、期限、成果和任务状态；不新建任务，也不覆盖其他来源。</p><label><input type="checkbox" name="confirm_meeting_project" value="1" required>我确认这条任务对应当前组会待办，且属于同一项目。</label>`,'确认关联');return;
    }
    if(button.dataset.attendanceReportPage){const host=document.querySelector('#attendance-report-results');await readAttendanceReport(host.dataset.week,host.dataset.user,+button.dataset.attendanceReportPage);return;}
    if(button.dataset.attendanceType){await recordAttendance(button.dataset.attendanceType);return;}
    if(button.dataset.calendarMode){chartMode=button.dataset.calendarMode;renderTimeline.chart?.changeView(chartMode);document.querySelectorAll('[data-calendar-mode]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.calendarMode===chartMode)));updateCalendarRange();return;}
    if(button.dataset.openUnifiedAccount||button.dataset.resendUnifiedInvitation){
      const resend=!!button.dataset.resendUnifiedInvitation;if(resend&&!confirm('重发激活邀请可能使尚未使用的旧邀请链接失效。确认让该学员重新检查邮箱？'))return;
      const label=button.textContent;button.disabled=true;button.textContent=resend?'正在提交邀请…':'正在开通并核对权限…';
      try{const result=await request('/workshop/enrollment/account',{method:'POST',timeoutMs:120000,headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:+(button.dataset.openUnifiedAccount||button.dataset.resendUnifiedInvitation),resend})});await load();message(result.message);}catch(error){await load().catch(()=>null);message(error.message,true);}finally{if(button.isConnected){button.disabled=false;button.textContent=label;}}return;
    }
    if(button.dataset.auditProjectSpace){
      const host=button.closest('#project-space')?.querySelector('.project-access-audit'),project=+button.dataset.auditProjectSpace;
      if(!host)return;button.disabled=true;host.textContent='正在只读核对登记项目组、资料共享与群聊参与者…';
      try{const result=await request('/workshop/project-space/audit?project_id='+project,{timeoutMs:120000});if(host.isConnected&&selected===project)host.innerHTML=`<h3>共享权限核对</h3><p>${esc(result.message)}</p><ul>${result.findings.map(f=>`<li><strong>${esc(f.area)}</strong>：${esc(f.message)}${f.resources?.length?`<ul>${f.resources.map(item=>`<li>${item.file_id?`<a data-collaboration="files" href="${esc(collaboration+'/f/'+item.file_id)}">${esc(item.path)}</a>`:esc(item.path)}</li>`).join('')}</ul>${f.truncated?'<p class="subtle">仅展示前50条，请到原生共享设置核对其余记录。</p>':''}`:''}</li>`).join('')}</ul><p class="subtle">核对范围：${esc(result.scope)}</p><p class="subtle">可通过上方项目资料和聊天入口打开原生共享或成员设置；不会自动删除任何授权。</p>`;}
      catch(error){if(host.isConnected)host.textContent='只读核对未完成：'+error.message;}
      finally{if(button.isConnected)button.disabled=false;}return;
    }
    if(button.dataset.prepareProjectSpace){
      const project=+button.dataset.prepareProjectSpace;if(projectSpaceBusy.has(project))return;projectSpaceBusy.add(project);button.disabled=true;button.textContent='正在建置并核对…';
      const host=button.closest('#project-space');
      try{const result=await request('/workshop/project-space',{method:'POST',timeoutMs:180000,headers:{'Content-Type':'application/json'},body:JSON.stringify({project_id:project})});if(host?.isConnected&&selected===project)host.innerHTML=projectSpacePanel(result);message(result.message);await flushProjectGroupQueue();}
      catch(error){message(error.message,true);if(host?.isConnected){host.innerHTML='<p class="subtle" role="status">'+esc(error.message)+'</p>'+(error.status===428?'<a class="button" data-collaboration="settings" href="'+esc(collaboration+'/apps/workshop_shell/project-confirm?project='+project)+'">使用原生维护确认</a>':'<button data-prepare-project-space="'+project+'">重试并核对已有进度</button>');}}
      finally{projectSpaceBusy.delete(project);}return;
    }
    if(button.hasAttribute('data-flush-project-groups')){void flushProjectGroupQueue();return;}
    if(button.dataset.syncProjectGroups){button.disabled=true;const label=button.textContent;button.textContent='正在核对项目组权限…';try{const result=await request('/workshop/enrollment/groups',{method:'POST',timeoutMs:90000,headers:{'Content-Type':'application/json'},body:JSON.stringify({user_id:+button.dataset.syncProjectGroups})});await load();message(result.message);}catch(error){message(error.message,true);}finally{if(button.isConnected){button.disabled=false;button.textContent=label;}}return;}
    if(button.hasAttribute('data-enrollment-readiness')){
      const panel=document.querySelector('#enrollment-readiness');panel.hidden=false;panel.textContent='正在检查注册、发信和统一账号开通准备…';button.disabled=true;
      try{const r=await request('/workshop/enrollment/readiness');const labels={inactive:'已停用或未通过',awaiting_review:'等待身份审核',awaiting_email:'等待邮箱验证',awaiting_project:'等待项目分配',awaiting_account:'等待消息与资料账号开通',bound:'已绑定登录身份'};
       panel.innerHTML=`<h3>账号开通准备</h3><ul>${r.checks.map(c=>`<li>${esc(c.label)}：${c.ready?(c.id==='native_administrator'?'已确认':'已配置（仍需实际收信验证）'):'尚未就绪'}</li>`).join('')}</ul><p>${Object.entries(r.counts).map(([k,v])=>`${labels[k]} ${+v} 人`).join(' · ')}</p><p class="subtle">${esc(r.message)}</p><p class="subtle">登记项目组同步${r.project_group_sync_available?'已接通':'尚未登记'}，待核对 ${+r.pending_group_sync_count||0} 人。统一账号创建与邀请重发入口已接入，需正式发信后完成实际收信验收；个人分享等完整资源权限同步尚未完成。当前检查不会改变任何账号。</p>`;
      }catch(error){panel.textContent=error.message;}finally{button.disabled=false;}return;
    }
    if(button.dataset.peopleRole){peopleRole=button.dataset.peopleRole;filterPeople();return;}
    if(button.dataset.collaboration){event.preventDefault();await openCollaboration(button.href);return;}
    nativeNavigationTicket++;if(notice.textContent==='正在进入工坊模块…')notice.hidden=true;
    if(button.dataset.view==='settings'){event.preventDefault();await openCollaboration(collaboration+'/settings/user/workshop-identity');return;}
    if(button.dataset.view){event.preventDefault();view=button.dataset.view;if(button.closest('#main-navigation')||['overview','mine'].includes(view))selected=0;search='';taskFilter='all';page=1;closeModal();await load();return;}
    if(button.dataset.filter){taskFilter=button.dataset.filter;if(['overview','projects','reviews'].includes(view))view='tasks';page=1;await load();return;}
    if(button.dataset.project){selected=+button.dataset.project;taskFilter='all';page=1;view='projects';await load();return;}
    if(button.dataset.task){await showTask(+button.dataset.task);return;}
    if(button.dataset.member){forms('member',+button.dataset.member);return;}
    if(button.dataset.personRole){forms('person-role',+button.dataset.personRole);return;}
    if(button.dataset.approve){if(confirm('已现场核实此人的身份，确认批准入组？')){await mutate('approve',{user_id:+button.dataset.approve});await load();}return;}
    if(button.dataset.suspend){if(confirm('确认停用账号？历史工作会保留，账号将无法访问工坊。')){await mutate('suspend',{user_id:+button.dataset.suspend});await load();}return;}
    const action=button.dataset.action;
    if(action==='toggle-nav'){const open=document.querySelector('.sidebar').classList.toggle('menu-open');button.setAttribute('aria-expanded',String(open));return;}
    if(action==='close'){closeModal();return;}
    if(action==='retry-workspace'){await load('replace').catch(showInitialLoadError);return;}
    if(action==='refresh'){await load();message('刷新完成 · '+lastUpdated);return;}
    if(action==='calendar-retry'){void renderTimeline();return;}
    if(['calendar-prev','calendar-next','calendar-today'].includes(action)){const chart=renderTimeline.chart;if(chart){if(action==='calendar-today')chart.today();else if(action==='calendar-prev')chart.prev();else chart.next();updateCalendarRange();}return;}
    if(action==='home'){event.preventDefault();view='overview';selected=0;search='';taskFilter='all';page=1;await load();return;}
    if(action==='dismiss-meeting-source'){meetingSource='';if(taskFilter==='meeting')taskFilter='all';sessionStorage.removeItem(prefix()+'meeting-source');await load('replace');return;}
    if(action==='all-projects'){selected=0;view='projects';await load();return;}
    if(action==='edit-project'){const p=state.projects.find(p=>+p.project_id===selected);formModal('维护项目阶段与目标','edit_project',hidden('project_id',selected)+hidden('revision',p.revision)+field('stage','当前阶段','text',p.stage,'required maxlength=120')+area('goal','阶段目标',p.goal,'maxlength=4000'));return;}
    if(action==='roster'){await rosterDialog();return;}
    if(action==='next'||action==='prev'){page+=action==='next'?1:-1;await load();return;}
    if(action==='archive'){const p=state.projects.find(p=>+p.project_id===selected);if(confirm(p.archived_at?'确认重新开放项目？':'确认归档项目？归档后项目只读。')){await mutate('archive',{project_id:selected,revision:+p.revision,archived:!p.archived_at});await load();}return;}
    if(action)forms(action);
  } catch(error){message(error.message,true);}
});
document.addEventListener('input',event=>{if(event.target.id==='knowledge-question-text')knowledgeDrafts.set(knowledgeProject,event.target.value);});
document.addEventListener('change',event=>{if(event.target.id==='knowledge-project'){knowledgeProject=+event.target.value;history.replaceState({workshop:true},'',routeUrl(routeSnapshot()));render();committedRoute=routeSnapshot();}});
document.addEventListener('submit',async(event)=>{if(event.target.id!=='knowledge-question')return;event.preventDefault();if(knowledgeBusy)return;const form=event.target,question=form.elements.question.value.trim();if(!question)return;const projectId=knowledgeProject;knowledgeBusy=true;const button=form.querySelector('button'),status=form.querySelector('[role=status]');button.disabled=true;button.textContent='正在查阅资料…';status.textContent='正在检索项目资料，请稍候。';try{const answer=await request('/workshop/knowledge',{method:'POST',timeoutMs:70000,headers:{'Content-Type':'application/json'},body:JSON.stringify({project_id:projectId,question})});const items=knowledgeAnswers.get(projectId)||[];items.push({question,...answer});knowledgeAnswers.set(projectId,items.slice(-10));if(form.elements.question.value.trim()===question){form.elements.question.value="";knowledgeDrafts.delete(projectId);}if(view==='knowledge'&&knowledgeProject===projectId)render();}catch(error){if(form.isConnected)status.textContent=error.message;message(error.message,true);}finally{knowledgeBusy=false;if(form.isConnected){button.disabled=false;button.textContent='发送';}else if(view==='knowledge'){const next=document.querySelector('#knowledge-question button');if(next){next.disabled=false;next.textContent='发送';}}}});
document.addEventListener('submit',async event=>{
 const form=event.target;if(form.id!=='legacy-project-space')return;event.preventDefault();const button=form.querySelector('button[type="submit"]'),status=form.querySelector('[role="status"]');if(button.disabled)return;button.disabled=true;status.textContent='正在读取现有资源并核对项目归属…';const project=+form.elements.project_id.value;
 try{const result=await request('/workshop/project-space/legacy',{method:'POST',timeoutMs:120000,headers:{'Content-Type':'application/json'},body:JSON.stringify({project_id:project,folder_path:form.elements.folder_path.value,room_token:form.elements.room_token.value})});if(form.isConnected)closeModal();if(view==='projects'&&selected===project)await loadProjectSpace();message(result.message);}
 catch(error){if(form.isConnected)status.textContent=error.message;message(error.message,true);}
 finally{if(form.isConnected)button.disabled=false;}
});
document.addEventListener('submit',async(event)=>{
  const form=event.target;
  if(form.id==='task-search'){event.preventDefault();nativeNavigationTicket++;search=form.elements.search.value.trim();view='tasks';selected=0;page=1;taskFilter='all';try{await load();}catch(e){message(e.message,true);}return;}
  if(form.id==='logout'||form.action===base+'/workshop/logout'){for(const key of Object.keys(sessionStorage))if(key.startsWith('workshop:'))sessionStorage.removeItem(key);return;}
  if(!form.dataset.kind)return;event.preventDefault();
  if(form.dataset.busy)return;form.dataset.busy='1';
  const submit=form.querySelector('button[type="submit"]')||form.querySelector('button');submit.disabled=true;
  const status=form.querySelector('.form-status');status.textContent='正在保存，请稍候…';
  const data=Object.fromEntries(new FormData(form));const action=form.dataset.kind;
  const originRevision=revision,originNavigation=nativeNavigationTicket,originDialog=form.closest('dialog');
  const savedDraftKey=prefix()+'draft:'+draftId(form),savedDraft=sessionStorage.getItem(savedDraftKey);
  for(const key of ['user_id','project_id','task_id','revision','assignee_id','submission_id','priority'])if(key in data)data[key]=+data[key];
  if('active'in data)data.active=data.active==='true';
  if('reduce_motion'in data)data.reduce_motion=data.reduce_motion==='true';
  try {
    if(action==='register'||action==='resend'){
      const result=await request('/workshop/'+action,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
      status.textContent=result.message;message(result.message);if(action==='register')form.elements.password.value='';return;
    }
    if(action==='submit'){
      const files=[...form.elements.file.files];if(files.length>10)throw new Error('每次最多上传10个附件。');
      let saved=[];try{saved=JSON.parse(sessionStorage.getItem(prefix()+'files:'+data.task_id)||'[]');}catch{}
      for(const file of files){
        const signature=`${file.name}:${file.size}:${file.lastModified}`;
        let entry=saved.find(f=>f.signature===signature);
        if(!entry){entry={signature,key:crypto.randomUUID()};saved.push(entry);}
        sessionStorage.setItem(prefix()+'files:'+data.task_id,JSON.stringify(saved));
        if(!entry.file_id){
          status.textContent=`正在上传 ${file.name}…`;
          const body=new FormData();body.append('file',file);body.append('task_id',data.task_id);
          const result=await request('/workshop/upload',{method:'POST',headers:{'Idempotency-Key':entry.key},body});entry.file_id=result.file_id;entry.name=result.name;
        }
        sessionStorage.setItem(prefix()+'files:'+data.task_id,JSON.stringify(saved));
        form.querySelector('#uploaded').textContent=saved.filter(f=>f.file_id).map(f=>'已上传：'+f.name).join('；');
      }
      data.file_ids=saved.filter(f=>f.file_id).map(f=>f.file_id);delete data.file;
    }
    const result=await mutate(action,data,action+(data.task_id||data.user_id||''));
    if(sessionStorage.getItem(savedDraftKey)===savedDraft)sessionStorage.removeItem(savedDraftKey);
    if(action==='submit'){const fileKey=prefix()+'files:'+data.task_id;try{const current=JSON.parse(sessionStorage.getItem(fileKey)||'[]');if(JSON.stringify(current.map(f=>f.file_id).sort())===JSON.stringify([...data.file_ids].sort()))sessionStorage.removeItem(fileKey);}catch{}}
    if(!form.isConnected||revision!==originRevision||nativeNavigationTicket!==originNavigation){if(originDialog?.isConnected)originDialog.close();message(result.message+' 当前页面已保留，可刷新查看最新结果。');return;}
    if(['create_task','link_meeting_task'].includes(action)&&data.meeting_source){meetingSource='';if(taskFilter==='meeting')taskFilter='all';sessionStorage.removeItem(prefix()+'meeting-source');}
    if(action==='create_project'&&result.project_id){selected=+result.project_id;view='projects';page=1;}
    closeModal();const refresh=load(),refreshRevision=revision,refreshNavigation=nativeNavigationTicket;await refresh;
    if(revision!==refreshRevision||nativeNavigationTicket!==refreshNavigation)return;
    if(data.task_id||action==='create_task'&&data.meeting_source)await showTask(data.task_id||result.task_id);message(result.message);
  }catch(error){status.textContent=error.message;message(error.message,true);if(form.isConnected)draft(form);}
  finally{submit.disabled=false;delete form.dataset.busy;}
});
window.addEventListener('popstate',()=>{if(registerMode)return;nativeNavigationTicket++;closeModal();applyRoute(routeFromLocation());load('replace').catch(error=>message(error.message,true));});
window.addEventListener('pageshow',event=>{if(registerMode)return;if(!event.persisted){const select=document.querySelector('#knowledge-project');if(select)select.value=String(knowledgeProject);return;}load.nativeAppearanceChecked=false;applyRoute(routeFromLocation());load('replace').catch(error=>message(error.message,true));});
window.addEventListener('online',()=>message('网络已恢复。若上次保存未确认，请重试同次操作，系统会防止重复保存。'));
function showInitialLoadError(error) {
  // Keep the server-authorized navigation. A denied deep link is not a failed login.
  const denied=error.status===403,title=denied?'无权访问此项目':'暂时无法载入数据';
  const html=`<h2>${title}</h2><p>${esc(error.message)}</p><p class="subtle">${denied?'请返回总览查看已授权项目；如需加入此项目，请联系负责人。':'可以重试读取；若登录已过期，请重新登录。'}</p><div class="actions"><a class="button" href="${base}/workshop?view=overview">返回工坊总览</a>${denied?'':'<button data-action="retry-workspace">重试载入</button>'}<a class="button" href="${base}/auth/login">重新登录</a></div>`;
  const panel=root.querySelector('.initial-loading');
  if(panel){panel.innerHTML=html;panel.setAttribute('role','alert');const titleNode=root.querySelector('.page-head h1');if(titleNode)titleNode.textContent=title;}
  else root.innerHTML=`<main class="main"><section class="panel initial-loading" role="alert">${html}</section></main>`;
  const toggle=root.querySelector('.mobile-nav-toggle');
  if(toggle){toggle.disabled=false;toggle.dataset.action='toggle-nav';toggle.setAttribute('aria-expanded','false');toggle.setAttribute('aria-controls','main-navigation');}
}
if(registerMode)registration();else load().catch(showInitialLoadError);

document.addEventListener('submit',async event=>{
 if(event.target.id!=='knowledge-publish')return;event.preventDefault();const form=event.target,button=form.querySelector('button'),status=form.querySelector('[role=status]');if(button.disabled)return;const file=form.elements.file.files[0],project=knowledgeProject;
 if(!file||file.size>5242880){status.textContent='请选择5MB以内的PDF、DOCX、TXT或Markdown。';return;}
 const replacing=knowledgeReplacements.get(project);const signature=project+':'+file.name+':'+file.size+':'+file.lastModified+':'+(replacing?.id||0);let key=knowledgeUploadKeys.get(signature);if(!key){key=crypto.randomUUID();knowledgeUploadKeys.set(signature,key);}const upload=new FormData(form);upload.set('project_id',String(project));if(replacing){upload.set('replaces_source_id',String(replacing.id));upload.set('revision',String(replacing.revision));}upload.set('shared_with_project',form.elements.shared_with_project.checked?'1':'0');button.disabled=true;status.textContent='正在解析资料并建立索引，请保留页面；保存结果未确认前不要重复发布。';
 try{const result=await request('/workshop/knowledge/publish',{method:'POST',body:upload,timeoutMs:240000,headers:{'Idempotency-Key':key}});knowledgeUploadKeys.delete(signature);knowledgeReplacements.delete(project);knowledgeAnswers.delete(project);knowledgeLibraries.delete(project);message(result.message);await loadKnowledgeLibrary(project,true);}catch(error){status.textContent=error.message;message(error.message,true);const next=await request('/workshop/knowledge/library?project_id='+project).catch(()=>null);if(next){knowledgeLibraries.set(project,next);if(next.status==='pending')status.innerHTML=esc(error.message)+` <button type="button" data-knowledge-sync="${project}">重试同步并核对索引</button>`;}}finally{if(button.isConnected)button.disabled=false;}
});
document.addEventListener('click',async event=>{
 const replace=event.target.closest('[data-knowledge-replace]'),cancel=event.target.closest('[data-knowledge-cancel-replace]');if(replace){knowledgeReplacements.set(+replace.dataset.kbProject,{id:+replace.dataset.knowledgeReplace,revision:+replace.dataset.revision});render();return;}if(cancel){knowledgeReplacements.delete(+cancel.dataset.knowledgeCancelReplace);render();return;}
 const refresh=event.target.closest('[data-knowledge-library-refresh]');if(refresh){await loadKnowledgeLibrary(+refresh.dataset.knowledgeLibraryRefresh,true);return;}
 const button=event.target.closest('[data-knowledge-withdraw],[data-knowledge-sync]');if(!button||button.disabled)return;const project=button.dataset.knowledgeSync?+button.dataset.knowledgeSync:+button.dataset.kbProject;button.disabled=true;const old=button.textContent;button.textContent='正在核对索引…';
 try{const path=button.dataset.knowledgeSync?'retry':'withdraw';const result=await request('/workshop/knowledge/'+path,{method:'POST',timeoutMs:240000,headers:{'Content-Type':'application/json'},body:JSON.stringify({project_id:project,source_id:+button.dataset.knowledgeWithdraw,revision:+button.dataset.revision})});knowledgeAnswers.delete(project);message(result.message);await loadKnowledgeLibrary(project,true);}catch(error){message(error.message,true);await loadKnowledgeLibrary(project,true);}finally{if(button.isConnected){button.disabled=false;button.textContent=old;}}
});
