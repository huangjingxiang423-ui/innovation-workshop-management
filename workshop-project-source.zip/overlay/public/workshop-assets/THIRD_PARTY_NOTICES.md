# Native dependency provenance

native-frappe-gantt.js is copied from this pinned Leantime 3.12.0 checkout at public/assets/js/libs/simpleGantt/frappe-gantt.js. It is an existing bundled Gantt implementation, not a newly authored chart engine. The local adapter adds an early return in bind_bar_events when options.is_draggable === false; the workshop uses it in read-only mode. Preserve upstream notices and the repository LICENSE when distributing source. No claim of an independent license audit is made here.

Other workshop assets are the local Workshop integration and presentation implementation. They do not include DooTask paid binary code. The source repository LICENSE remains intact.
