<?php

namespace Leantime\Command;

use Illuminate\Console\Command;
use Leantime\Core\Db\Db;
use Leantime\Domain\Workshop\Migrations\InitialSchema;

final class WorkshopInstallCommand extends Command
{
    protected $signature = 'workshop:install';
    protected $description = 'Install additive workshop schema (run after native Leantime installation)';

    public function handle(Db $db): int
    {
        $connection = $db->getConnection();
        if (!$connection->getSchemaBuilder()->hasTable('zp_user')) {
            $this->error('请先完成 Leantime 原生安装。');
            return self::FAILURE;
        }
        (new InitialSchema)->up($connection);
        foreach (['WorkspacePreferences', 'BridgeRequests', 'RosterSchema', 'IdentityBindings',
            'AttendanceCorrectionsSchema', 'ProjectGroupSyncSchema', 'AccountEnrollmentSchema',
            'ProjectSpacesSchema', 'LegacyProjectLinksSchema', 'MeetingTaskSourceSchema'] as $migration) {
            $class = 'Leantime\\Domain\\Workshop\\Migrations\\' . $migration;
            (new $class())->up($connection);
        }
        $this->info('工坊 schema 已就绪；未创建默认密码或虚构学员。');
        return self::SUCCESS;
    }
}
