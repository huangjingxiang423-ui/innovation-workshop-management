<?php

namespace Leantime\Domain\Workshop;

use Closure;
use Leantime\Core\Db\Db;
use Leantime\Core\Http\IncomingRequest;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Response;

/** Fail-closed boundary prevents legacy API/MCP/native screens bypassing workshop rules. */
final class AccessBoundary
{
    public function handle(IncomingRequest $request, Closure $next): Response
    {
        if (!config('workshop.enabled', false)) {
            return $next($request);
        }
        $path = $request->getPathInfo();
        $id = (int) session('userdata.id');
        if (preg_match('#^/(api|mcp|webhook)(/|$)#i', $path)) {
            return new JsonResponse(['error' => '工坊模式未开放旧 API 或自动化入口。'], 403);
        }
        if (!$id || preg_match('#^/auth/(login|logout|resetPw|userInvite)(/|$)#i', $path)
            || preg_match('#^/oidc/(login|callback)(/|$)#i', $path)) {
            return $next($request);
        }
        if ($path === '/' || ($request->isMethod('GET') && (rtrim($path, '/') === '/dashboard/home'
            || ($path === '/workshop' && session()->has('workshop.return_view'))))) {
            $native=session()->pull('workshop.return_native');
            if(in_array($native,['chat','meetings','files','settings'],true))return new RedirectResponse(BASE_URL.'/workshop/open-native/'.$native);
            $view = session()->pull('workshop.return_view');
            $suffix = in_array($view, ['overview', 'mine', 'projects', 'tasks', 'reviews', 'timeline', 'people', 'settings', 'knowledge', 'attendance'], true)
                ? '?view='.$view : '';
            return new RedirectResponse(BASE_URL.'/workshop'.$suffix);
        }
        if ($path === '/workshop' || str_starts_with($path, '/workshop/')) {
            return $next($request); // The domain controller authorizes every non-public action.
        }
        $db = app(Db::class)->getConnection();
        $user = $db->table('zp_user')->where('id', $id)->first();
        // Only the bootstrap maintenance owner retains the original administration interface.
        // Workshop managers/teachers are deliberately NOT native global administrators.
        if ($user && (int) $user->role === 50 && strtolower((string) $user->status) === 'a') {
            return $next($request);
        }
        return new JsonResponse(['error' => '请通过工坊工作台操作；此入口不开放。'], 403,
            ['Cache-Control' => 'no-store']);
    }
}
