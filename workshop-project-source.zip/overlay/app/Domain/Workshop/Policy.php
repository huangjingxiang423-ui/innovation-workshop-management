<?php

namespace Leantime\Domain\Workshop;

/** Pure domain rules, shared by every HTTP mutation. */
final class Policy
{
    public const STATES = ['new' => 3, 'progress' => 4, 'blocked' => 1, 'review' => 2, 'done' => 0];

    public static function transition(string $from, string $to, bool $leader, bool $assignee): void
    {
        $allowed = [
            'new' => ['progress', 'blocked'],
            'progress' => ['blocked', 'new'],
            'blocked' => ['progress', 'new'],
            'done' => $leader ? ['progress'] : [],
        ];
        // review/done can only be entered by submit/review services, never a status dropdown.
        if ((!$leader && !$assignee) || !in_array($to, $allowed[$from] ?? [], true)) {
            throw new WorkshopException('当前角色不能进行此状态变更，请使用成果提交或验收流程。', 403);
        }
    }

    public static function links(string $value): array
    {
        $links = array_values(array_filter(array_map('trim', preg_split('/\R/u', $value) ?: [])));
        if (count($links) > 10) {
            throw new WorkshopException('最多填写 10 个成果链接。');
        }
        foreach ($links as $link) {
            if (strlen($link) > 2048 || !filter_var($link, FILTER_VALIDATE_URL)
                || !in_array(strtolower((string) parse_url($link, PHP_URL_SCHEME)), ['http', 'https'], true)) {
                throw new WorkshopException('成果链接必须是有效的 http 或 https 地址。');
            }
        }
        return array_values(array_unique($links));
    }

    public static function text(mixed $value, int $max, bool $required = false): string
    {
        if (!is_string($value) || mb_strlen(trim($value)) > $max || ($required && trim($value) === '')) {
            throw new WorkshopException('请检查必填内容和字数限制。');
        }
        return trim($value);
    }

    public static function revision(mixed $expected, int $actual): void
    {
        if (!is_numeric($expected) || (int) $expected !== $actual) {
            throw new WorkshopException('内容已被其他人更新，请刷新后比较最新内容；你的输入仍会保留。', 409);
        }
    }
}
