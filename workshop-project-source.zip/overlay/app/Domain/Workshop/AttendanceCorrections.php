<?php
namespace Leantime\Domain\Workshop;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Cache;
/** Approval adapter for native Employee Checkin. Original events are never edited or deleted. */
final class AttendanceCorrections
{
 public function __construct(private ConnectionInterface $db,private Attendance $attendance){}
 private function manager(array $actor): bool {return $actor['owner']||in_array($actor['role'],['manager','teacher'],true);}
 private function audit(int $actor,string $action,int $id,mixed $before,mixed $after): void
 {
  $this->db->table('ws_audit')->insert(['actor_id'=>$actor,'project_id'=>null,'action'=>$action,'entity'=>'attendance_correction','entity_id'=>$id,'before_json'=>$before===null?null:json_encode($before,JSON_UNESCAPED_UNICODE),'after_json'=>json_encode($after,JSON_UNESCAPED_UNICODE),'created_at'=>gmdate('Y-m-d H:i:s')]);
 }
 public function listing(array $actor): array
 {
  $query=$this->db->table('ws_attendance_corrections as c')->join('zp_user as u','u.id','=','c.user_id')->leftJoin('zp_user as reviewer','reviewer.id','=','c.reviewer_id')->select('c.*','u.firstname','u.lastname','reviewer.firstname as reviewer_firstname','reviewer.lastname as reviewer_lastname');
  if(!$this->manager($actor))$query->where('c.user_id',$actor['id']);
  $rows=$query->orderByRaw("CASE WHEN c.status IN ('pending','processing') THEN 0 ELSE 1 END")->orderByDesc('c.id')->limit(100)->get()->all();
  return array_map(function($r){return ['id'=>(int)$r->id,'user_id'=>(int)$r->user_id,'name'=>trim($r->firstname.' '.$r->lastname),'source_time'=>$r->source_time,'requested_time'=>$r->requested_time,'reason'=>$r->reason,'status'=>$r->status,'reviewer_id'=>(int)$r->reviewer_id,'reviewer_name'=>trim(($r->reviewer_firstname??'').' '.($r->reviewer_lastname??'')),'review_comment'=>$r->review_comment,'created_at'=>$r->created_at,'reviewed_at'=>$r->reviewed_at,'record_id'=>$r->native_record_id];},$rows);
 }
 public function submit(array $actor,array $data,string $key): array
 {
  if(array_diff(array_keys($data),['source_id','requested_time','reason']))throw new WorkshopException('补正申请不能指定其他人员或审批结果。');
  if(!preg_match('/^[a-zA-Z0-9_-]{16,80}$/D',$key))throw new WorkshopException('缺少有效操作编号，请刷新后重试。');
  $reason=Policy::text($data['reason']??'',1000,true);$source=Policy::text($data['source_id']??'',140,true);
  $time=str_replace('T',' ',Policy::text($data['requested_time']??'',19,true));if(strlen($time)===16)$time.=':00';
  $zone=new \DateTimeZone('Asia/Shanghai');$date=\DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',$time,$zone);
  if(!$date||$date->format('Y-m-d H:i:s')!==$time||$date>new \DateTimeImmutable('now',$zone))throw new WorkshopException('请填写有效且不晚于当前时间的实际签退时间。');
  $hash=hash('sha256',json_encode([$source,$time,$reason],JSON_UNESCAPED_UNICODE));
  $lock=Cache::lock('workshop-attendance-'.$actor['id'],90);if(!$lock->get())throw new WorkshopException('正在核对考勤，请稍后重试。',409);
  try{
   $existing=$this->db->table('ws_attendance_corrections')->where('user_id',$actor['id'])->where('request_key',$key)->first();
   if($existing){if(!hash_equals($existing->request_hash,$hash))throw new WorkshopException('同一申请编号不能用于不同内容。',409);return ['message'=>'补正申请已保存，请查看审核状态。','id'=>(int)$existing->id];}
   $state=$this->attendance->state($actor);$last=$state['records'][0]??null;
   if(!($state['needs_correction']??false)||!$last||$last['id']!==$source||$time<=$last['time'])throw new WorkshopException('记录已变化或补正时间不晚于签到，请刷新核对。',409);
   return $this->db->transaction(function()use($actor,$key,$hash,$last,$time,$reason){
    if($this->db->table('ws_attendance_corrections')->where('user_id',$actor['id'])->where('source_record_id',$last['id'])->whereIn('status',['pending','processing'])->exists())throw new WorkshopException('此记录已有待处理申请，请先查看审核结果。',409);
    $now=gmdate('Y-m-d H:i:s');$id=$this->db->table('ws_attendance_corrections')->insertGetId(['user_id'=>$actor['id'],'source_record_id'=>$last['id'],'source_time'=>$last['time'],'requested_time'=>$time,'reason'=>$reason,'status'=>'pending','request_key'=>$key,'request_hash'=>$hash,'created_at'=>$now,'updated_at'=>$now]);
    $this->audit($actor['id'],'attendance.correction.requested',$id,null,['source_id'=>$last['id'],'source_time'=>$last['time'],'requested_time'=>$time,'reason'=>$reason,'status'=>'pending']);
    return ['message'=>'申请已提交，请等待另一位老师或总负责人审核。审核前不会改动签到记录。','id'=>$id];
   });
  }finally{$lock->release();}
 }
 public function review(array $actor,array $data): array
 {
  if(!$this->manager($actor))throw new WorkshopException('只有老师或总负责人可以审核考勤补正。',403);
  if(array_diff(array_keys($data),['id','decision','comment']))throw new WorkshopException('请使用补正审核表单。');
  $id=(int)($data['id']??0);$decision=$data['decision']??'';$comment=Policy::text($data['comment']??'',1000,true);
  if(!in_array($decision,['approve','reject'],true))throw new WorkshopException('请选择通过或退回。');
  $row=$this->db->table('ws_attendance_corrections')->where('id',$id)->first();if(!$row)throw new WorkshopException('补正申请不存在。',404);
  if((int)$row->user_id===$actor['id'])throw new WorkshopException('不能审核本人的补正申请，请由另一位老师或总负责人核实。',403);
  $lock=Cache::lock('workshop-attendance-'.$row->user_id,90);if(!$lock->get())throw new WorkshopException('该成员的考勤操作正在处理中，请稍后重试。',409);
  try{
   $row=$this->db->transaction(function()use($actor,$id,$decision,$comment){
    $row=$this->db->table('ws_attendance_corrections')->where('id',$id)->lockForUpdate()->first();
    if($row->status==='approved'){if($decision==='approve')return $row;throw new WorkshopException('已通过的补正不能再退回。',409);}
    if(!in_array($row->status,['pending','processing'],true))throw new WorkshopException('申请已被处理，请刷新查看。',409);
    $target=$this->db->table('zp_user')->where('id',$row->user_id)->first();$person=$this->db->table('ws_people')->where('user_id',$row->user_id)->first();
    if(!$target||strtolower($target->status)!=='a'||((int)$target->role!==50&&(!$person||$person->status!=='approved'||!$person->email_verified_at)))throw new WorkshopException('申请人已停用或未通过审核，不能补写考勤。',409);
    if($row->status==='processing'){
     if($decision!=='approve'||(int)$row->reviewer_id!==$actor['id']||$row->review_comment!==$comment)throw new WorkshopException('正在核对此前审核，请由原审核人使用原意见重试。',409);
     return $row;
    }
    $status=$decision==='approve'?'processing':'rejected';$now=gmdate('Y-m-d H:i:s');
    $this->db->table('ws_attendance_corrections')->where('id',$id)->update(['status'=>$status,'reviewer_id'=>$actor['id'],'review_comment'=>$comment,'reviewed_at'=>$now,'updated_at'=>$now]);
    $this->audit($actor['id'],'attendance.correction.reviewed',$id,['status'=>$row->status],['status'=>$status,'comment'=>$comment]);
    return $this->db->table('ws_attendance_corrections')->where('id',$id)->first();
   });
   if($row->status==='rejected')return ['message'=>'申请已退回，原始记录没有改动。'];
   if($row->status==='approved')return ['message'=>'补正已完成，不会重复追加记录。'];
   // The processing decision is durable before calling native HR. Retry finds its stable event ID.
   $record=$this->attendance->appendApprovedCheckout((array)$row);
   return $this->db->transaction(function()use($actor,$row,$record){
    $fresh=$this->db->table('ws_attendance_corrections')->where('id',$row->id)->lockForUpdate()->first();
    if($fresh->status!=='approved'){
     $now=gmdate('Y-m-d H:i:s');$this->db->table('ws_attendance_corrections')->where('id',$row->id)->update(['status'=>'approved','native_record_id'=>$record['id'],'updated_at'=>$now]);
     $this->audit($actor['id'],'attendance.correction.applied',(int)$row->id,['status'=>'processing'],['status'=>'approved','record'=>$record,'reviewer_id'=>(int)$row->reviewer_id]);
    }
    return ['message'=>'补正已通过并同步签到记录，原始签到保留。','record'=>$record];
   });
  }finally{$lock->release();}
 }
}
