<?php
namespace Leantime\Domain\Workshop;

use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\RateLimiter;

/** Minimal authenticated adapter. Retrieval, embeddings and generation remain upstream. */
final class Knowledge
{
    private static function config(): array
    {
        $file='/run/workshop-ai/config.json';
        if (!is_readable($file)) return [];
        try { $config=json_decode(file_get_contents($file),true,32,JSON_THROW_ON_ERROR); }
        catch (\Throwable) { return []; }
        return is_array($config)?$config:[];
    }
    public static function serverConfiguration(): array {return self::config();}
    public static function available(array $authorizedIds): array
    {
        $config=self::config();
        if (empty($config['api_key'])) return [];
        $db=app(\Leantime\Core\Db\Db::class)->getConnection();$managed=$db->getSchemaBuilder()->hasTable('ws_knowledge_libraries')?$db->table('ws_knowledge_libraries')->whereIn('project_id',$authorizedIds)->get()->keyBy('project_id'):collect();
        return array_values(array_filter($authorizedIds,fn($id)=>isset($managed[$id])?$managed[$id]->status==='ready':!empty($config['project_workspaces'][(string)$id])));
    }
    public function ask(array $actor, int $projectId, string $question): array
    {
        $config=self::config();$slug=$config['project_workspaces'][(string)$projectId]??'';
        $db=app(\Leantime\Core\Db\Db::class)->getConnection();$managed=$db->getSchemaBuilder()->hasTable('ws_knowledge_libraries')?$db->table('ws_knowledge_libraries')->where('project_id',$projectId)->first():null;
        if($managed){if($managed->status!=='ready')throw new WorkshopException('项目资料正在同步，暂不使用旧索引回答，请稍后重试。',409);$slug=$managed->active_slug;}
        if($managed&&!$db->table('ws_knowledge_sources')->where('project_id',$projectId)->where('status','active')->exists())return ['answer'=>'资料中没有找到依据。','sources'=>[],'project_id'=>$projectId,'library_revision'=>(int)$managed->revision,'notice'=>'当前项目没有已发布的问答资料。'];
        // Upstream address is deployment-owned; request input never selects a URL or workspace.
        if (($config['base_url']??'')!=='http://workshop-knowledge:3001/api/v1' || empty($config['api_key']) || !preg_match('/^[a-zA-Z0-9_-]{1,200}$/D',$slug)) {
            throw new WorkshopException('这个项目还没有接入资料库，请联系管理员配置。',409);
        }
        $key='workshop-knowledge:'.$actor['id'];
        if (RateLimiter::tooManyAttempts($key,8)) throw new WorkshopException('提问较频繁，请稍后再试。',429);
        $lock=Cache::lock('workshop-knowledge-generation',80);
        if (!$lock->get()) throw new WorkshopException('问答助手正在回答其他问题，请稍后再试。',429);
        try {
            RateLimiter::hit($key,60);
            try {
                $response=Http::connectTimeout(3)->timeout(60)->withToken($config['api_key'])->acceptJson()->post($config['base_url'].'/workspace/'.rawurlencode($slug).'/chat',[
                    'message'=>str_replace(['@','/'],['＠','／'],$question).' /no_think','mode'=>'query',
                    'sessionId'=>'workshop-'.$actor['id'].'-'.$projectId.'-'.bin2hex(random_bytes(12)),
                    'attachments'=>[],
                ]);
                if (!$response->successful()) throw new \RuntimeException('upstream unavailable');
                $result=$response->json();
                if (!is_array($result)||!empty($result['error'])||($result['type']??'')==='abort') throw new \RuntimeException('upstream failed');
            } catch (\Throwable) {
                // Never log tokens, private questions, source contents or upstream internal errors.
                throw new WorkshopException('问答服务暂时不可用或超时，问题已保留，请稍后重试。',503);
            }
            $sources=[];
            foreach (array_slice((array)($result['sources']??[]),0,5) as $source) {
                if (!is_array($source)) continue;
                $excerpt=trim(preg_replace('/<document_metadata>.*?<\/document_metadata>/s','',(string)($source['chunk']??$source['text']??'')));
                $title=(string)($source['title']??'');
                if ($title==='' || preg_match('/^\.[a-zA-Z0-9]+$/D',$title)) $title=strtok($excerpt,"\n")?:'项目资料';
                $sources[]=['title'=>mb_substr(basename(str_replace('\\','/',$title)),0,200),
                    'excerpt'=>mb_substr($excerpt,0,1200)];
            }
            $answer=trim(preg_replace('/<think>.*?<\/think>/s','',(string)($result['textResponse']??'')));
            if (!$sources) $answer='资料中没有找到依据。';
            if ($answer==='') throw new WorkshopException('没有获得完整回答，请稍后重试。',503);
            if($managed){$fresh=$db->table('ws_knowledge_libraries')->where('project_id',$projectId)->first();if(!$fresh||$fresh->status!=='ready'||$fresh->revision!==$managed->revision)throw new WorkshopException('回答期间资料版本已变化，请重新提问。',409);}
            return ['answer'=>mb_substr($answer,0,12000),'sources'=>$sources,'project_id'=>$projectId,'library_revision'=>$managed?(int)$managed->revision:null,
                'notice'=>'回答仅依据当前项目接入的资料，请结合原文核实。'];
        } finally { $lock->release(); }
    }
}
