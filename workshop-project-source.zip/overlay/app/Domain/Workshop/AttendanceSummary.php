<?php
namespace Leantime\Domain\Workshop;

/** Read-only presentation of native check-in events. No attendance eligibility rules. */
final class AttendanceSummary
{
 public static function build(array $records, \DateTimeImmutable $monday, \DateTimeImmutable $now, bool $complete=true): array
 {
  $zone=new \DateTimeZone('Asia/Shanghai');$monday=$monday->setTimezone($zone)->setTime(0,0);$now=$now->setTimezone($zone);
  $end=$monday->modify('+7 days');$days=[];
  for($i=0;$i<7;$i++){$date=$monday->modify("+$i days")->format('Y-m-d');$days[$date]=['date'=>$date,'sign_ins'=>0,'sessions'=>0,'seconds'=>0,'issues'=>[]];}
  usort($records,fn($a,$b)=>strcmp($a['time'],$b['time'])?:strcmp($a['name'],$b['name']));
  $open=null;$ambiguous=false;
  $issue=static function(string $time,string $text)use(&$days){$date=substr($time,0,10);if(isset($days[$date]))$days[$date]['issues'][]=$text;};
  foreach($records as $r){
   $time=\DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',substr($r['time'],0,19),$zone);
   if(!$time||$time->format('Y-m-d H:i:s')!==substr($r['time'],0,19))continue;
   if($time>$now)continue;
   $kind=$r['log_type'];$date=$time->format('Y-m-d');
   if($kind==='IN'){
    if(isset($days[$date]))$days[$date]['sign_ins']++;
    if($open){$issue($open['time'],'连续签到，时段待核对');$issue($r['time'],'连续签到，时段待核对');$ambiguous=true;}
    else{$open=$r;$ambiguous=false;}
   }elseif($kind==='OUT'){
    if(!$open){$issue($r['time'],'签退缺少对应签到');continue;}
    $start=new \DateTimeImmutable($open['time'],$zone);
    if(!$ambiguous&&$time>$start){
     // Split an actual closed interval at local midnight; clip to this week.
     foreach($days as $day=>&$row){$lo=max($start->getTimestamp(),(new \DateTimeImmutable($day,$zone))->getTimestamp());$hi=min($time->getTimestamp(),(new \DateTimeImmutable($day,$zone))->modify('+1 day')->getTimestamp());if($hi>$lo){$row['seconds']+=$hi-$lo;$row['sessions']++;}}unset($row);
    }elseif(!$ambiguous){$issue($r['time'],'签到签退顺序异常');}
    $open=null;$ambiguous=false;
   }else{$issue($r['time'],'未知考勤类型，待核对');}
  }
  if($open){$issue($open['time'],'未签退，不计时长');if(substr($open['time'],0,10)<$monday->format('Y-m-d'))$days[$monday->format('Y-m-d')]['issues'][]='此前有未签退记录，待补正';}
  $seconds=0;$ins=0;$issues=0;
  foreach($days as &$day){$day['issues']=array_values(array_unique($day['issues']));$seconds+=$day['seconds'];$ins+=$day['sign_ins'];$issues+=count($day['issues']);if(!$complete)$day['seconds']=null;}unset($day);
  return ['start'=>$monday->format('Y-m-d'),'end'=>$end->modify('-1 day')->format('Y-m-d'),'complete'=>$complete,'sign_ins'=>$ins,'seconds'=>$complete?$seconds:null,'issue_count'=>$issues,'days'=>array_values($days)];
 }
}
