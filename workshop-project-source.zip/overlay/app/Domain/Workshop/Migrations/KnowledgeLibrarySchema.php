<?php
namespace Leantime\Domain\Workshop\Migrations;
use Illuminate\Database\ConnectionInterface;use Illuminate\Database\Schema\Blueprint;
final class KnowledgeLibrarySchema
{
 public function up(ConnectionInterface $db):void
 {
  if(!$db->getSchemaBuilder()->hasTable('ws_knowledge_libraries'))$db->getSchemaBuilder()->create('ws_knowledge_libraries',function(Blueprint $t){$t->unsignedInteger('project_id')->primary();$t->unsignedInteger('revision')->default(0);$t->string('status',20);$t->string('active_slug',200)->nullable();$t->string('working_name',150)->nullable();$t->string('working_slug',200)->nullable();$t->timestamps();});
  if(!$db->getSchemaBuilder()->hasTable('ws_knowledge_sources'))$db->getSchemaBuilder()->create('ws_knowledge_sources',function(Blueprint $t){$t->bigIncrements('id');$t->unsignedInteger('project_id');$t->unsignedInteger('user_id');$t->string('title',190);$t->string('stored_file',200);$t->string('extension',10);$t->unsignedInteger('bytes');$t->char('sha256',64);$t->string('request_key',80);$t->char('request_hash',64);$t->string('status',20)->default('active');$t->boolean('upload_attempted')->default(false);$t->text('native_paths')->nullable();$t->timestamps();$t->unique(['user_id','request_key']);$t->index(['project_id','status']);});
  if(!$db->getSchemaBuilder()->hasColumn('ws_knowledge_sources','replaces_source_id'))$db->getSchemaBuilder()->table('ws_knowledge_sources',function(Blueprint $t){$t->unsignedBigInteger('replaces_source_id')->nullable();});
  $db->table('ws_migrations')->insertOrIgnore(['version'=>'008_knowledge_versions','applied_at'=>gmdate('Y-m-d H:i:s')]);
  $db->table('ws_migrations')->insertOrIgnore(['version'=>'007_knowledge_library','applied_at'=>gmdate('Y-m-d H:i:s')]);
 }
}
