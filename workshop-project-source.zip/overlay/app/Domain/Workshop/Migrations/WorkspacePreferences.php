<?php
namespace Leantime\Domain\Workshop\Migrations;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Schema\Blueprint;
/** Additive metadata only; no business data or credentials are rewritten. */
final class WorkspacePreferences
{
    public function up(ConnectionInterface $db): void
    {
        $schema = $db->getSchemaBuilder();
        if (!$schema->hasTable('ws_settings')) {
            $schema->create('ws_settings', function (Blueprint $t) {
                $t->string('key', 60)->primary(); $t->text('value'); $t->unsignedInteger('revision')->default(1); $t->timestamps();
            });
        }
        $db->table('ws_settings')->insertOrIgnore(['key'=>'identity', 'value'=>json_encode(['name'=>'创新工坊']), 'revision'=>1,
            'created_at'=>gmdate('Y-m-d H:i:s'), 'updated_at'=>gmdate('Y-m-d H:i:s')]);
        if (!$schema->hasTable('ws_preferences')) {
            $schema->create('ws_preferences', function (Blueprint $t) {
                $t->unsignedInteger('user_id')->primary(); $t->text('preferences_json'); $t->timestamps();
            });
        }
        $db->table('ws_migrations')->insertOrIgnore(['version'=>'002_workspace_preferences','applied_at'=>gmdate('Y-m-d H:i:s')]);
    }
}
