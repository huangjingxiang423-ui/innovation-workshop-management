<?php
namespace Leantime\Domain\Workshop\Migrations;
use Illuminate\Database\ConnectionInterface;use Illuminate\Database\Schema\Blueprint;
final class ProjectGroupSyncSchema
{
 public function up(ConnectionInterface $db):void
 {
  if(!$db->getSchemaBuilder()->hasTable('ws_native_project_groups'))$db->getSchemaBuilder()->create('ws_native_project_groups',function(Blueprint $t){$t->unsignedInteger('project_id')->primary();$t->string('native_group',190)->unique();$t->string('source',80);$t->timestamps();});
  if(!$db->getSchemaBuilder()->hasTable('ws_native_access_sync'))$db->getSchemaBuilder()->create('ws_native_access_sync',function(Blueprint $t){$t->unsignedInteger('user_id')->primary();$t->unsignedInteger('revision')->default(1);$t->string('status',30)->default('pending');$t->string('last_error',50)->nullable();$t->timestamp('verified_at')->nullable();$t->timestamps();});
  $db->table('ws_migrations')->insertOrIgnore(['version'=>'009_project_group_sync','applied_at'=>gmdate('Y-m-d H:i:s')]);
 }
}
