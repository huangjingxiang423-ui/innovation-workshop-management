<?php
namespace Leantime\Domain\Workshop\Migrations;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Schema\Blueprint;
/** External writes need a committed intent before contacting their native service. */
final class BridgeRequests
{
 public function up(ConnectionInterface $db): void
 {
  $schema=$db->getSchemaBuilder();
  if (!$schema->hasTable('ws_bridge_requests')) $schema->create('ws_bridge_requests',function(Blueprint $t){
   $t->bigIncrements('id');$t->unsignedInteger('user_id');$t->string('request_key',80);$t->string('operation',40);
   $t->char('request_hash',64);$t->text('payload_json');$t->text('response_json')->nullable();$t->timestamps();
   $t->unique(['user_id','request_key']);
  });
  $db->table('ws_migrations')->insertOrIgnore(['version'=>'003_bridge_requests','applied_at'=>gmdate('Y-m-d H:i:s')]);
 }
}
