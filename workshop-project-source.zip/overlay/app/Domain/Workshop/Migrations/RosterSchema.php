<?php
namespace Leantime\Domain\Workshop\Migrations;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Schema\Blueprint;
final class RosterSchema
{
 public function up(ConnectionInterface $db): void
 {
  $schema=$db->getSchemaBuilder();
  if(!$schema->hasTable('ws_roster'))$schema->create('ws_roster',function(Blueprint $t){
   $t->increments('id');$t->string('student_no',64);$t->string('name',60);
   $t->unsignedInteger('project_id');$t->string('role',16);$t->unsignedInteger('revision')->default(1);$t->timestamps();
   $t->unique(['student_no','project_id']);
  });
  $db->table('ws_migrations')->insertOrIgnore(['version'=>'004_roster','applied_at'=>gmdate('Y-m-d H:i:s')]);
 }
}
