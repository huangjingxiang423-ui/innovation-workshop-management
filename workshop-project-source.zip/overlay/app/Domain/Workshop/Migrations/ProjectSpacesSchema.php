<?php
namespace Leantime\Domain\Workshop\Migrations;
use Illuminate\Database\ConnectionInterface;use Illuminate\Database\Schema\Blueprint;
final class ProjectSpacesSchema
{
 public function up(ConnectionInterface $db):void
 {
  if(!$db->getSchemaBuilder()->hasTable('ws_project_spaces'))$db->getSchemaBuilder()->create('ws_project_spaces',function(Blueprint $t){
   $t->unsignedInteger('project_id')->primary();$t->string('native_group',190)->unique();$t->string('owner_uid',190);$t->string('folder_path',190)->unique();$t->unsignedBigInteger('folder_id')->nullable();$t->string('room_name',190)->unique();$t->string('room_token',64)->nullable();foreach(['group_attempted','folder_attempted','room_attempted'] as $field)$t->boolean($field)->default(false);$t->string('status',30)->default('pending');$t->string('last_error',50)->nullable();$t->timestamps();
  });
  $db->table('ws_migrations')->insertOrIgnore(['version'=>'011_project_spaces','applied_at'=>gmdate('Y-m-d H:i:s')]);
 }
}
