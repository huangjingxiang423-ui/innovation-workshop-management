<?php

namespace Leantime\Domain\Workshop\Migrations;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Schema\Blueprint;

/** Additive, versioned migration. Never run DDL from a web request. */
final class InitialSchema
{
    public function up(ConnectionInterface $db): void
    {
        $schema = $db->getSchemaBuilder();
        if (!$schema->hasTable('ws_migrations')) {
            $schema->create('ws_migrations', function (Blueprint $t) {
                $t->string('version', 80)->primary();
                $t->dateTime('applied_at');
            });
        }
        if ($db->table('ws_migrations')->where('version', '001_core')->exists()) {
            return;
        }
        // Each table is restart-safe after a MySQL DDL interruption.
        $tables = [
            'ws_people' => function (Blueprint $t) {
                $t->unsignedInteger('user_id')->primary();
                $t->string('student_no', 64)->unique();
                $t->string('status', 20)->default('pending')->index();
                $t->string('workshop_role', 20)->default('member');
                $t->dateTime('email_verified_at')->nullable();
                $t->timestamps();
            },
            'ws_email_tokens' => function (Blueprint $t) {
                $t->char('token_hash', 64)->primary();
                $t->unsignedInteger('user_id')->index();
                $t->dateTime('expires_at');
                $t->dateTime('used_at')->nullable();
                $t->dateTime('created_at');
            },
            'ws_projects' => function (Blueprint $t) {
                $t->unsignedInteger('project_id')->primary();
                $t->string('stage', 120)->default('启动');
                $t->text('goal')->nullable();
                $t->dateTime('archived_at')->nullable();
                $t->unsignedInteger('revision')->default(1);
                $t->timestamps();
            },
            'ws_memberships' => function (Blueprint $t) {
                $t->increments('id');
                $t->unsignedInteger('project_id')->index();
                $t->unsignedInteger('user_id')->index();
                $t->string('role', 16)->default('member');
                $t->boolean('active')->default(true);
                $t->timestamps();
                $t->unique(['project_id', 'user_id']);
            },
            'ws_tasks' => function (Blueprint $t) {
                $t->unsignedInteger('task_id')->primary();
                $t->unsignedInteger('revision')->default(1);
                $t->dateTime('baseline_due')->nullable();
                $t->text('block_reason')->nullable();
                $t->text('support_needed')->nullable();
                $t->boolean('cancelled')->default(false);
                $t->timestamps();
            },
            'ws_submissions' => function (Blueprint $t) {
                $t->increments('id');
                $t->unsignedInteger('task_id')->index();
                $t->unsignedInteger('user_id');
                $t->text('content');
                $t->text('links_json');
                $t->text('files_json');
                $t->dateTime('created_at');
            },
            'ws_reviews' => function (Blueprint $t) {
                $t->increments('id');
                $t->unsignedInteger('submission_id')->unique();
                $t->unsignedInteger('user_id');
                $t->string('decision', 16);
                $t->text('comment');
                $t->dateTime('created_at');
            },
            'ws_requests' => function (Blueprint $t) {
                $t->increments('id');
                $t->unsignedInteger('user_id');
                $t->string('request_key', 80);
                $t->char('request_hash', 64);
                $t->longText('response_json')->nullable();
                $t->dateTime('created_at');
                $t->unique(['user_id', 'request_key']);
            },
            'ws_audit' => function (Blueprint $t) {
                $t->bigIncrements('id');
                $t->unsignedInteger('actor_id')->nullable();
                $t->unsignedInteger('project_id')->nullable()->index();
                $t->string('action', 60);
                $t->string('entity', 40);
                $t->unsignedInteger('entity_id')->nullable();
                $t->text('before_json')->nullable();
                $t->text('after_json')->nullable();
                $t->dateTime('created_at')->index();
            },
        ];
        foreach ($tables as $name => $definition) {
            if (!$schema->hasTable($name)) {
                $schema->create($name, $definition);
            }
        }
        $db->table('ws_migrations')->insert(['version' => '001_core', 'applied_at' => gmdate('Y-m-d H:i:s')]);
    }
}
