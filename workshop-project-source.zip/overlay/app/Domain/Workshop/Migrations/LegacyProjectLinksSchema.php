<?php
namespace Leantime\Domain\Workshop\Migrations;
use Illuminate\Database\ConnectionInterface;use Illuminate\Database\Schema\Blueprint;
final class LegacyProjectLinksSchema
{
 public function up(ConnectionInterface $db):void
 {
  if(!$db->getSchemaBuilder()->hasColumn('ws_project_spaces','origin'))$db->getSchemaBuilder()->table('ws_project_spaces',function(Blueprint $t){$t->string('origin',20)->default('managed');});
  $db->table('ws_migrations')->insertOrIgnore(['version'=>'012_legacy_project_links','applied_at'=>gmdate('Y-m-d H:i:s')]);
 }
}
