<?php
namespace Leantime\Domain\Workshop\Migrations;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Schema\Blueprint;
final class AttendanceCorrectionsSchema {
 public function up(ConnectionInterface $db): void {
  if(!$db->getSchemaBuilder()->hasTable('ws_attendance_corrections'))$db->getSchemaBuilder()->create('ws_attendance_corrections',function(Blueprint $t){
   $t->bigIncrements('id');$t->unsignedInteger('user_id');$t->string('source_record_id',140);$t->dateTime('source_time');$t->dateTime('requested_time');$t->text('reason');$t->string('status',20);$t->string('request_key',80);$t->char('request_hash',64);$t->unsignedInteger('reviewer_id')->nullable();$t->text('review_comment')->nullable();$t->dateTime('reviewed_at')->nullable();$t->string('native_record_id',140)->nullable();$t->timestamps();$t->unique(['user_id','request_key']);$t->index(['status','user_id']);
  });
  $db->table('ws_migrations')->insertOrIgnore(['version'=>'006_attendance_corrections','applied_at'=>gmdate('Y-m-d H:i:s')]);
 }
}
