<?php
namespace Leantime\Domain\Workshop\Migrations;
use Illuminate\Database\ConnectionInterface;use Illuminate\Database\Schema\Blueprint;
final class MeetingTaskSourceSchema
{
 public function up(ConnectionInterface $db):void
 {
  if(!$db->getSchemaBuilder()->hasTable('ws_task_origins'))$db->getSchemaBuilder()->create('ws_task_origins',function(Blueprint $t){$t->unsignedInteger('task_id')->primary();$t->string('source_type',30);$t->string('source_path',2048);$t->unsignedInteger('created_by');$t->timestamp('created_at');});
  $db->table('ws_migrations')->insertOrIgnore(['version'=>'013_meeting_task_source','applied_at'=>gmdate('Y-m-d H:i:s')]);
 }
}
