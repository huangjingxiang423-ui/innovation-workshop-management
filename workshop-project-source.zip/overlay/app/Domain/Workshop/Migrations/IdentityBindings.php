<?php
namespace Leantime\Domain\Workshop\Migrations;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Database\Schema\Blueprint;
final class IdentityBindings
{
 public function up(ConnectionInterface $db):void
 {
  if(!$db->getSchemaBuilder()->hasTable('ws_identity_bindings'))$db->getSchemaBuilder()->create('ws_identity_bindings',function(Blueprint $t){
   $t->unsignedInteger('user_id')->primary();$t->string('native_uid',64)->unique();$t->unsignedInteger('bound_by');$t->timestamps();
  });
  $db->table('ws_migrations')->insertOrIgnore(['version'=>'005_identity_bindings','applied_at'=>gmdate('Y-m-d H:i:s')]);
 }
}
