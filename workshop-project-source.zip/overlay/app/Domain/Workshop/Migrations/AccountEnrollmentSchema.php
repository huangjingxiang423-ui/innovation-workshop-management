<?php
namespace Leantime\Domain\Workshop\Migrations;
use Illuminate\Database\ConnectionInterface;use Illuminate\Database\Schema\Blueprint;
final class AccountEnrollmentSchema
{
 public function up(ConnectionInterface $db):void
 {
  if(!$db->getSchemaBuilder()->hasTable('ws_account_enrollments'))$db->getSchemaBuilder()->create('ws_account_enrollments',function(Blueprint $t){$t->unsignedInteger('user_id')->primary();$t->string('native_uid',64)->unique();$t->string('email',190);$t->string('name',120);$t->string('status',30);$t->string('mail_status',30)->default('unconfirmed');$t->string('auth_mode',16)->default('core');$t->unsignedInteger('created_by');$t->timestamps();});
  $db->table('ws_migrations')->insertOrIgnore(['version'=>'010_account_enrollment','applied_at'=>gmdate('Y-m-d H:i:s')]);
 }
}
