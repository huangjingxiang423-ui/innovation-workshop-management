<?php
namespace Leantime\Domain\Workshop;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\{Cache,Http};
/** Durable group-membership reconciliation through native provisioning APIs.
 * This owns only registered project groups, not arbitrary personal shares or legacy direct ACLs.
 */
final class ProjectGroupSync
{
 public function __construct(private ConnectionInterface $db){}
 public function queue(int $user):void
 {
  if(!$this->db->table('ws_identity_bindings')->where('user_id',$user)->exists())return;
  $now=gmdate('Y-m-d H:i:s');$this->db->table('ws_native_access_sync')->insertOrIgnore(['user_id'=>$user,'revision'=>0,'status'=>'pending','created_at'=>$now,'updated_at'=>$now]);
  $this->db->table('ws_native_access_sync')->where('user_id',$user)->update(['revision'=>$this->db->raw('revision + 1'),'status'=>'pending','last_error'=>null,'updated_at'=>$now]);
 }
 private function context(int $user):array
 {
  $binding=$this->db->table('ws_identity_bindings')->where('user_id',$user)->first();if(!$binding)throw new WorkshopException('该成员尚未开通消息与资料身份。',409);
  $p=$this->db->table('ws_people as w')->join('zp_user as u','u.id','=','w.user_id')->where('w.user_id',$user)->select('w.*','u.status as account_status')->first();
  if(!$p)throw new WorkshopException('维护账号不能通过学员项目群组同步修改。',409);
  $eligible=$p->status==='approved'&&$p->email_verified_at&&strtolower((string)$p->account_status)==='a';
  $mapping=$this->db->table('ws_native_project_groups')->orderBy('project_id')->get();$all=[];$desired=[];
  foreach($mapping as $m){$group=(string)$m->native_group;if($group===''||mb_strtolower($group)==='admin'||strlen($group)>190)throw new WorkshopException('项目群组登记异常，请联系维护人员核对。',409);$all[]=$group;
   if($eligible&&(in_array($p->workshop_role,['manager','teacher'],true)||$this->db->table('ws_memberships')->where('user_id',$user)->where('project_id',$m->project_id)->where('active',1)->exists()))$desired[]=$group;
  }
  if(!$all)throw new WorkshopException('还没有登记受管理的项目群组，不能执行同步。',409);
  return ['uid'=>(string)$binding->native_uid,'managed'=>$all,'desired'=>$desired];
 }
 private function client(string $cookie,string $token='')
 {
  return Http::baseUrl('http://workshop-collaboration')->asForm()->withHeaders(['Cookie'=>$cookie,'Accept'=>'application/json','OCS-APIRequest'=>'true','requesttoken'=>$token])->connectTimeout(3)->timeout(12)->withoutRedirecting();
 }
 private function ocs(string $method,string $path,string $cookie,string $token,array $data=[]):array
 {
  try{$client=$this->client($cookie,$token);$r=$method==='GET'?$client->get('/ocs/v2.php'.$path,['format'=>'json']):$client->send($method,'/ocs/v2.php'.$path.'?format=json',['form_params'=>$data]);$v=$r->json();
   if(!$r->successful()||!is_array($v)||($v['ocs']['meta']['status']??'')!=='ok')throw new \RuntimeException();return $v['ocs']['data']??[];
  }catch(\Throwable){throw new WorkshopException('项目组权限同步结果待核对，请保留当前状态后重试；不会显示为同步完成。',503);}
 }
 /** Small, serialized batches run only in an authenticated maintenance session.
  * Pending rows are durable; closing the browser never discards revoked access.
  */
 public function flush(array $actor,string $cookie,callable $guard):array
 {
  $guard();if(!($actor['owner']??false))throw new WorkshopException('只有系统维护管理员可以处理项目权限同步队列。',403);
  $lock=Cache::lock('workshop-native-groups:queue',180);if(!$lock->get())throw new WorkshopException('项目权限队列正在核对，请稍后查看。',429);
  try{
   $users=$this->db->table('ws_native_access_sync')->where('status','pending')->orderBy('updated_at')->orderBy('user_id')->limit(2)->pluck('user_id');
   $processed=0;$failure=null;$deadline=microtime(true)+30;
   foreach($users as $user){
    if(microtime(true)>$deadline)break;
    try{$this->synchronize($actor,(int)$user,$cookie,$guard);$processed++;}
    catch(WorkshopException $e){$failure=['status'=>$e->status,'message'=>$e->getMessage()];break;}
   }
   $remaining=$this->db->table('ws_native_access_sync')->where('status','pending')->count();
   return ['processed'=>$processed,'remaining'=>$remaining,'blocked'=>$failure!==null,'reason'=>$failure['message']??null,
    'message'=>$failure?'已核对 '.$processed.' 人；其余权限仍待同步。'.$failure['message']:($remaining?'已核对 '.$processed.' 人，还有 '.$remaining.' 人待同步。':'登记项目组权限队列已核对完成。')];
  }finally{$lock->release();}
 }
 public function synchronize(array $actor,int $user,string $cookie,callable $guard):array
 {
  $guard();if(!($actor['owner']??false))throw new WorkshopException('只有系统维护管理员可以同步消息与资料项目群组。',403);
  $lock=Cache::lock('workshop-native-groups:'.$user,120);if(!$lock->get())throw new WorkshopException('该成员的项目权限正在同步，请稍后重试。',429);
  $started=false;
  try{
   $self=$this->db->table('ws_identity_bindings')->where('user_id',$actor['id'])->first();
   try{$r=$this->client($cookie)->get('/index.php/apps/workshop_shell/identity');$identity=$r->json();if(!$r->successful()||!$self||!is_array($identity)||($identity['account_administration']??false)!==true||!hash_equals($self->native_uid,(string)($identity['uid']??''))||mb_strtolower((string)($identity['email']??''))!==mb_strtolower($actor['email']))throw new \RuntimeException();$t=$this->client($cookie)->get('/csrftoken');$token=$t->json('token');if(!$t->successful()||!is_string($token)||$token==='')throw new \RuntimeException();}catch(\Throwable){throw new WorkshopException('请使用已绑定的账号维护管理员统一登录，再执行项目群组同步。',403);}
   $target=$this->context($user);$row=$this->db->table('ws_native_access_sync')->where('user_id',$user)->first();if(!$row){$this->queue($user);$row=$this->db->table('ws_native_access_sync')->where('user_id',$user)->first();}
   $version=(int)$row->revision;$started=true;
   // Force pending before native reads/writes. Any timeout leaves access blocked until reconciled.
   $this->db->table('ws_native_access_sync')->where('user_id',$user)->where('revision',$version)->update(['status'=>'pending','last_error'=>null,'updated_at'=>gmdate('Y-m-d H:i:s')]);
   $path='/cloud/users/'.rawurlencode($target['uid']).'/groups';$raw=$this->ocs('GET',$path,$cookie,$token);$actual=$raw['groups']??null;if(!is_array($actual))throw new WorkshopException('无法确认原生项目群组列表。',503);
   $remove=array_values(array_diff(array_intersect($actual,$target['managed']),$target['desired']));$add=array_values(array_diff($target['desired'],$actual));
   foreach($remove as $g){$guard();$this->ocs('DELETE',$path,$cookie,$token,['groupid'=>$g]);}
   foreach($add as $g){$guard();$this->ocs('POST',$path,$cookie,$token,['groupid'=>$g]);}
   $verified=$this->ocs('GET',$path,$cookie,$token)['groups']??null;if(!is_array($verified))throw new WorkshopException('同步后未取得项目群组核对结果。',503);
   $found=array_values(array_intersect($verified,$target['managed']));$expected=$target['desired'];sort($found);sort($expected);if($found!==$expected)throw new WorkshopException('项目群组尚未与主系统一致，请重试核对。',503);
   $guard();$fresh=$this->context($user);if($fresh!==$target)throw new WorkshopException('同步期间成员权限发生变化，请再次同步最新权限。',409);
   $this->db->transaction(function()use($user,$actor,$version,$add,$remove){$now=gmdate('Y-m-d H:i:s');$changed=$this->db->table('ws_native_access_sync')->where('user_id',$user)->where('revision',$version)->update(['status'=>'verified','last_error'=>null,'verified_at'=>$now,'updated_at'=>$now]);if(!$changed)throw new WorkshopException('同步期间成员权限已更新，请再次同步。',409);$this->db->table('ws_audit')->insert(['actor_id'=>$actor['id'],'project_id'=>null,'action'=>'collaboration.groups_verified','entity'=>'person','entity_id'=>$user,'before_json'=>null,'after_json'=>json_encode(['revision'=>$version,'added'=>count($add),'removed'=>count($remove)]),'created_at'=>$now]);});
   return ['message'=>'已核对登记项目群组的成员权限。个人分享及未登记资源不在本次同步范围。','user_id'=>$user,'status'=>'verified','added'=>count($add),'removed'=>count($remove)];
  }catch(\Throwable $e){if($started)$this->db->table('ws_native_access_sync')->where('user_id',$user)->update(['status'=>'pending','last_error'=>'reconciliation_required','updated_at'=>gmdate('Y-m-d H:i:s')]);throw $e;}finally{$lock->release();}
 }
}
