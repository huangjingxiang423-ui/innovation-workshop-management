<?php
namespace Leantime\Domain\Workshop;
use Illuminate\Database\ConnectionInterface;

/** Workshop email proof and immutable native binding are authoritative together.
 * Called only AFTER the standard OIDC signature/issuer/audience/state/nonce validation.
 * No matching/claiming a core identity by email alone, and no implicit enrollment.
 */
final class OidcIdentity
{
 public function __construct(private ConnectionInterface $db){}
 public function verify(array $claims,string $email): void
 {
  $user=$this->db->table('zp_user')->where('username',mb_strtolower(trim($email)))->first();
  $subject=$claims['sub']??null;
  if(!$user||!is_string($subject)||$subject==='')throw new WorkshopException('账号尚未完成工坊统一身份开通，请联系管理员。',403);
  $person=$this->db->table('ws_people')->where('user_id',$user->id)->first();
  $workshopProof=$person&&$person->status==='approved'&&$person->email_verified_at;
  // Bootstrap maintenance owners predate workshop enrollment; retain their native
  // verified-email requirement. Ordinary students NEVER inherit this exception.
  $maintenanceProof=!$person&&(int)$user->role===50&&in_array($claims['email_verified']??null,[true,'true',1,'1'],true);
  if(!$person&&(int)$user->role===50&&!$maintenanceProof)throw new WorkshopException('维护管理员的统一登录邮箱尚未验证。请先使用邮箱密码入口维护系统，配置发信并验证邮箱后再使用统一登录。',403);
  if(strtolower((string)$user->status)!=='a'||(!$workshopProof&&!$maintenanceProof))throw new WorkshopException('账号须完成工坊邮箱验证与身份审核，且未被停用。',403);
  $binding=$this->db->table('ws_identity_bindings')->where('user_id',$user->id)->first();
  if(!$binding||!hash_equals((string)$binding->native_uid,$subject))throw new WorkshopException('登录身份与已审核工坊账号不一致，请使用本人账号或联系管理员。',403);
  // Never accept a different email from a user-controlled native profile. The core
  // verified email, fixed UID and the cryptographically validated subject must all agree.
  if(mb_strtolower(trim((string)$user->username))!==mb_strtolower(trim($email)))throw new WorkshopException('登录邮箱与工坊核验记录不一致。',403);
 }
}
