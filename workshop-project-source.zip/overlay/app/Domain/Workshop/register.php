<?php

use Leantime\Core\Events\EventDispatcher;

if (config('workshop.enabled', false)) {
    EventDispatcher::add_filter_listener('leantime.domain.auth.*.belowWelcomeText', static function ($content, $params) {
        return '<p class="socialProofContent">创新工坊<br>项目、任务、成果与团队协作。</p>';
    });
}
