<?php
namespace Leantime\Domain\Workshop;
use Illuminate\Database\ConnectionInterface;use Illuminate\Support\Facades\{Http,Cache,Storage};
/** Publishes explicitly project-wide documents through native AnythingLLM parsing/indexing.
 * Each change builds a new immutable workspace; queries stop while reconciliation is pending.
 */
final class KnowledgeLibrary
{
 public function __construct(private ConnectionInterface $db){}
 public function listing(int $project):array
 {
  $library=$this->db->table('ws_knowledge_libraries')->where('project_id',$project)->first();
  $sources=$this->db->table('ws_knowledge_sources')->where('project_id',$project)->select('id','title','bytes','status','replaces_source_id','created_at','updated_at')->orderByRaw("CASE WHEN status = 'active' THEN 0 ELSE 1 END")->orderByDesc('id')->limit(100)->get();
  return ['project_id'=>$project,'status'=>$library->status??'not_created','revision'=>(int)($library->revision??0),'sources'=>$sources,'storage_used_bytes'=>(int)$this->db->table('ws_knowledge_sources')->where('project_id',$project)->sum('bytes'),'storage_limit_bytes'=>$this->storageLimit()];
 }
 private function storageLimit():int{return max(5242880,(int)(Knowledge::serverConfiguration()['storage_limit_bytes']??104857600));}
 private function client(){ $c=Knowledge::serverConfiguration();if(($c['base_url']??'')!=='http://workshop-knowledge:3001/api/v1'||empty($c['api_key']))throw new WorkshopException('知识服务尚未配置。',409);return Http::baseUrl($c['base_url'])->withToken($c['api_key'])->acceptJson()->connectTimeout(3)->timeout(100)->withoutRedirecting(); }
 private function api(string $method,string $path,array $data=[]):array
 {
  try{$r=$method==='GET'?$this->client()->get($path,$data):$this->client()->post($path,$data);$b=$r->json();if(!$r->successful()||!is_array($b)||!empty($b['error']))throw new \RuntimeException();return $b;}catch(WorkshopException $e){throw $e;}catch(\Throwable){throw new WorkshopException('资料同步结果尚待核对，请保留原文件并使用“重试同步”，不会自动重复发布。',503);}
 }
 private function disk(){return Storage::build(['driver'=>'local','root'=>'/var/www/html/userfiles/workshop-knowledge-private','throw'=>true]);}
 private function audit(array $actor,int $project,string $action,?int $id,array $data):void{$this->db->table('ws_audit')->insert(['actor_id'=>$actor['id'],'project_id'=>$project,'action'=>$action,'entity'=>'knowledge','entity_id'=>$id,'before_json'=>null,'after_json'=>json_encode($data,JSON_UNESCAPED_UNICODE),'created_at'=>gmdate('Y-m-d H:i:s')]);}
 private function pending(int $project):void
 {
  $now=gmdate('Y-m-d H:i:s');$this->db->table('ws_knowledge_libraries')->insertOrIgnore(['project_id'=>$project,'revision'=>0,'status'=>'pending','created_at'=>$now,'updated_at'=>$now]);$r=$this->db->table('ws_knowledge_libraries')->where('project_id',$project)->lockForUpdate()->first();$revision=$r->revision+1;
  $this->db->table('ws_knowledge_libraries')->where('project_id',$project)->update(['revision'=>$revision,'status'=>'pending','working_name'=>'ws-project-'.$project.'-r'.$revision.'-'.bin2hex(random_bytes(8)),'working_slug'=>null,'updated_at'=>$now]);
 }
 public function publish(array $actor,int $project,array $file,string $key,callable $guard,int $replaces=0,int $revision=0):array
 {
  if(!preg_match('/^[a-zA-Z0-9_-]{16,80}$/D',$key))throw new WorkshopException('缺少有效发布操作编号。');
  $ext=strtolower(pathinfo($file['name']??'',PATHINFO_EXTENSION));$mime=['pdf'=>['application/pdf'],'docx'=>['application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/zip'],'txt'=>['text/plain'],'md'=>['text/plain','text/markdown']];$tmp=$file['tmp_name']??'';
  if(!isset($mime[$ext])||($file['error']??1)!==UPLOAD_ERR_OK||!is_uploaded_file($tmp)||($file['size']??0)<1||($file['size']??0)>5242880)throw new WorkshopException('请选择5MB以内的PDF、DOCX、TXT或Markdown资料。');
  if(!in_array((new \finfo(FILEINFO_MIME_TYPE))->file($tmp),$mime[$ext],true))throw new WorkshopException('资料实际类型与文件扩展名不符。');
  if($ext==='docx'){$z=new \ZipArchive();if($z->open($tmp)!==true)throw new WorkshopException('DOCX文件损坏。');try{$size=0;if($z->locateName('word/document.xml')===false||$z->numFiles>500)throw new WorkshopException('请上传正常的DOCX文件。');for($i=0;$i<$z->numFiles;$i++){$s=$z->statIndex($i);$size+=$s['size'];if($size>20971520||str_contains(strtolower($s['name']),'vbaproject'))throw new WorkshopException('DOCX内容过大或包含宏。');}}finally{$z->close();}}
  $title=Policy::text(basename(str_replace('\\','/',$file['name'])),190,true);$sha=hash_file('sha256',$tmp);$hash=hash('sha256',$project.'|'.$title.'|'.$sha.($replaces?'|replace:'.$replaces:''));
  $lock=Cache::lock('workshop-knowledge-generation',300);if(!$lock->get())throw new WorkshopException('知识服务正在处理其他操作，请稍后重试同一次发布。',429);
  try{$guard();$old=$this->db->table('ws_knowledge_sources')->where('user_id',$actor['id'])->where('request_key',$key)->first();
   if($old){if($old->status!=='active')throw new WorkshopException('这份资料已撤回，重新发布请使用新的操作编号。',409);if(!hash_equals($old->request_hash,$hash))throw new WorkshopException('同一发布编号不能用于不同资料。',409);$id=$old->id;}
   else{
    if($this->db->table('ws_knowledge_sources')->where('project_id',$project)->where('status','active')->count()>=($replaces?21:20))throw new WorkshopException('每项目当前最多20份发布资料，请先撤回不再使用的资料。',409);
    if((int)$this->db->table('ws_knowledge_sources')->where('project_id',$project)->sum('bytes')+(int)$file['size']>$this->storageLimit())throw new WorkshopException('本项目含历史版本的资料已达当前存储额度，请联系管理员调整存储配置。',409);
    $stored=$project.'/'.bin2hex(random_bytes(20)).'.'.$ext;try{$this->disk()->put($stored,file_get_contents($tmp));
    $id=$this->db->transaction(function()use($actor,$project,$title,$stored,$ext,$file,$sha,$key,$hash,$replaces,$revision){if($replaces){$library=$this->db->table('ws_knowledge_libraries')->where('project_id',$project)->lockForUpdate()->first();$prior=$this->db->table('ws_knowledge_sources')->where('id',$replaces)->where('project_id',$project)->where('status','active')->first();if(!$prior||!$library||$library->revision!==$revision)throw new WorkshopException('待替换资料已变化或不属于本项目，请刷新后重试。',409);$this->db->table('ws_knowledge_sources')->where('id',$replaces)->update(['status'=>'withdrawn','updated_at'=>gmdate('Y-m-d H:i:s')]);}$now=gmdate('Y-m-d H:i:s');$id=$this->db->table('ws_knowledge_sources')->insertGetId(['project_id'=>$project,'user_id'=>$actor['id'],'title'=>$title,'stored_file'=>$stored,'extension'=>$ext,'bytes'=>$file['size'],'sha256'=>$sha,'request_key'=>$key,'request_hash'=>$hash,'replaces_source_id'=>$replaces?:null,'status'=>'active','created_at'=>$now,'updated_at'=>$now]);$this->pending($project);$this->audit($actor,$project,'knowledge.published',$id,['title'=>$title,'scope'=>'all_project_members','replaces_source_id'=>$replaces?:null]);return $id;});}catch(\Throwable $e){try{if(!$this->db->table('ws_knowledge_sources')->where('stored_file',$stored)->exists())$this->disk()->delete($stored);}catch(\Throwable){}throw $e;}
   }
   $this->synchronize($actor,$project,$guard);return ['message'=>'资料已发布，本项目成员可在问答中检索。','source_id'=>(int)$id]+$this->listing($project);
  }finally{$lock->release();}
 }
 public function withdraw(array $actor,int $project,int $id,int $revision,callable $guard):array
 {
  $lock=Cache::lock('workshop-knowledge-generation',300);if(!$lock->get())throw new WorkshopException('知识服务正在处理其他操作，请稍后重试。',429);
  try{$guard();$this->db->transaction(function()use($actor,$project,$id,$revision){$r=$this->db->table('ws_knowledge_libraries')->where('project_id',$project)->lockForUpdate()->first();$s=$this->db->table('ws_knowledge_sources')->where('id',$id)->where('project_id',$project)->first();if(!$s)throw new WorkshopException('没有此项目资料。',404);if($s->status==='withdrawn')return;if(!$r||$r->revision!==$revision)throw new WorkshopException('资料已经更新，请刷新后重试。',409);$this->db->table('ws_knowledge_sources')->where('id',$id)->update(['status'=>'withdrawn','updated_at'=>gmdate('Y-m-d H:i:s')]);$this->pending($project);$this->audit($actor,$project,'knowledge.withdrawn',$id,['title'=>$s->title]);});$this->synchronize($actor,$project,$guard);return ['message'=>'资料已撤回，后续问答不再检索该资料；已有回答和历史原件仍保留。']+$this->listing($project);}finally{$lock->release();}
 }
 public function retry(array $actor,int $project,callable $guard):array{$lock=Cache::lock('workshop-knowledge-generation',300);if(!$lock->get())throw new WorkshopException('知识服务繁忙，请稍后重试。',429);try{$guard();$this->synchronize($actor,$project,$guard);return ['message'=>'资料索引已核对。']+$this->listing($project);}finally{$lock->release();}}
 private function pathsFromTree(array $node,string $prefix,string $parent=''):array
 {
  $name=(string)($node['name']??'');$path=$parent===''&&$name==='documents'?'':trim($parent.'/'.$name,'/');$paths=[];
  if(($node['type']??'')==='file'&&str_starts_with($name,$prefix.'.'))$paths[]=$path;
  foreach(($node['items']??[]) as $item)if(is_array($item))$paths=array_merge($paths,$this->pathsFromTree($item,$prefix,$path));return $paths;
 }
 private function synchronize(array $actor,int $project,callable $guard):void
 {
  $r=$this->db->table('ws_knowledge_libraries')->where('project_id',$project)->first();if(!$r||$r->status==='ready')return;
  $docs=$this->db->table('ws_knowledge_sources')->where('project_id',$project)->where('status','active')->orderBy('id')->get();$paths=[];
  foreach($docs as $doc){$known=$doc->native_paths?json_decode($doc->native_paths,true):null;$prefix='ws-source-'.$doc->id.'-'.substr($doc->sha256,0,16);
   if(!$known&&$doc->upload_attempted){$tree=$this->api('GET','/documents');$known=$this->pathsFromTree($tree['localFiles']??[],$prefix);if(!$known)throw new WorkshopException('此前上传结果尚未找到，请稍后重试同步。系统不会重复上传原件。',503);}
   if(!$known){$this->db->table('ws_knowledge_sources')->where('id',$doc->id)->update(['upload_attempted'=>true]);try{$stream=$this->disk()->readStream($doc->stored_file);try{$response=$this->client()->attach('file',$stream,$prefix.'.'.$doc->extension)->post('/document/upload',['metadata'=>json_encode(['title'=>$doc->title])]);$b=$response->json();if(!$response->successful()||empty($b['success'])||empty($b['documents']))throw new \RuntimeException();$known=array_column($b['documents'],'location');}finally{if(is_resource($stream))fclose($stream);}}catch(\Throwable){throw new WorkshopException('资料解析结果尚待核对，请使用重试同步，不会重复上传。',503);}}
   if(!$known)throw new WorkshopException('资料未返回有效解析结果。',503);
   foreach($known as $p)if(!is_string($p)||!preg_match('#^[a-zA-Z0-9_./-]+\.json$#D',$p)||str_contains($p,'..'))throw new WorkshopException('资料服务返回了异常文档路径。',503);
   $this->db->table('ws_knowledge_sources')->where('id',$doc->id)->update(['native_paths'=>json_encode($known)]);$paths=array_merge($paths,$known);
  }
  $slug=$r->working_slug;
  if(!$slug){$all=$this->api('GET','/workspaces');foreach($all['workspaces']??[] as $w)if(($w['name']??'')===$r->working_name){$slug=$w['slug'];break;}
   if(!$slug){$new=$this->api('POST','/workspace/new',['name'=>$r->working_name,'chatMode'=>'query','similarityThreshold'=>0.1,'topN'=>3,'openAiTemp'=>0.1,'openAiPrompt'=>'你是工坊资料助手。只依据当前项目资料回答，给出依据；依据不足请说资料中没有找到依据。/no_think']);$slug=$new['workspace']['slug']??null;}
   if(!is_string($slug)||!preg_match('/^[a-zA-Z0-9_-]{1,200}$/D',$slug))throw new WorkshopException('资料库创建结果待核对。',503);$this->db->table('ws_knowledge_libraries')->where('project_id',$project)->update(['working_slug'=>$slug]);
  }
  $info=$this->api('GET','/workspace/'.rawurlencode($slug));$w=$info['workspace'][0]??$info['workspace']??[];$actual=array_column($w['documents']??[],'docpath');$expected=array_values(array_unique($paths));
  if(array_diff($expected,$actual))$this->api('POST','/workspace/'.rawurlencode($slug).'/update-embeddings',['adds'=>array_values(array_diff($expected,$actual)),'deletes'=>[]]);
  $info=$this->api('GET','/workspace/'.rawurlencode($slug));$w=$info['workspace'][0]??$info['workspace']??[];$actual=array_values(array_unique(array_column($w['documents']??[],'docpath')));sort($expected);sort($actual);if($expected!==$actual)throw new WorkshopException('资料索引尚未完整匹配，问答暂不开放，请重试同步。',503);
  $guard();$this->db->transaction(function()use($actor,$project,$r,$slug){$changed=$this->db->table('ws_knowledge_libraries')->where('project_id',$project)->where('revision',$r->revision)->where('status','pending')->update(['status'=>'ready','active_slug'=>$slug,'updated_at'=>gmdate('Y-m-d H:i:s')]);if(!$changed)throw new WorkshopException('资料版本已变化，请重试核对。',409);$this->audit($actor,$project,'knowledge.index_ready',null,['revision'=>$r->revision]);});
 }
 public function file(int $id):array{$s=$this->db->table('ws_knowledge_sources')->where('id',$id)->first();if(!$s||$s->status!=='active')throw new WorkshopException('资料不存在或已撤回。',404);$path=$this->disk()->path($s->stored_file);if(!is_file($path))throw new WorkshopException('资料原件暂不可用，请联系管理员核对存储。',503);return ['source'=>$s,'path'=>$path];}
}
