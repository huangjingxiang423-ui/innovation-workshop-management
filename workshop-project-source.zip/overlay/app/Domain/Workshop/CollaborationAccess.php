<?php
namespace Leantime\Domain\Workshop;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Http;
use Leantime\Core\Db\Db;
use Illuminate\Database\ConnectionInterface;
/** Gateway prerequisite only: native project/file/room authorization still runs after this check. */
final class CollaborationAccess
{
 private ConnectionInterface $db;
 public function __construct(Db $db){$this->db=$db->getConnection();}
 public function check(array $actor,string $cookie): void
 {
  $binding=$this->db->table('ws_identity_bindings')->where('user_id',$actor['id'])->first();
  if(!$binding)throw new WorkshopException('你的消息与资料身份尚未开通，请联系管理员完成统一账号绑定。',403);
  if($this->db->table('ws_native_access_sync')->where('user_id',$actor['id'])->where('status','pending')->exists())throw new WorkshopException('项目权限变更正在同步，请管理员核对后再进入消息与资料。',409);
  if($cookie==='')throw new WorkshopException('请先统一登录工坊账号。',401);
  try{
   // Never cache the core eligibility decision. Only the authenticated native display identity
   // is briefly cached per opaque cookie hash, reducing fan-out during a native page load.
   $identity=Cache::remember('workshop-native-access:'.hash('sha256',$cookie),2,function()use($cookie){
    $response=Http::withHeaders(['Accept'=>'application/json','Cookie'=>$cookie])->timeout(5)->withoutRedirecting()
      ->get('http://workshop-collaboration/index.php/apps/workshop_shell/identity');
    if($response->status()===401||$response->redirect())throw new WorkshopException('请先登录工坊消息与资料账号。',401);
    if(!$response->successful())throw new WorkshopException('消息与资料服务暂不可用，请稍后重试。',503);
    $body=$response->json();
    if(!is_array($body)||!is_string($body['email']??null)||!is_string($body['uid']??null)||$body['uid']==='')throw new WorkshopException('无法确认消息与资料登录身份，请重新统一登录。',401);
    return ['email'=>mb_strtolower(trim($body['email'])),'uid'=>$body['uid']];
   });
  }catch(WorkshopException $e){throw $e;}catch(\Throwable){throw new WorkshopException('消息与资料服务暂不可用，请稍后重试。',503);}
  if(!hash_equals($binding->native_uid,$identity['uid']))throw new WorkshopException('两处登录身份不一致，请退出后使用同一个工坊账号登录。',403);
  if($identity['email']!==mb_strtolower(trim($actor['email'])))throw new WorkshopException('两处登录身份不一致，请退出后使用同一个工坊账号登录。',403);
 }
}
