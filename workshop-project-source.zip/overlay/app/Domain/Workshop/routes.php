<?php

use Illuminate\Support\Facades\Route;
use Leantime\Domain\Workshop\VerifyCsrfToken;
use Leantime\Domain\Workshop\Controller;

if (config('workshop.enabled', false)) {
    Route::middleware([VerifyCsrfToken::class])->group(function () {
        Route::get('/workshop', [Controller::class, 'index']);
        Route::get('/workshop/open-native/{view}', [Controller::class, 'openNative']);
        Route::get('/workshop/collaboration-access', [Controller::class, 'collaborationAccess']);
        Route::get('/workshop/open/{view}', [Controller::class, 'open']);
        Route::get('/workshop/register', [Controller::class, 'registration']);
        Route::post('/workshop/register', [Controller::class, 'register']);
        Route::post('/workshop/resend', [Controller::class, 'resend']);
        Route::get('/workshop/verify', [Controller::class, 'verify']);
        Route::get('/workshop/export', [Controller::class, 'export']);
        Route::get('/workshop/settings-context',[Controller::class,'settingsContext']);
        Route::get('/workshop/identity', [Controller::class, 'identity']);
        Route::get('/workshop/data', [Controller::class, 'data']);
        Route::get('/workshop/attendance', [Controller::class, 'attendance']);
        Route::get('/workshop/attendance/report',[Controller::class,'attendanceReport']);
        Route::get('/workshop/attendance/export',[Controller::class,'exportAttendanceReport']);
        Route::post('/workshop/attendance/corrections', [Controller::class, 'attendanceCorrection']);
        Route::post('/workshop/attendance/corrections/review', [Controller::class, 'reviewAttendanceCorrection']);
        Route::post('/workshop/attendance', [Controller::class, 'recordAttendance']);
        Route::post('/workshop/enrollment/account',[Controller::class,'openCollaborationAccount']);
        Route::post('/workshop/enrollment/groups',[Controller::class,'syncCollaborationGroups']);
        Route::get('/workshop/project-space',[Controller::class,'projectSpace']);
        Route::get('/workshop/project-space/audit',[Controller::class,'auditProjectSpace']);
        Route::post('/workshop/project-space',[Controller::class,'prepareProjectSpace']);
        Route::post('/workshop/project-space/legacy',[Controller::class,'registerLegacyProjectSpace']);
        Route::post('/workshop/enrollment/groups/flush',[Controller::class,'flushCollaborationGroups']);
        Route::get('/workshop/enrollment/readiness',[Controller::class,'enrollmentReadiness']);
        Route::get('/workshop/roster', [Controller::class, 'roster']);
        Route::post('/workshop/roster/preview', [Controller::class, 'rosterPreview']);
        Route::post('/workshop/action', [Controller::class, 'mutation']);
        Route::post('/workshop/upload', [Controller::class, 'upload']);
        Route::get('/workshop/file/{id}', [Controller::class, 'file'])->whereNumber('id');
        Route::post('/workshop/logout', [Controller::class, 'logout']);
    });
}
