<?php

namespace Leantime\Domain\Workshop;

use Leantime\Domain\Auth\Services\Auth;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Response;

final class Controller
{
    public function __construct(private Service $service) {}

    private function result(callable $action, int $status = 200): JsonResponse
    {
        try {
            return new JsonResponse($action(), $status, ['Cache-Control' => 'no-store']);
        } catch (WorkshopException $e) {
            return new JsonResponse(['error' => $e->getMessage()], $e->status, ['Cache-Control' => 'no-store']);
        } catch (\Throwable $e) {
            \Illuminate\Support\Facades\Log::error('Workshop operation failed', ['exception_type' => get_class($e)]);
            return new JsonResponse(['error' => '服务器未确认保存结果，请保留输入并重试同次操作。'], 503, ['Cache-Control' => 'no-store']);
        }
    }

    public function index(): Response
    {
        if (request()->query('view') === 'knowledge') return new Response('该模块已下线。', 404);
        try { $this->service->actor(); } catch (WorkshopException $e) {
            return $this->accessError($e,false);
        }
        return $this->page(false);
    }

    public function registration(): Response
    {
        return $this->page(true);
    }

    public function open(string $view): Response
    {
        if (!in_array($view, ['overview', 'mine', 'projects', 'tasks', 'reviews', 'timeline', 'people', 'settings', 'attendance'], true)) {
            return new Response('没有此页面。', 404);
        }
        if (session('userdata.id')) {
            try { $this->service->actor(); } catch (WorkshopException $e) {
                return $this->accessError($e,false);
            }
            return new RedirectResponse(BASE_URL.'/workshop?view='.$view);
        }
        session(['workshop.return_view' => $view]);
        $oidcEnabled = app(\Leantime\Core\Configuration\Environment::class)->get('oidcEnable', false);
        return new RedirectResponse(BASE_URL.($oidcEnabled ? '/oidc/login' : '/auth/login'));
    }

    /** Render the real navigation immediately; client data replaces only after authorized loading. */
    private function initialFrame(): string
    {
        $context=$this->service->identity();$actor=$context['actor'];$manager=$this->service->manager($actor);
        $escape=fn($s)=>htmlspecialchars((string)$s,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
        $name=$escape($context['workspace']['name']);$base=$escape(BASE_URL);
        $titles=['overview'=>'工坊总览','mine'=>'我的任务','projects'=>'项目中心','tasks'=>'项目任务','timeline'=>'项目日历','reviews'=>'成果验收'];
        $collaboration=rtrim((string)config('workshop.collaboration_url',''),'/');
        if($collaboration)$titles+=['chat'=>'项目聊天','meetings'=>'组会记录','files'=>'资料与知识库'];
        if($manager)$titles['people']='人员与权限';
        $titles['attendance']='考勤管理';if($actor['owner'])$titles['equipment']='设备预约 · 试用';
        $titles+=['settings'=>'设置'];
        $view=(string)request()->query('view','overview');if(!isset($titles[$view]))$view='overview';
        $icons=json_decode(file_get_contents(__DIR__.'/Templates/navigation-icons.json'),true);
        $navigation=json_decode(file_get_contents(__DIR__.'/../../../public/workshop-assets/navigation.json'),true);
        $nav='';
        foreach($navigation['groups'] as $group){
            if(($group['manager']??false)&&!$manager)continue;
            if(($group['native']??false)&&!$collaboration)continue;
            $key=$group['items'][0][0];$label=$group['label'];
            if($key==='files'&&!$collaboration)continue;
            $path=['chat'=>'/apps/spreed/','files'=>'/apps/files/'][$key]??null;
            $url=$path?$collaboration.$path:BASE_URL.'/workshop?view='.$key;
            $icon=$icons[$group['icon']]??$icons['tasks'];
            $selected=in_array($view,array_column($group['items'],0),true);
            $nav.='<a class="nav-item '.($selected?'selected':'').'" href="'.$escape($url).'"'.($selected?' aria-current="page"':'').'><span class="nav-icon"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$icon.'</svg></span><span>'.$label.'</span></a>';
        }
        return '<div class="layout"><aside class="sidebar"><a class="brand" href="'.$base.'/workshop"><span class="brand-mark">W</span><span>'.$name.'<small>创新 · 协作 · 实践</small></span></a><button class="mobile-nav-toggle" disabled>功能菜单</button><p class="nav-caption">工作空间</p><nav id="main-navigation" aria-label="主导航">'.$nav.'</nav><div class="sidebar-bottom"><div><strong>'.$escape($actor['name']).'</strong></div></div></aside><main class="main"><header class="page-head"><div><p class="eyebrow">'.$name.' <span>/</span> 工作空间</p><h1>'.$titles[$view].'</h1></div></header><section class="panel initial-loading" role="status"><span class="spinner" aria-hidden="true"></span> 正在载入数据…</section></main></div>';
    }

    private function initialData(bool $registration): string
    {
        if($registration)return '';
        try{
            $data=$this->service->state((int)request()->query('project',0),max(1,min(100000,(int)request()->query('page',1))),request()->query('view')==='reviews',(string)request()->query('filter','all'),request()->query('view')==='mine',mb_substr((string)request()->query('search',''),0,100),request()->query('meeting_source',''));
            return '<script type="application/json" id="workshop-initial-data">'.json_encode($data,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_THROW_ON_ERROR).'</script>';
        }catch(WorkshopException){return '';}
    }

    private function nativePath(string $view): ?string
    {
        return ['chat'=>'/apps/spreed/','meetings'=>'/apps/collectives/','files'=>'/apps/files/','settings'=>'/settings/user/workshop-identity'][$view]??null;
    }

    public function openNative(string $view): Response
    {
        $path=$this->nativePath($view);if(!$path)return new Response('没有此页面。',404);
        if(!session('userdata.id')){
            session(['workshop.return_native'=>$view]);
            $oidc=app(\Leantime\Core\Configuration\Environment::class)->get('oidcEnable',false);
            return new RedirectResponse(BASE_URL.($oidc?'/oidc/login':'/auth/login'));
        }
        try{$this->service->actor();}catch(WorkshopException $e){return $this->accessError($e,false);}
        return new RedirectResponse(rtrim((string)config('workshop.collaboration_url',''),'/').$path);
    }

    private function accessError(WorkshopException $error, bool $coreAuthenticated): Response
    {
        $escape=fn($v)=>htmlspecialchars((string)$v,ENT_QUOTES|ENT_SUBSTITUTE,'UTF-8');
        $base=$escape(BASE_URL);
        $panel='<section class="panel"><h2>'.($error->status===503?'服务暂不可用':'请核对工坊账号').'</h2><p class="pre">'.$escape($error->getMessage()).'</p><p class="subtle">如需开通或恢复访问，请联系工坊管理员。</p><a class="button primary" href="'.$base.($coreAuthenticated?'/workshop':'/auth/login').'">'.($coreAuthenticated?'返回工作台':'返回登录').'</a></section>';
        $frame='<main class="registration">'.$panel.'</main>';
        if($coreAuthenticated){try{$frame=preg_replace_callback('#<section class="panel initial-loading".*?</section>#s',fn()=>$panel,$this->initialFrame(),1);$frame=preg_replace('#<h1>.*?</h1>#','<h1>账号与访问</h1>',$frame,1);}catch(\Throwable){}}
        $template=file_get_contents(__DIR__.'/Templates/workspace.html');preg_match('/workshop\.css\?v=([^"\s]+)/',$template,$match);$version=$escape($match[1]??'access');
        $html='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>工坊账号与访问</title><script src="'.$base.'/workshop-assets/appearance-seed.js?v='.$version.'"></script><link rel="stylesheet" href="'.$base.'/workshop-assets/workshop.css?v='.$version.'"></head><body>'.$frame.'</body></html>';
        return new Response($html,$error->status,['Content-Type'=>'text/html; charset=utf-8','Cache-Control'=>'no-store','X-Content-Type-Options'=>'nosniff','Content-Security-Policy'=>"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"]);
    }

    /** Caddy forward_auth calls this GET before native business requests. No client identity headers are trusted. */
    public function collaborationAccess(): Response
    {
        $coreAuthenticated=false;
        try{
            $actor=$this->service->actor();$coreAuthenticated=true;
            app(CollaborationAccess::class)->check($actor,(string)request()->header('Cookie',''));
            return new Response('',204,['Cache-Control'=>'no-store']);
        }catch(WorkshopException $e){
            $method=(string)request()->header('X-Forwarded-Method','GET');
            if($e->status===401&&$method==='GET'&&str_contains((string)request()->header('Accept',''),'text/html')){
                $uri=(string)request()->header('X-Forwarded-Uri','');
                $view=str_contains($uri,'/settings/')?'settings':(str_contains($uri,'/collectives')?'meetings':(str_contains($uri,'/files')||str_contains($uri,'/s/')?'files':'chat'));
                return new RedirectResponse($coreAuthenticated?rtrim((string)config('workshop.collaboration_url',''),'/').'/login?'.http_build_query(['redirect_url'=>$this->nativePath($view)]):BASE_URL.'/workshop/open-native/'.$view);
            }
            if($method==='GET'&&str_contains((string)request()->header('Accept',''),'text/html'))return $this->accessError($e,$coreAuthenticated);
            return new JsonResponse(['error'=>$e->getMessage()],$e->status,['Cache-Control'=>'no-store']);
        }catch(\Throwable){
            return new JsonResponse(['error'=>'暂时无法核对工坊访问权限，请稍后重试。'],503,['Cache-Control'=>'no-store']);
        }
    }

    private function page(bool $registration): Response
    {
        $csrf = htmlspecialchars(csrf_token(), ENT_QUOTES);
        $mode = $registration ? 'register' : 'workspace';
        $base = htmlspecialchars(BASE_URL, ENT_QUOTES);
        $html = file_get_contents(__DIR__.'/Templates/workspace.html');
        $collaboration = rtrim((string) config('workshop.collaboration_url', ''), '/');
        if (!filter_var($collaboration, FILTER_VALIDATE_URL) || !preg_match('#^https?://#', $collaboration)) {
            $collaboration = '';
        }
        $html = str_replace(['{{CSRF}}', '{{MODE}}', '{{BASE}}', '{{COLLABORATION}}', '{{INITIAL}}', '{{DATA}}'],
            [$csrf, $mode, $base, htmlspecialchars($collaboration, ENT_QUOTES), $registration ? '<main class="loading" role="status">正在载入注册表…</main>' : $this->initialFrame(), $this->initialData($registration)], $html);
        return new Response($html, 200, ['Content-Type' => 'text/html; charset=utf-8',
            'Cache-Control' => 'no-store', 'X-Content-Type-Options' => 'nosniff',
            'Referrer-Policy' => 'same-origin',
            'Content-Security-Policy' => "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'"]);
    }

    public function settingsContext():JsonResponse
    {
        return $this->result(function(){$data=$this->service->identity();return $data+['manager'=>$this->service->manager($data['actor']),'csrf_token'=>csrf_token()];});
    }

    public function identity(): JsonResponse
    {
        return $this->result(fn () => $this->service->identity());
    }

    public function data(): JsonResponse
    {
        return $this->result(fn () => request()->query('task_id')
            ? $this->service->detail((int) request()->query('task_id'))
            : $this->service->state((int) request()->query('project_id', 0), (int) request()->query('page', 1),
                request()->query('view') === 'reviews', (string) request()->query('filter', 'all'), request()->query('mine') === '1', (string) request()->query('search', ''),request()->query('meeting_source','')));
    }

    public function export(): Response
    {
        try { return $this->service->exportTasks((int)request()->query('project_id',0)); }
        catch (WorkshopException $e) { return new Response(htmlspecialchars($e->getMessage(),ENT_QUOTES),$e->status,['Content-Type'=>'text/plain; charset=utf-8','Cache-Control'=>'no-store']); }
    }

    public function attendance(): JsonResponse
    { return $this->result(fn () => $this->service->attendance()); }
    public function recordAttendance(): JsonResponse
    { return $this->result(fn () => $this->service->recordAttendance((array)request()->all(),(string)request()->header('Idempotency-Key'))); }

    public function attendanceReport():JsonResponse{return $this->result(fn()=>$this->service->attendanceReport((string)request()->query('week',''),(int)request()->query('user_id',0),(int)request()->query('page',1)));}
    public function exportAttendanceReport():Response{try{return $this->service->exportAttendanceReport((string)request()->query('week',''),(int)request()->query('user_id',0));}catch(WorkshopException $e){return new Response(htmlspecialchars($e->getMessage(),ENT_QUOTES),$e->status,['Content-Type'=>'text/plain; charset=utf-8','Cache-Control'=>'no-store']);}}
    public function attendanceCorrection(): JsonResponse
    { return $this->result(fn () => $this->service->attendanceCorrection((array)request()->all(),(string)request()->header('Idempotency-Key'))); }
    public function reviewAttendanceCorrection(): JsonResponse
    { return $this->result(fn () => $this->service->reviewAttendanceCorrection((array)request()->all())); }

    public function knowledge(): JsonResponse
    {
        return $this->result(fn () => $this->service->knowledge((array) request()->all()));
    }

    public function roster(): JsonResponse
    { return $this->result(fn () => $this->service->roster()); }

    public function rosterPreview(): JsonResponse
    {
        return $this->result(function(){
            if(isset($_FILES['file']))return $this->service->previewRosterFile($_FILES['file']);
            $csv=request()->input('csv');if(!is_string($csv))throw new WorkshopException('请选择 UTF-8 CSV 名单。');
            return $this->service->previewRoster($csv);
        });
    }

    public function openCollaborationAccount():JsonResponse{return $this->result(fn()=>$this->service->openCollaborationAccount((int)request()->input('user_id'),(string)request()->header('Cookie',''),request()->input('resend')===true));}
    public function syncCollaborationGroups():JsonResponse{return $this->result(fn()=>$this->service->syncCollaborationGroups((int)request()->input('user_id'),(string)request()->header('Cookie','')));}
    public function projectSpace():JsonResponse{return $this->result(fn()=>$this->service->projectSpace((int)request()->query('project_id')));}
    public function auditProjectSpace():JsonResponse{return $this->result(fn()=>$this->service->auditProjectSpace((int)request()->query('project_id'),(string)request()->header('Cookie','')));}
    public function prepareProjectSpace():JsonResponse{return $this->result(fn()=>$this->service->projectSpace((int)request()->input('project_id'),(string)request()->header('Cookie',''),true));}
    public function registerLegacyProjectSpace():JsonResponse{return $this->result(fn()=>$this->service->registerLegacyProjectSpace((int)request()->input('project_id'),request()->only(['folder_path','room_token']),(string)request()->header('Cookie','')));}
    public function flushCollaborationGroups():JsonResponse{return $this->result(fn()=>$this->service->flushCollaborationGroups((string)request()->header('Cookie','')));}
    public function enrollmentReadiness():JsonResponse{return $this->result(fn()=>$this->service->enrollmentReadiness((string)request()->header('Cookie','')));}
    public function knowledgeLibrary():JsonResponse{return $this->result(fn()=>$this->service->knowledgeLibrary((int)request()->query('project_id')));}
    public function publishKnowledge():JsonResponse{return $this->result(fn()=>$this->service->publishKnowledge((int)request()->input('project_id'),$_FILES['file']??[],(string)request()->header('Idempotency-Key'),request()->input('shared_with_project')==='1',(int)request()->input('replaces_source_id'),(int)request()->input('revision')));}
    public function withdrawKnowledge():JsonResponse{return $this->result(fn()=>$this->service->withdrawKnowledge((int)request()->input('project_id'),(int)request()->input('source_id'),(int)request()->input('revision')));}
    public function retryKnowledge():JsonResponse{return $this->result(fn()=>$this->service->retryKnowledge((int)request()->input('project_id')));}
    public function knowledgeFile(int $id):Response{try{return $this->service->knowledgeFile($id);}catch(WorkshopException $e){return new Response('资料不存在或没有访问权限。',$e->status);}}

    public function mutation(): JsonResponse
    {
        return $this->result(fn () => $this->service->mutate((string) request()->input('action'),
            (array) request()->input('data', []), (string) request()->header('Idempotency-Key')));
    }

    public function register(): JsonResponse
    {
        return $this->result(fn () => $this->service->register(request()->all(), request()->ip()), 201);
    }

    public function resend(): JsonResponse
    {
        return $this->result(fn () => $this->service->resend((string) request()->input('email'), request()->ip()));
    }

    public function verify(): Response
    {
        try {
            $this->service->verify((string) request()->query('token'));
            return new RedirectResponse(BASE_URL.'/workshop/register?verified=1');
        } catch (WorkshopException $e) {
            return new Response(htmlspecialchars($e->getMessage(), ENT_QUOTES), $e->status,
                ['Content-Type' => 'text/plain; charset=utf-8', 'Cache-Control' => 'no-store', 'Referrer-Policy' => 'no-referrer']);
        }
    }

    public function upload(): JsonResponse
    {
        return $this->result(fn () => $this->service->upload($_FILES['file'] ?? [],
            (int) request()->input('task_id'), (string) request()->header('Idempotency-Key')));
    }

    public function file(int $id): Response
    {
        try { return $this->service->download($id); } catch (WorkshopException $e) {
            return new Response(htmlspecialchars($e->getMessage(), ENT_QUOTES), $e->status, ['Content-Type' => 'text/plain; charset=utf-8', 'Cache-Control' => 'no-store']);
        }
    }

    public function logout(): Response
    {
        session()->invalidate();
        session()->regenerateToken();
        $environment = app(\Leantime\Core\Configuration\Environment::class);
        $collaboration = rtrim((string) config('workshop.collaboration_url', ''), '/');
        if ($environment->get('oidcEnable', false) && filter_var($collaboration, FILTER_VALIDATE_URL)
            && preg_match('#^https?://#', $collaboration) && $environment->get('oidcClientId', '')) {
            return new RedirectResponse($collaboration.'/index.php/apps/oidc/logout?'.http_build_query([
                'client_id' => $environment->get('oidcClientId'),
                'post_logout_redirect_uri' => BASE_URL.'/auth/login',
            ]));
        }
        return new RedirectResponse(BASE_URL.'/auth/login');
    }
}
