<?php

namespace Leantime\Domain\Workshop;

use Closure;
use Illuminate\Session\TokenMismatchException;
use Symfony\Component\HttpFoundation\JsonResponse;

/** Keep native token validation, with an explicit expired-form response for this domain. */
final class VerifyCsrfToken extends \Leantime\Core\Middleware\VerifyCsrfToken
{
    public function handle($request, Closure $next)
    {
        try {
            return parent::handle($request, $next);
        } catch (TokenMismatchException $e) {
            return new JsonResponse(['error' => '表单凭证已失效，请刷新页面后重试；请先保留输入。'], 419,
                ['Cache-Control' => 'no-store']);
        }
    }
}
