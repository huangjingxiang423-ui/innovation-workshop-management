<?php

namespace Leantime\Domain\Workshop;

use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\RateLimiter;
use Leantime\Core\Db\Db;
use Leantime\Core\Mailer;
use Leantime\Domain\Files\Repositories\Files as FileRepository;
use Leantime\Domain\Files\Services\Files as FileService;
use Leantime\Domain\Projects\Repositories\Projects;
use Leantime\Domain\Tickets\Repositories\Tickets;
use Leantime\Domain\Users\Repositories\Users;

/**
 * Additive workshop domain. Native users/projects/tickets/files stay authoritative.
 * Mutations are scoped, version checked, audited and idempotent in one DB transaction.
 */
final class Service
{
    private ConnectionInterface $db;

    public function __construct(Db $db, private Users $users, private Projects $projects,
        private Tickets $tickets, private FileRepository $files, private FileService $fileService)
    {
        $this->db = $db->getConnection();
    }

    public function actor(): array
    {
        $id = (int) session('userdata.id');
        $user = $this->db->table('zp_user')->where('id', $id)->first();
        if (!$user || strtolower((string) $user->status) !== 'a') {
            throw new WorkshopException('请登录有效账号。', 401);
        }
        $owner = (int) $user->role === 50;
        $person = $this->db->table('ws_people')->where('user_id', $id)->first();
        if (!$owner && (!$person || $person->status !== 'approved' || !$person->email_verified_at)) {
            throw new WorkshopException('账号尚未通过工坊审核或已被停用。', 403);
        }
        return ['id' => $id, 'name' => trim($user->firstname.' '.$user->lastname),
            'email' => $user->username, 'owner' => $owner,
            'role' => $owner ? 'manager' : $person->workshop_role,
            'student_no' => $person->student_no ?? ''];
    }

    public function manager(array $actor): bool
    {
        return $actor['owner'] || in_array($actor['role'], ['manager', 'teacher'], true);
    }

    private function requireManager(array $actor): void
    {
        if (!$this->manager($actor)) {
            throw new WorkshopException('只有老师或总负责人可以执行此操作。', 403);
        }
    }

    private function project(array $actor, int $id, bool $write = false, bool $leader = false): object
    {
        $project = $this->db->table('ws_projects as w')->join('zp_projects as p', 'p.id', '=', 'w.project_id')
            ->select('w.*', 'p.name', 'p.details')->where('w.project_id', $id);
        if ($write) { $project->lockForUpdate(); }
        $project = $project->first();
        $membership = $this->db->table('ws_memberships')->where('user_id', $actor['id'])
            ->where('project_id', $id)->where('active', 1)->first();
        if (!$project || (!$this->manager($actor) && (!$membership || ($leader && $membership->role !== 'leader')))) {
            throw new WorkshopException('项目不存在或没有访问权限。', 403);
        }
        if ($write && $project->archived_at) {
            throw new WorkshopException('项目已归档，当前为只读。', 409);
        }
        return $project;
    }

    private function leader(array $actor, int $projectId): bool
    {
        return $this->manager($actor) || $this->db->table('ws_memberships')->where('project_id', $projectId)
            ->where('user_id', $actor['id'])->where('active', 1)->where('role', 'leader')->exists();
    }

    private function task(array $actor, int $id, bool $write = false): object
    {
        // Always lock in mutation transactions; serializes version check + native write + history.
        $query = $this->db->table('ws_tasks as w')->join('zp_tickets as t', 't.id', '=', 'w.task_id')
            ->select('t.*', 'w.revision', 'w.baseline_due', 'w.block_reason', 'w.support_needed', 'w.cancelled')
            ->where('t.id', $id);
        if ($write) {
            $query->lockForUpdate();
        }
        $task = $query->first();
        if (!$task) {
            throw new WorkshopException('任务不存在或没有访问权限。', 404);
        }
        $this->project($actor, (int) $task->projectId, $write);
        return $task;
    }

    private function audit(?int $actor, string $action, string $entity, ?int $id,
        ?int $project = null, mixed $before = null, mixed $after = null): void
    {
        $this->db->table('ws_audit')->insert(['actor_id' => $actor, 'project_id' => $project,
            'action' => $action, 'entity' => $entity, 'entity_id' => $id,
            'before_json' => $before === null ? null : json_encode($before, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
            'after_json' => $after === null ? null : json_encode($after, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR),
            'created_at' => gmdate('Y-m-d H:i:s')]);
    }

    /** Durable idempotency: insert-or-ignore + row lock handles concurrent duplicate requests. */
    private function once(array $actor, string $key, string $operation, array $data, callable $action): array
    {
        if (!preg_match('/^[a-zA-Z0-9_-]{16,80}$/D', $key)) {
            throw new WorkshopException('缺少有效的操作编号，请刷新后重试。');
        }
        $hash = hash('sha256', $operation.json_encode($data, JSON_THROW_ON_ERROR));
        return $this->db->transaction(function () use ($actor, $key, $hash, $action) {
            $this->db->table('ws_requests')->insertOrIgnore(['user_id' => $actor['id'], 'request_key' => $key,
                'request_hash' => $hash, 'created_at' => gmdate('Y-m-d H:i:s')]);
            $record = $this->db->table('ws_requests')->where('user_id', $actor['id'])
                ->where('request_key', $key)->lockForUpdate()->first();
            if (!$record || !hash_equals($record->request_hash, $hash)) {
                throw new WorkshopException('同一操作编号不能用于不同内容。', 409);
            }
            if ($record->response_json !== null) {
                return json_decode($record->response_json, true, flags: JSON_THROW_ON_ERROR);
            }
            $result = $action();
            $this->db->table('ws_requests')->where('id', $record->id)
                ->update(['response_json' => json_encode($result, JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR)]);
            return $result;
        }, 3);
    }

    public function mutate(string $operation, array $data, string $key): array
    {
        $actor = $this->actor();
        $handlers = ['create_project' => 'createProject', 'membership' => 'membership',
            'approve' => 'approve', 'suspend' => 'suspend', 'person_role' => 'personRole',
            'link_meeting_task'=>'linkMeetingTask', 'create_task' => 'createTask', 'edit_task' => 'editTask', 'transition' => 'transition',
            'submit' => 'submit', 'review' => 'review', 'archive' => 'archive',
            'preferences' => 'preferences', 'workspace_settings' => 'workspaceSettings', 'edit_project' => 'editProject', 'import_roster' => 'importRoster'];
        if (!isset($handlers[$operation])) {
            throw new WorkshopException('不支持此操作。', 404);
        }
        return $this->once($actor, $key, $operation, $data, fn () => $this->{$handlers[$operation]}($actor, $data));
    }

    public function roster(): array
    {
        $this->requireManager($this->actor());return (new Roster($this->db))->listing();
    }

    public function previewRoster(string $csv): array
    {
        $actor=$this->actor();$this->requireManager($actor);
        return (new Roster($this->db))->preview($csv);
    }

    public function previewRosterFile(array $file): array
    {
        $this->requireManager($this->actor());
        if(($file['error']??UPLOAD_ERR_NO_FILE)!==UPLOAD_ERR_OK||!is_uploaded_file($file['tmp_name']??''))throw new WorkshopException('名单上传不完整，请重新选择文件。');
        $ext=strtolower(pathinfo($file['name']??'',PATHINFO_EXTENSION));
        if($ext==='xlsx')$csv=(new RosterWorkbook())->csv($file['tmp_name']);
        elseif($ext==='csv'){if(($file['size']??0)>1048576)throw new WorkshopException('CSV请控制在1MB以内。');$csv=file_get_contents($file['tmp_name']);}
        else throw new WorkshopException('请使用 .xlsx 或 UTF-8 CSV，旧版 .xls 请另存为 .xlsx。');
        return (new Roster($this->db))->preview($csv)+['normalized_csv'=>$csv];
    }

    private function importRoster(array $actor, array $data): array
    {
        $this->requireManager($actor);
        if(isset($data['sync_existing'])&&!is_bool($data['sync_existing']))throw new WorkshopException('请选择是否同步已入组成员。');
        if(!is_string($data['csv']??null)||!is_string($data['digest']??null))throw new WorkshopException('请先选择名单并预检。');
        // Serialize all imports with an existing migration row, including a currently empty roster.
        $this->db->table('ws_migrations')->where('version','004_roster')->lockForUpdate()->first();
        $roster=new Roster($this->db);$preview=$roster->preview($data['csv'],true);
        if(!$preview['valid'])throw new WorkshopException('名单仍有错误，请更正后重新预检。');
        if(!hash_equals($preview['digest'],$data['digest']))throw new WorkshopException('名单或现有数据已经变化，请重新预检。',409);
        $result=$roster->save($preview,fn($before,$after)=>$this->audit($actor['id'],'roster.relationship','roster',null,(int)$after['project_id'],$before,$after));
        $synced=0;
        if(($data['sync_existing']??false)===true){
            foreach($preview['rows'] as $row){
                if(!$row['sync_eligible'])continue;
                $old=$this->db->table('ws_memberships')->where('user_id',$row['registered_user_id'])->where('project_id',$row['project_id'])->first();
                if($old&&(bool)$old->active&&$old->role===$row['role'])continue;
                $this->membership($actor,['user_id'=>$row['registered_user_id'],'project_id'=>$row['project_id'],'role'=>$row['role'],'active'=>true]);$synced++;
            }
            $result['message']='名单已导入，已按本次明确确认同步 '.$synced.' 条已审核成员的项目角色。未列出的其他项目权限保持原状；消息与资料权限开通仍需完成。';
        }
        $result['synced_memberships']=$synced;
        $this->audit($actor['id'],'roster.imported','roster',null,null,null,['counts'=>$result['counts'],'people'=>$result['people']]);
        return $result;
    }

    public function register(array $data, string $ip): array
    {
        $this->publicRateLimit($ip, (string) ($data['email'] ?? ''));
        $name = Policy::text($data['name'] ?? '', 60, true);
        $number = strtoupper(Policy::text($data['student_no'] ?? '', 64, true));
        $email = mb_strtolower(Policy::text($data['email'] ?? '', 190, true));
        $password = $data['password'] ?? '';
        if (!preg_match('/^[a-zA-Z0-9_-]{3,64}$/D', $number) || !filter_var($email, FILTER_VALIDATE_EMAIL)
            || !is_string($password) || strlen($password) < 12 || strlen($password) > 128
            || !preg_match('/[a-zA-Z]/', $password) || !preg_match('/[0-9]/', $password)) {
            throw new WorkshopException('请填写有效学号、邮箱；密码至少12位，包含字母和数字。');
        }
        $id = $this->db->transaction(function () use ($name, $number, $email, $password) {
            if($this->db->table('ws_roster')->exists()&&!$this->db->table('ws_roster')->where('student_no',$number)->where('name',$name)->exists()){
                throw new WorkshopException('登记信息未能匹配工坊名单，请联系管理员现场核验。',422);
            }
            if ($this->db->table('ws_people')->where('student_no', $number)->exists()
                || $this->db->table('zp_user')->where('username', $email)->exists()) {
                throw new WorkshopException('学号或邮箱已登记，请登录、重发验证邮件或联系管理员。', 409);
            }
            // Reuse the core password hashing and account store; inactive until BOTH checks pass.
            $id = (int) $this->users->addUser(['firstname' => $name, 'lastname' => '', 'user' => $email,
                'password' => $password, 'role' => '20', 'status' => 'i', 'source' => 'workshop']);
            $now = gmdate('Y-m-d H:i:s');
            $this->db->table('ws_people')->insert(['user_id' => $id, 'student_no' => $number,
                'status' => 'pending', 'workshop_role' => 'member', 'created_at' => $now, 'updated_at' => $now]);
            $this->audit($id, 'registration.created', 'person', $id);
            return $id;
        });
        $sent = $this->verificationMail($id);
        $testMail = (bool) config('workshop.test_mail', false);
        return ['message' => $sent && $testMail ? '注册资料已保存。当前为本机演示模式，验证邮件仅保存在本机，未发送到你的邮箱。' : ($sent ? '注册资料已保存，请验证邮箱并等待现场身份审核。'
            : '注册资料已保存，但验证邮件未发出。请稍后重发，或联系管理员检查邮件服务。'), 'email_sent' => $sent && !$testMail];
    }

    private function publicRateLimit(string $ip, string $email): void
    {
        foreach (['ip:'.$ip, 'email:'.strtolower($email)] as $source) {
            $key = 'workshop-register:'.hash('sha256', $source);
            if (RateLimiter::tooManyAttempts($key, 5)) {
                throw new WorkshopException('操作过于频繁，请10分钟后再试。', 429);
            }
            RateLimiter::hit($key, 600);
        }
    }

    public function resend(string $email, string $ip): array
    {
        $this->publicRateLimit($ip, $email);
        $person = $this->db->table('ws_people as w')->join('zp_user as u', 'u.id', '=', 'w.user_id')
            ->where('u.username', strtolower(trim($email)))->where('w.status', 'pending')->first();
        if ($person && !$person->email_verified_at) {
            $this->verificationMail((int) $person->user_id);
        }
        return ['message' => '如果有尚待验证的注册，系统会尝试发送验证邮件。'];
    }

    private function verificationMail(int $id): bool
    {
        $user = $this->users->getUser($id, false);
        $token = bin2hex(random_bytes(32));
        $base = rtrim((string) config('app.url'), '/');
        if (!filter_var($base, FILTER_VALIDATE_URL)) {
            return false;
        }
        $this->db->transaction(function () use ($id, $token) {
            $this->db->table('ws_email_tokens')->where('user_id', $id)->whereNull('used_at')
                ->update(['used_at' => gmdate('Y-m-d H:i:s')]);
            $this->db->table('ws_email_tokens')->insert(['user_id' => $id,
                'token_hash' => hash('sha256', $token), 'expires_at' => gmdate('Y-m-d H:i:s', time() + 1800),
                'created_at' => gmdate('Y-m-d H:i:s')]);
        });
        $link = $base.'/workshop/verify?token='.$token;
        if (config('workshop.test_mail', false)) {
            if (!in_array(parse_url($base, PHP_URL_HOST), ['127.0.0.1', 'localhost'], true)) {
                throw new WorkshopException('测试邮件模式只能用于本机环境。', 503);
            }
            $dir = APP_ROOT.'/storage/workshop-test-mail';
            if (!is_dir($dir)) {
                mkdir($dir, 0700, true);
            }
            $path = $dir.'/'.$id.'.json';
            if (file_put_contents($path, json_encode(['to' => $user['username'], 'url' => $link], JSON_THROW_ON_ERROR), LOCK_EX) === false) {
                return false;
            }
            chmod($path, 0600);
            return true;
        }
        $mailer = app()->make(Mailer::class);
        $mailer->setSubject('验证工坊账号邮箱');
        $mailer->setHtml('<p>请在30分钟内验证邮箱。验证后仍需管理员核实身份、批准入组。</p><p><a href="'.htmlspecialchars($link, ENT_QUOTES).'">验证我的邮箱</a></p>', true);
        return $mailer->sendMail([$user['username']], '工坊管理');
    }

    public function verify(string $token): void
    {
        if (!preg_match('/^[a-f0-9]{64}$/D', $token)) {
            throw new WorkshopException('验证链接无效或已过期。', 400);
        }
        $this->db->transaction(function () use ($token) {
            $row = $this->db->table('ws_email_tokens')->where('token_hash', hash('sha256', $token))->lockForUpdate()->first();
            if (!$row || $row->used_at || $row->expires_at < gmdate('Y-m-d H:i:s')) {
                throw new WorkshopException('验证链接无效或已过期，请重发邮件。', 400);
            }
            $now = gmdate('Y-m-d H:i:s');
            $this->db->table('ws_email_tokens')->where('token_hash', $row->token_hash)->update(['used_at' => $now]);
            $this->db->table('ws_people')->where('user_id', $row->user_id)
                ->update(['email_verified_at' => $now, 'updated_at' => $now]);
            $this->audit((int) $row->user_id, 'email.verified', 'person', (int) $row->user_id);
        });
    }

    private function approve(array $actor, array $data): array
    {
        $this->requireManager($actor);
        $id = (int) ($data['user_id'] ?? 0);
        $person = $this->db->table('ws_people')->where('user_id', $id)->lockForUpdate()->first();
        if (!$person || $person->status !== 'pending' || !$person->email_verified_at) {
            throw new WorkshopException('仅可批准已验证邮箱、尚待现场身份审核的账号。', 409);
        }
        $this->db->table('ws_migrations')->where('version','004_roster')->lockForUpdate()->first();
        $user=$this->db->table('zp_user')->where('id',$id)->first();
        $roster=$this->db->table('ws_roster')->where('student_no',$person->student_no)->get();
        if($this->db->table('ws_roster')->exists()&&($roster->isEmpty()||$roster->contains(fn($r)=>$r->name!==trim($user->firstname.' '.$user->lastname)))){
            throw new WorkshopException('账号与当前工坊名单不匹配，请先核实名单与身份。',409);
        }
        foreach($roster as $entry)$this->project($actor,(int)$entry->project_id,true);
        $this->db->table('ws_people')->where('user_id', $id)->update(['status' => 'approved', 'updated_at' => gmdate('Y-m-d H:i:s')]);
        $this->db->table('zp_user')->where('id', $id)->update(['status' => 'a']);
        $this->audit($actor['id'], 'person.approved', 'person', $id, null, 'pending', 'approved');
        foreach($roster as $entry)$this->membership($actor,['user_id'=>$id,'project_id'=>(int)$entry->project_id,'role'=>$entry->role,'active'=>true]);
        return ['message' => $roster->isNotEmpty()?'已批准入组，并按名单分配项目。':'已批准入组，请继续分配项目。'];
    }

    private function suspend(array $actor, array $data): array
    {
        $this->requireManager($actor);
        $id = (int) ($data['user_id'] ?? 0);
        $person = $this->db->table('ws_people')->where('user_id', $id)->lockForUpdate()->first();
        if (!$person || $id === $actor['id'] || (!$actor['owner'] && $person->workshop_role !== 'member')) {
            throw new WorkshopException('不能停用自己或超出管理范围的账号。', 403);
        }
        $this->db->table('ws_people')->where('user_id', $id)->update(['status' => 'suspended', 'updated_at' => gmdate('Y-m-d H:i:s')]);
        $this->db->table('zp_user')->where('id', $id)->update(['status' => 'i']);
        (new ProjectGroupSync($this->db))->queue($id);
        $this->audit($actor['id'], 'person.suspended', 'person', $id, null, $person->status, 'suspended');
        return ['message' => '账号已停用，历史工作记录保留。'];
    }

    private function personRole(array $actor, array $data): array
    {
        if (!$actor['owner']) {
            throw new WorkshopException('只有系统维护管理员可任命老师或总负责人。', 403);
        }
        $id = (int) ($data['user_id'] ?? 0);
        $role = $data['role'] ?? '';
        $person = $this->db->table('ws_people')->where('user_id', $id)->lockForUpdate()->first();
        if (!$person || $person->status !== 'approved' || !in_array($role, ['member', 'teacher', 'manager'], true)) {
            throw new WorkshopException('请选择已入组人员及有效角色。');
        }
        $this->db->table('ws_people')->where('user_id', $id)->update(['workshop_role' => $role, 'updated_at' => gmdate('Y-m-d H:i:s')]);
        foreach ($this->db->table('ws_projects')->pluck('project_id') as $projectId) {
            $membership = $this->db->table('ws_memberships')->where('user_id', $id)->where('project_id', $projectId)->first();
            $this->syncNativeMembership($id, (int) $projectId, $membership->role ?? 'member', (bool) ($membership->active ?? false));
        }
        // Workshop managers still use a non-admin native account; every API re-reads workshop role.
        $this->audit($actor['id'], 'person.role', 'person', $id, null, $person->workshop_role, $role);
        return ['message' => '工坊管理角色已更新。'];
    }

    private function syncNativeMembership(int $userId, int $projectId, string $role, bool $active): void
    {
        (new ProjectGroupSync($this->db))->queue($userId);
        $global = $this->db->table('ws_people')->where('user_id', $userId)->where('status', 'approved')->whereIn('workshop_role', ['manager', 'teacher'])->exists();
        if ($global) { $active = true; $role = 'leader'; }
        $this->db->table('zp_relationuserproject')->where('userId', $userId)->where('projectId', $projectId)->delete();
        if ($active) {
            $this->projects->addProjectRelation($userId, $projectId, $role === 'leader' ? '30' : '20');
        }
    }

    private function membership(array $actor, array $data): array
    {
        $this->requireManager($actor);
        $projectId = (int) ($data['project_id'] ?? 0);
        $this->project($actor, $projectId, true);
        $id = (int) ($data['user_id'] ?? 0);
        $role = $data['role'] ?? '';
        $active = ($data['active'] ?? true) === true;
        $person = $this->db->table('ws_people')->where('user_id', $id)->where('status', 'approved')->first();
        if (!$person || !in_array($role, ['member', 'leader'], true)) {
            throw new WorkshopException('请选择已入组的成员和有效项目角色。');
        }
        $before = $this->db->table('ws_memberships')->where('user_id', $id)->where('project_id', $projectId)->first();
        $now = gmdate('Y-m-d H:i:s');
        $this->db->table('ws_memberships')->updateOrInsert(['user_id' => $id, 'project_id' => $projectId],
            ['role' => $role, 'active' => $active, 'created_at' => $before->created_at ?? $now, 'updated_at' => $now]);
        $this->syncNativeMembership($id, $projectId, $role, $active);
        $this->audit($actor['id'], 'membership.changed', 'person', $id, $projectId, $before, ['role' => $role, 'active' => $active]);
        return ['message' => '项目成员关系已更新，其他项目权限保持独立。'];
    }

    private function createProject(array $actor, array $data): array
    {
        $this->requireManager($actor);
        $name = Policy::text($data['name'] ?? '', 120, true);
        $details = Policy::text($data['details'] ?? '', 10000);
        $goal = Policy::text($data['goal'] ?? '', 4000);
        $id = (int) $this->projects->addProject(['name' => $name, 'details' => $details,
            'clientId' => 0, 'hourBudget' => 0, 'dollarBudget' => 0, 'psettings' => 'restricted', 'assignedUsers' => []]);
        $now = gmdate('Y-m-d H:i:s');
        $this->db->table('ws_projects')->insert(['project_id' => $id, 'stage' => '启动', 'goal' => $goal,
            'revision' => 1, 'created_at' => $now, 'updated_at' => $now]);
        foreach ($this->db->table('ws_people')->where('status', 'approved')->whereIn('workshop_role', ['manager', 'teacher'])->pluck('user_id') as $managerId) {
            $this->syncNativeMembership((int) $managerId, $id, 'leader', true);
        }
        $this->audit($actor['id'], 'project.created', 'project', $id, $id);
        return ['message' => '项目已建立，请分配组长和成员。', 'project_id' => $id];
    }

    private function preferences(array $actor, array $data): array
    {
        $theme = $data['theme'] ?? 'dark'; $density = $data['density'] ?? 'comfortable';
        if (!in_array($theme, ['dark','light','system'], true) || !in_array($density, ['comfortable','compact'], true)) {
            throw new WorkshopException('请选择有效的界面偏好。');
        }
        $value = ['theme'=>$theme, 'density'=>$density, 'reduce_motion'=>($data['reduce_motion'] ?? false) === true];
        $now = gmdate('Y-m-d H:i:s');
        $before = $this->db->table('ws_preferences')->where('user_id',$actor['id'])->first();
        $this->db->table('ws_preferences')->updateOrInsert(['user_id'=>$actor['id']],
            ['preferences_json'=>json_encode($value),'created_at'=>$before->created_at ?? $now,'updated_at'=>$now]);
        return ['message'=>'个人界面偏好已保存。'];
    }

    private function workspaceSettings(array $actor, array $data): array
    {
        $this->requireManager($actor);
        $row = $this->db->table('ws_settings')->where('key','identity')->lockForUpdate()->first();
        if (!$row || (int)($data['revision'] ?? 0) !== (int)$row->revision) {
            throw new WorkshopException('设置已被其他人更新，请刷新后再保存。',409);
        }
        $value = ['name'=>Policy::text($data['name'] ?? '',40,true)];
        $this->db->table('ws_settings')->where('key','identity')->update(['value'=>json_encode($value),
            'revision'=>$row->revision+1,'updated_at'=>gmdate('Y-m-d H:i:s')]);
        $this->audit($actor['id'],'workspace.settings','workspace',null,null,json_decode($row->value,true),$value);
        return ['message'=>'工坊名称已更新。'];
    }

    private function editProject(array $actor, array $data): array
    {
        $id = (int)($data['project_id'] ?? 0);
        $project = $this->project($actor,$id,true,true);
        if ((int)($data['revision'] ?? 0) !== (int)$project->revision) {
            throw new WorkshopException('项目已更新，请刷新后再保存。',409);
        }
        $stage = Policy::text($data['stage'] ?? '',120,true);
        $goal = Policy::text($data['goal'] ?? '',4000);
        $this->db->table('ws_projects')->where('project_id',$id)->update(['stage'=>$stage,'goal'=>$goal,
            'revision'=>$project->revision+1,'updated_at'=>gmdate('Y-m-d H:i:s')]);
        $this->audit($actor['id'],'project.updated','project',$id,$id,['stage'=>$project->stage,'goal'=>$project->goal],['stage'=>$stage,'goal'=>$goal]);
        return ['message'=>'项目阶段与目标已更新。'];
    }

    private function due(mixed $value): ?string
    {
        if ($value === '' || $value === null) {
            return null;
        }
        if (!is_string($value) || !preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/D', $value)) {
            throw new WorkshopException('截止时间格式不正确。');
        }
        $date = \DateTimeImmutable::createFromFormat('!Y-m-d\TH:i', $value, new \DateTimeZone('Asia/Shanghai'));
        if (!$date || $date->format('Y-m-d\TH:i') !== $value) {
            throw new WorkshopException('截止时间无效。');
        }
        return $date->setTimezone(new \DateTimeZone('UTC'))->format('Y-m-d H:i:s');
    }

    private function assignee(int $projectId, int $userId): void
    {
        if (!$this->db->table('ws_memberships as m')->join('ws_people as p', 'p.user_id', '=', 'm.user_id')
            ->where('m.project_id', $projectId)->where('m.user_id', $userId)->where('m.active', 1)
            ->where('p.status', 'approved')->exists()) {
            throw new WorkshopException('责任人必须是此项目中有效的工坊成员。');
        }
    }

    private function createTask(array $actor, array $data): array
    {
        $projectId = (int) ($data['project_id'] ?? 0);
        $this->project($actor, $projectId, true, true);
        $meeting=null;
        if(isset($data['meeting_source'])&&$data['meeting_source']!==''){
            $meeting=MeetingReference::path($data['meeting_source']);
            if(($data['confirm_meeting_project']??'')!=='1')throw new WorkshopException('请人工确认会议待办属于当前项目，且允许在该项目中分配。');
        }
        $assigned = (int) ($data['assignee_id'] ?? 0);
        $this->assignee($projectId, $assigned);
        $due = $this->due($data['due'] ?? '');
        $priority = (int) ($data['priority'] ?? 3);
        if ($priority < 1 || $priority > 5) {
            throw new WorkshopException('优先级必须在1至5之间。');
        }
        $id = $this->tickets->addTicket(['headline' => Policy::text($data['title'] ?? '', 200, true),
            'description' => Policy::text($data['description'] ?? '', 20000), 'type' => 'task',
            'date' => gmdate('Y-m-d H:i:s'), 'dateToFinish' => $due, 'projectId' => $projectId,
            'status' => 3, 'userId' => $actor['id'], 'editorId' => $assigned, 'tags' => '', 'sprint' => null,
            'storypoints' => null, 'priority' => (string) $priority, 'hourRemaining' => null, 'planHours' => 0,
            'acceptanceCriteria' => Policy::text($data['criteria'] ?? '', 4000, true),
            'editFrom' => null, 'editTo' => null]);
        if (!$id) {
            throw new WorkshopException('任务未能保存，请重试。', 503);
        }
        $now = gmdate('Y-m-d H:i:s');
        $this->db->table('ws_tasks')->insert(['task_id' => $id, 'revision' => 1, 'baseline_due' => $due,
            'created_at' => $now, 'updated_at' => $now]);
        if($meeting!==null)$this->db->table('ws_task_origins')->insert(['task_id'=>$id,'source_type'=>'meeting','source_path'=>$meeting,'created_by'=>$actor['id'],'created_at'=>$now]);
        $this->audit($actor['id'], 'task.created', 'task', $id, $projectId);
        return ['message' => '任务已分配。', 'task_id' => $id];
    }

    private function linkMeetingTask(array $actor,array $data):array
    {
        $task=$this->task($actor,(int)($data['task_id']??0),true);
        $this->project($actor,(int)$task->projectId,true,true);
        $source=MeetingReference::path($data['meeting_source']??null);
        if(($data['confirm_meeting_project']??'')!=='1')throw new WorkshopException('请人工确认该会议待办与所选任务属于同一项目。');
        $existing=$this->db->table('ws_task_origins')->where('task_id',$task->id)->first();
        if($existing){
            if($existing->source_type==='meeting'&&hash_equals($existing->source_path,$source))return ['message'=>'这条任务已关联当前组会，没有重复创建任务或修改任务状态。','task_id'=>$task->id];
            throw new WorkshopException('任务已有其他来源，不能覆盖。请从任务详情核对原来源。',409);
        }
        Policy::revision($data['revision']??null,$task->revision);
        $this->db->table('ws_task_origins')->insert(['task_id'=>$task->id,'source_type'=>'meeting','source_path'=>$source,'created_by'=>$actor['id'],'created_at'=>gmdate('Y-m-d H:i:s')]);
        $this->bump($task);
        $this->audit($actor['id'],'task.meeting_linked','task',(int)$task->id,(int)$task->projectId,null,['source_type'=>'meeting']);
        return ['message'=>'已有任务已关联组会，责任人、截止时间和任务状态保持不变。','task_id'=>$task->id];
    }

    private function bump(object $task, array $extra = []): void
    {
        $this->db->table('ws_tasks')->where('task_id', $task->id)
            ->update(array_merge($extra, ['revision' => $task->revision + 1, 'updated_at' => gmdate('Y-m-d H:i:s')]));
    }

    private function editTask(array $actor, array $data): array
    {
        $task = $this->task($actor, (int) ($data['task_id'] ?? 0), true);
        $this->project($actor, (int) $task->projectId, true, true);
        Policy::revision($data['revision'] ?? null, $task->revision);
        $assigned = (int) ($data['assignee_id'] ?? 0);
        $this->assignee((int) $task->projectId, $assigned);
        $due = $this->due($data['due'] ?? '');
        $reason = Policy::text($data['reason'] ?? '', 1000, true);
        $this->tickets->patchTicket($task->id, ['editorId' => $assigned, 'dateToFinish' => $due]);
        $this->bump($task);
        $this->audit($actor['id'], 'task.assignment_or_due', 'task', $task->id, $task->projectId,
            ['assignee_id' => $task->editorId, 'due' => $task->dateToFinish],
            ['assignee_id' => $assigned, 'due' => $due, 'reason' => $reason]);
        return ['message' => '已更新责任人和期限，原始期限及修改理由已保留。'];
    }

    private function transition(array $actor, array $data): array
    {
        $task = $this->task($actor, (int) ($data['task_id'] ?? 0), true);
        Policy::revision($data['revision'] ?? null, $task->revision);
        $leader = $this->leader($actor, (int) $task->projectId);
        $to = (string) ($data['state'] ?? '');
        $from = $task->cancelled ? 'cancelled' : array_search((int) $task->status, Policy::STATES, true);
        if ($to === 'cancelled' || $from === 'cancelled') {
            if (!$leader || ($from === 'cancelled' && $to !== 'new')) {
                throw new WorkshopException('只有组长或管理者可以取消或重新打开任务。', 403);
            }
            $reason = Policy::text($data['reason'] ?? '', 1000, true);
            $this->tickets->patchTicket($task->id, ['status' => $to === 'cancelled' ? -1 : 3]);
            $this->bump($task, ['cancelled' => $to === 'cancelled']);
        } else {
            Policy::transition((string) $from, $to, $leader, (int) $task->editorId === $actor['id']);
            $reason = Policy::text($data['reason'] ?? '', 1000, $to === 'blocked' || $from === 'done');
            $this->tickets->patchTicket($task->id, ['status' => Policy::STATES[$to]]);
            $this->bump($task, ['block_reason' => $to === 'blocked' ? $reason : null,
                'support_needed' => Policy::text($data['support_needed'] ?? '', 1000)]);
        }
        $this->audit($actor['id'], 'task.transition', 'task', $task->id, $task->projectId,
            ['state' => $from], ['state' => $to, 'reason' => $reason]);
        return ['message' => '任务进度已保存。'];
    }

    private function submit(array $actor, array $data): array
    {
        $task = $this->task($actor, (int) ($data['task_id'] ?? 0), true);
        Policy::revision($data['revision'] ?? null, $task->revision);
        if ((int) $task->editorId !== $actor['id'] && !$this->leader($actor, (int) $task->projectId)) {
            throw new WorkshopException('只有责任人或组长可以提交此任务的成果。', 403);
        }
        if ($task->cancelled || in_array((int) $task->status, [0, 2], true)) {
            throw new WorkshopException('已完成、已取消或正在验收的任务不能重复提交。', 409);
        }
        $content = Policy::text($data['content'] ?? '', 20000, true);
        $links = Policy::links(Policy::text($data['links'] ?? '', 22000));
        $fileIds = $data['file_ids'] ?? [];
        if (!is_array($fileIds) || count($fileIds) > 10) {
            throw new WorkshopException('最多关联10个成果附件。');
        }
        foreach ($fileIds as $fileId) {
            $file = $this->files->getFile((int) $fileId);
            if (!$file || $file['module'] !== 'ticket' || (int) $file['moduleId'] !== (int) $task->id
                || (int) $file['userId'] !== $actor['id']) {
                throw new WorkshopException('附件不存在或不属于你在此任务下的上传。', 403);
            }
        }
        $id = $this->db->table('ws_submissions')->insertGetId(['task_id' => $task->id, 'user_id' => $actor['id'],
            'content' => $content, 'links_json' => json_encode($links, JSON_THROW_ON_ERROR),
            'files_json' => json_encode(array_values(array_unique(array_map('intval', $fileIds))), JSON_THROW_ON_ERROR),
            'created_at' => gmdate('Y-m-d H:i:s')]);
        $this->tickets->patchTicket($task->id, ['status' => 2]);
        $this->bump($task);
        $this->audit($actor['id'], 'submission.created', 'submission', $id, $task->projectId, null, ['task_id' => $task->id]);
        return ['message' => '成果已提交，等待验收。', 'submission_id' => $id];
    }

    private function review(array $actor, array $data): array
    {
        $task = $this->task($actor, (int) ($data['task_id'] ?? 0), true);
        $this->project($actor, (int) $task->projectId, true, true);
        Policy::revision($data['revision'] ?? null, $task->revision);
        $submission = $this->db->table('ws_submissions')->where('task_id', $task->id)->orderByDesc('id')->first();
        $decision = $data['decision'] ?? '';
        if (!$submission || (int) $task->status !== 2 || $task->cancelled
            || !in_array($decision, ['accepted', 'returned'], true)
            || (int) ($data['submission_id'] ?? 0) !== (int) $submission->id) {
            throw new WorkshopException('成果版本或待验收状态已变化，请刷新。', 409);
        }
        if ((int) $submission->user_id === $actor['id'] && !$this->manager($actor)) {
            throw new WorkshopException('组长不能验收自己提交的成果，请老师或总负责人验收。', 403);
        }
        $comment = Policy::text($data['comment'] ?? '', 4000, true);
        $this->db->table('ws_reviews')->insert(['submission_id' => $submission->id, 'user_id' => $actor['id'],
            'decision' => $decision, 'comment' => $comment, 'created_at' => gmdate('Y-m-d H:i:s')]);
        $this->tickets->patchTicket($task->id, ['status' => $decision === 'accepted' ? 0 : 4]);
        $this->bump($task);
        $this->audit($actor['id'], 'submission.'.$decision, 'submission', $submission->id, $task->projectId,
            null, ['task_id' => $task->id, 'comment' => $comment]);
        return ['message' => $decision === 'accepted' ? '成果已验收通过。' : '已退回，意见已保留。'];
    }

    private function archive(array $actor, array $data): array
    {
        $this->requireManager($actor);
        $id = (int) ($data['project_id'] ?? 0);
        $project = $this->project($actor, $id);
        $project = $this->db->table('ws_projects')->where('project_id', $id)->lockForUpdate()->first();
        Policy::revision($data['revision'] ?? null, $project->revision);
        $archived = ($data['archived'] ?? true) === true;
        $this->db->table('ws_projects')->where('project_id', $id)->update(['archived_at' => $archived ? gmdate('Y-m-d H:i:s') : null,
            'revision' => $project->revision + 1, 'updated_at' => gmdate('Y-m-d H:i:s')]);
        $this->db->table('zp_projects')->where('id', $id)->update(['state' => $archived ? 1 : 0]);
        $this->audit($actor['id'], $archived ? 'project.archived' : 'project.reopened', 'project', $id, $id);
        return ['message' => $archived ? '项目已归档，历史仍可查询。' : '项目已重新开放。'];
    }

    public function upload(array $file, int $taskId, string $key): array
    {
        $actor = $this->actor();
        $task = $this->task($actor, $taskId);
        $this->project($actor, (int) $task->projectId, true);
        if ((int) $task->editorId !== $actor['id'] && !$this->leader($actor, (int) $task->projectId)) {
            throw new WorkshopException('没有上传此任务成果的权限。', 403);
        }
        $extension = strtolower(pathinfo($file['name'] ?? '', PATHINFO_EXTENSION));
        $allowed = ['pdf' => ['application/pdf'], 'png' => ['image/png'], 'jpg' => ['image/jpeg'],
            'jpeg' => ['image/jpeg'], 'txt' => ['text/plain'], 'csv' => ['text/plain', 'text/csv'],
            'zip' => ['application/zip', 'application/x-zip-compressed']];
        $tmp = $file['tmp_name'] ?? '';
        if (!isset($allowed[$extension]) || ($file['error'] ?? 1) !== UPLOAD_ERR_OK || !is_uploaded_file($tmp)
            || ($file['size'] ?? 0) > 10 * 1024 * 1024 || ($file['size'] ?? 0) < 1) {
            throw new WorkshopException('附件仅支持 PDF、图片、TXT、CSV、ZIP，单个不超过10MB。');
        }
        $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($tmp);
        if (!in_array($mime, $allowed[$extension], true)) {
            throw new WorkshopException('文件实际类型与扩展名不符。');
        }
        return $this->once($actor, $key, 'upload', ['task_id' => $taskId, 'name' => $file['name'], 'sha256' => hash_file('sha256', $tmp)],
            function () use ($actor, $file, $taskId) {
                $this->task($actor, $taskId, true);
                $result = $this->fileService->upload(['file' => $file], 'ticket', $taskId);
                if (!is_array($result) || empty($result['fileId'])) {
                    throw new WorkshopException('附件未确认保存，请重试。', 503);
                }
                $this->audit($actor['id'], 'file.uploaded', 'file', (int) $result['fileId'],
                    (int) $this->task($actor, $taskId)->projectId);
                return ['message' => '附件已上传，提交成果后会关联到本次版本。',
                    'file_id' => (int) $result['fileId'], 'name' => $result['realName']];
            });
    }

    public function download(int $id): \Symfony\Component\HttpFoundation\Response
    {
        $actor = $this->actor();
        $file = $this->files->getFile($id);
        if (!$file || $file['module'] !== 'ticket') {
            throw new WorkshopException('附件不存在或无权访问。', 404);
        }
        $this->task($actor, (int) $file['moduleId']);
        return $this->fileService->getFileForUser($file['encName'], $actor['id']);
    }

    public function state(int $projectId = 0, int $page = 1, bool $reviewsOnly = false, string $filter = 'all', bool $mine = false, string $search = '', mixed $meetingSource = ''): array
    {
        $actor = $this->actor();
        $query = $this->db->table('ws_projects as w')->join('zp_projects as p', 'p.id', '=', 'w.project_id')
            ->select('w.*', 'p.name', 'p.details')->orderBy('p.id');
        if (!$this->manager($actor)) {
            $query->whereIn('w.project_id', $this->db->table('ws_memberships')->select('project_id')
                ->where('user_id', $actor['id'])->where('active', 1));
        }
        $projects = $query->get();
        $ids = $projects->pluck('project_id')->map(fn ($id) => (int) $id)->all();
        if ($projectId && !in_array($projectId, $ids, true)) {
            throw new WorkshopException('没有此项目的访问权限。', 403);
        }
        $taskQuery = $this->db->table('ws_tasks as w')->join('zp_tickets as t', 't.id', '=', 'w.task_id')
            ->leftJoin('ws_task_origins as source','source.task_id','=','t.id')
            ->leftJoin('zp_user as u', 'u.id', '=', 't.editorId')->join('zp_projects as p', 'p.id', '=', 't.projectId')
            ->whereIn('t.projectId', $projectId ? [$projectId] : $ids);
        if ($mine) { $taskQuery->where('t.editorId', $actor['id']); }
        if($filter==='meeting'){
            $source=MeetingReference::path($meetingSource);
            $taskQuery->whereExists(function($q)use($source){$q->selectRaw('1')->from('ws_task_origins as origin')->whereColumn('origin.task_id','t.id')->where('origin.source_type','meeting')->where('origin.source_path',$source);});
        }

        $all = clone $taskQuery;
        $counts = ['total' => $all->count(), 'review' => (clone $all)->where('t.status', 2)->where('w.cancelled', 0)->count(),
            'done' => (clone $all)->where('t.status', 0)->where('w.cancelled', 0)->count(),
            'overdue' => (clone $all)->whereNotIn('t.status', [0, -1])->where('w.cancelled', 0)
                ->where('t.dateToFinish', '<', gmdate('Y-m-d H:i:s'))->count()];
        if ($reviewsOnly) { $taskQuery->where('t.status', 2)->where('w.cancelled', 0); }
        if ($filter === 'review') { $taskQuery->where('t.status', 2)->where('w.cancelled', 0); }
        if ($filter === 'done') { $taskQuery->where('t.status', 0)->where('w.cancelled', 0); }
        if ($filter === 'overdue') {
            $taskQuery->whereNotIn('t.status', [0, -1])->where('w.cancelled', 0)
                ->where('t.dateToFinish', '<', gmdate('Y-m-d H:i:s'));
        }
        if ($search !== '') {
            $search = Policy::text($search,100);
            $taskQuery->where('t.headline','like','%'.addcslashes($search, '%_\\').'%');
        }
        $visibleCount = (clone $taskQuery)->count();
        $tasks = $taskQuery->select('t.id', 't.headline', 't.projectId', 't.editorId', 't.status', 't.priority', 't.dateToFinish',
            'w.revision', 'w.cancelled', 'w.block_reason', 'w.support_needed', 'u.firstname as assignee_name', 'p.name as project_name','source.source_path as meeting_source')
            ->orderByDesc('t.id')->offset((max(1, $page) - 1) * 50)->limit(50)->get();
        $members = $this->db->table('ws_memberships as m')->join('zp_user as u', 'u.id', '=', 'm.user_id')
            ->join('ws_people as w', 'w.user_id', '=', 'm.user_id')->whereIn('m.project_id', $ids)
            ->select('m.project_id', 'm.user_id', 'm.role', 'm.active', 'u.firstname as name', 'w.status')->get();
        $people = [];
        if ($this->manager($actor)) {
            $people = $this->db->table('ws_people as w')->join('zp_user as u', 'u.id', '=', 'w.user_id')
                ->leftJoin('ws_identity_bindings as b','b.user_id','=','w.user_id')
                ->leftJoin('ws_native_access_sync as ns','ns.user_id','=','w.user_id')
                ->leftJoin('ws_account_enrollments as ae','ae.user_id','=','w.user_id')
                ->select('w.*', 'u.firstname as name', 'u.username as email','b.user_id as collaboration_bound','ns.status as collaboration_group_status','ae.status as enrollment_status','ae.mail_status as invitation_status')->orderByDesc('w.created_at')->limit(500)->get();
        }
        return ['actor' => $actor, 'manager' => $this->manager($actor), 'projects' => $projects, 'tasks' => $tasks,
            'memberships' => $members, 'people' => $people, 'counts' => $counts,
            'workspace' => $this->workspaceMetadata($actor),
            'overview' => $this->overview($ids), 'knowledge_projects' => Knowledge::available($ids),
            'page' => max(1, $page), 'has_more' => max(1, $page) * 50 < $visibleCount];
    }

    public function openCollaborationAccount(int $user,string $cookie,bool $resend=false):array
    {
        $actor=$this->actor();$guard=function(){if(!$this->actor()['owner'])throw new WorkshopException('账号维护权限已变化。',403);};$enrollment=new AccountEnrollment($this->db);return $resend?$enrollment->resend($actor,$user,$cookie,$guard):$enrollment->open($actor,$user,$cookie,$guard);
    }

    public function syncCollaborationGroups(int $user,string $cookie):array
    {
        $actor=$this->actor();return (new ProjectGroupSync($this->db))->synchronize($actor,$user,$cookie,function(){if(!$this->actor()['owner'])throw new WorkshopException('账号维护权限已变化。',403);});
    }

    public function projectSpace(int $project,string $cookie='',bool $prepare=false):array
    {
        $actor=$this->actor();$p=$this->project($actor,$project);$spaces=new ProjectSpaces($this->db);
        if(!$prepare)return $spaces->status($project,$actor['owner']&&!$p->archived_at)+['can_audit'=>(bool)$actor['owner']];
        $guard=function()use($project){$a=$this->actor();if(!$a['owner'])throw new WorkshopException('账号维护权限已变化。',403);$this->project($a,$project,true);};
        return $spaces->prepare($actor,$project,$p->name,$cookie,$guard);
    }

    public function auditProjectSpace(int $project,string $cookie):array
    {
        $actor=$this->actor();$guard=function()use($project){$a=$this->actor();if(!$a['owner'])throw new WorkshopException('仅账号维护管理员可读取共享权限核对结果。',403);$this->project($a,$project);};
        return (new ProjectSpaces($this->db))->audit($actor,$project,$cookie,$guard);
    }

    public function registerLegacyProjectSpace(int $project,array $input,string $cookie):array
    {
        $actor=$this->actor();$guard=function()use($project){$a=$this->actor();if(!$a['owner'])throw new WorkshopException('仅账号维护管理员可核对旧资源入口。',403);$this->project($a,$project,true);};
        return (new ProjectSpaces($this->db))->registerLegacy($actor,$project,$input,$cookie,$guard);
    }

    public function flushCollaborationGroups(string $cookie):array
    {
        $actor=$this->actor();return (new ProjectGroupSync($this->db))->flush($actor,$cookie,function(){if(!$this->actor()['owner'])throw new WorkshopException('账号维护权限已变化。',403);});
    }

    public function enrollmentReadiness(string $cookie):array
    {
        $actor=$this->actor();$this->requireManager($actor);$native=['available'=>false];
        if($cookie!=='')try{
            app(CollaborationAccess::class)->check($actor,$cookie);
            $r=\Illuminate\Support\Facades\Http::withHeaders(['Accept'=>'application/json','Cookie'=>$cookie])->timeout(5)->withoutRedirecting()->get('http://workshop-collaboration/index.php/apps/workshop_shell/identity');
            if($r->successful()&&is_array($r->json()))$native=$r->json()+['available'=>true];
        }catch(\Throwable){} // Diagnostics report unavailable; never grant an alternative identity.
        $mail=app(\Leantime\Core\Configuration\Environment::class);$mailReady=!config('workshop.test_mail',false)&&filter_var($mail->get('useSMTP',false),FILTER_VALIDATE_BOOLEAN)&&trim((string)$mail->get('smtpHosts',''))!==''&&filter_var($mail->get('email',''),FILTER_VALIDATE_EMAIL)!==false;
        return (new EnrollmentReadiness($this->db))->report($mailReady,$native);
    }

    public function attendance(): array
    {
        $actor=$this->actor();$attendance=new Attendance($this->db);$result=$attendance->state($actor)+['corrections'=>(new AttendanceCorrections($this->db,$attendance))->listing($actor),'can_review'=>$this->manager($actor)];
        if($result['can_review'])try{$result+=$attendance->reportMetadata($actor);}catch(WorkshopException $e){$result['report_error']=$e->getMessage();}
        return $result;
    }
    public function attendanceReport(string $date,int $user,int $page):array {return (new Attendance($this->db))->report($this->actor(),$date,$user,$page);}
    public function exportAttendanceReport(string $date,int $user):\Symfony\Component\HttpFoundation\Response {return (new Attendance($this->db))->exportReport($this->actor(),$date,$user);}

    public function attendanceCorrection(array $data,string $key): array { return (new AttendanceCorrections($this->db,new Attendance($this->db)))->submit($this->actor(),$data,$key); }
    public function reviewAttendanceCorrection(array $data): array { return (new AttendanceCorrections($this->db,new Attendance($this->db)))->review($this->actor(),$data); }
    public function recordAttendance(array $data,string $key): array { return (new Attendance($this->db))->record($this->actor(),$data,$key); }

    public function knowledge(array $data): array
    {
        $actor=$this->actor();
        $projectId=(int)($data['project_id']??0);
        $this->project($actor,$projectId); // Backend membership check precedes workspace lookup or generation.
        $question=Policy::text($data['question']??'',1500,true);
        $answer=(new Knowledge())->ask($actor,$projectId,$question);$this->project($this->actor(),$projectId);return $answer;
    }

    public function knowledgeLibrary(int $projectId):array{$actor=$this->actor();$this->project($actor,$projectId);return (new KnowledgeLibrary($this->db))->listing($projectId)+['can_publish'=>$this->leader($actor,$projectId)];}
    private function knowledgeGuard(int $project):void{$this->project($this->actor(),$project,true,true);}
    public function publishKnowledge(int $project,array $file,string $key,bool $shared,int $replaces=0,int $revision=0):array{$this->knowledgeGuard($project);if(!$shared)throw new WorkshopException('请明确确认资料可供本项目全体成员检索。');return (new KnowledgeLibrary($this->db))->publish($this->actor(),$project,$file,$key,fn()=>$this->knowledgeGuard($project),$replaces,$revision);}
    public function withdrawKnowledge(int $project,int $id,int $revision):array{$this->knowledgeGuard($project);return (new KnowledgeLibrary($this->db))->withdraw($this->actor(),$project,$id,$revision,fn()=>$this->knowledgeGuard($project));}
    public function retryKnowledge(int $project):array{$this->knowledgeGuard($project);return (new KnowledgeLibrary($this->db))->retry($this->actor(),$project,fn()=>$this->knowledgeGuard($project));}
    public function knowledgeFile(int $id):\Symfony\Component\HttpFoundation\BinaryFileResponse{$f=(new KnowledgeLibrary($this->db))->file($id);$this->project($this->actor(),(int)$f['source']->project_id);$response=new \Symfony\Component\HttpFoundation\BinaryFileResponse($f['path']);$response->setContentDisposition('attachment',$f['source']->title);$response->headers->set('Cache-Control','no-store');$response->headers->set('X-Content-Type-Options','nosniff');return $response;}

    public function identity(): array
    {
        $actor=$this->actor();
        return ['actor'=>$actor,'workspace'=>$this->workspaceMetadata($actor),
            'project_roles'=>$this->db->table('ws_memberships as m')->join('zp_projects as p','p.id','=','m.project_id')
                ->where('m.user_id',$actor['id'])->where('m.active',1)->select('m.project_id','m.role','p.name')->get()];
    }

    private function workspaceMetadata(array $actor): array
    {
        $row = $this->db->table('ws_settings')->where('key','identity')->first();
        $prefs = $this->db->table('ws_preferences')->where('user_id',$actor['id'])->value('preferences_json');
        return ['name'=>(json_decode($row->value ?? '{}',true)['name'] ?? '创新工坊'),
            'revision'=>(int)($row->revision ?? 1), 'preferences'=>json_decode($prefs ?? '{}',true),
            'test_mail'=>(bool)config('workshop.test_mail',false)];
    }

    /** Project-authorized server aggregation; never aggregate the paginated task list. */
    private function overview(array $ids): array
    {
        $now=gmdate('Y-m-d H:i:s');
        $base=$this->db->table('ws_tasks as w')->join('zp_tickets as t','t.id','=','w.task_id')
            ->join('zp_projects as p','p.id','=','t.projectId')->whereIn('t.projectId',$ids);
        $stats=(clone $base)->select('t.projectId')->selectRaw('COUNT(*) as total')
            ->selectRaw('SUM(CASE WHEN t.status != -1 AND w.cancelled = 0 THEN 1 ELSE 0 END) as active_total')
            ->selectRaw('SUM(CASE WHEN t.status = 0 AND w.cancelled = 0 THEN 1 ELSE 0 END) as done')
            ->selectRaw('SUM(CASE WHEN t.status = 2 AND w.cancelled = 0 THEN 1 ELSE 0 END) as review')
            ->selectRaw('SUM(CASE WHEN t.status = 1 AND w.cancelled = 0 THEN 1 ELSE 0 END) as blocked')
            ->selectRaw('SUM(CASE WHEN t.status NOT IN (0,-1) AND w.cancelled = 0 AND t.dateToFinish < ? THEN 1 ELSE 0 END) as overdue',[$now])
            ->selectRaw('MIN(CASE WHEN t.status NOT IN (0,-1) AND w.cancelled = 0 THEN t.dateToFinish ELSE NULL END) as next_due')
            ->groupBy('t.projectId')->get();
        $select=['t.id','t.headline','t.projectId','t.status','t.dateToFinish','w.created_at','w.baseline_due',
            'w.block_reason','w.support_needed','p.name as project_name'];
        $attention=(clone $base)->where('w.cancelled',0)->whereNotIn('t.status',[0,-1])
            ->where(function($q)use($now){$q->whereIn('t.status',[1,2])->orWhere('t.dateToFinish','<',$now);})
            ->select($select)->orderByRaw('CASE WHEN t.status = 1 THEN 0 WHEN t.status = 2 THEN 2 ELSE 1 END')
            ->orderBy('t.dateToFinish')->limit(8)->get();
        $timeline=(clone $base)->where('w.cancelled',0)->whereNotNull('t.dateToFinish')
            ->where('t.dateToFinish','>=',gmdate('Y-m-d H:i:s',time()-30*86400))
            ->where('t.dateToFinish','<=',gmdate('Y-m-d H:i:s',time()+120*86400))
            ->select($select)->orderBy('t.dateToFinish')->limit(100)->get();
        $recent=$this->db->table('ws_reviews as r')->join('ws_submissions as s','s.id','=','r.submission_id')
            ->join('zp_tickets as t','t.id','=','s.task_id')->join('zp_projects as p','p.id','=','t.projectId')
            ->whereIn('t.projectId',$ids)->where('r.decision','accepted')
            ->select('t.id','t.headline','p.name as project_name','r.created_at')->orderByDesc('r.created_at')->limit(5)->get();
        return ['projects'=>$stats,'attention'=>$attention,'timeline'=>$timeline,'recent'=>$recent,
            'timeline_limit'=>100,'timeline_from'=>gmdate('Y-m-d',time()-30*86400),'timeline_to'=>gmdate('Y-m-d',time()+120*86400)];
    }

    public function exportTasks(int $projectId = 0): \Symfony\Component\HttpFoundation\Response
    {
        $state=$this->state($projectId); // Same actor/project authorization as the workbench.
        $ids=array_map(fn($p)=>(int)$p->project_id,$state['projects']->all());
        $query=$this->db->table('ws_tasks as w')->join('zp_tickets as t','t.id','=','w.task_id')
            ->join('zp_projects as p','p.id','=','t.projectId')->leftJoin('zp_user as u','u.id','=','t.editorId')
            ->whereIn('t.projectId',$projectId?[$projectId]:$ids);
        if((clone $query)->count()>5000)throw new WorkshopException('单次最多导出5000项任务，请按项目分别导出。');
        $file=fopen('php://temp','w+');fwrite($file,"\xEF\xBB\xBF");
        fputcsv($file,['任务编号','项目','任务名称','责任人','状态','截止时间（北京时间）','原始截止时间（北京时间）','阻塞原因','支持需求'],',','"','');
        $labels=[3=>'待开展',4=>'进行中',1=>'已阻塞',2=>'待验收',0=>'已完成',-1=>'已取消'];
        $format=static fn($v)=>$v?(new \DateTimeImmutable($v,new \DateTimeZone('UTC')))->setTimezone(new \DateTimeZone('Asia/Shanghai'))->format('Y-m-d H:i'):'';
        foreach($query->select('t.id','p.name','t.headline','u.firstname','t.status','t.dateToFinish',
            'w.baseline_due','w.block_reason','w.support_needed','w.cancelled')->orderBy('t.id')->cursor() as $task){
            $row=[$task->id,$task->name,$task->headline,$task->firstname,$task->cancelled?'已取消':($labels[$task->status]??''),
                $format($task->dateToFinish),$format($task->baseline_due),$task->block_reason,$task->support_needed];
            // Neutralize spreadsheet formulas, including leading control/whitespace characters.
            $row=array_map(static function($v){$v=(string)($v??'');return preg_match('/^[\s\x00-\x1f]*[=+@-]/u',$v)?"'".$v:$v;},$row);
            fputcsv($file,$row,',','"','');
        }
        rewind($file);$content=stream_get_contents($file);fclose($file);
        return new \Symfony\Component\HttpFoundation\Response($content,200,['Content-Type'=>'text/csv; charset=utf-8',
            'Content-Disposition'=>'attachment; filename="workshop-tasks-'.gmdate('Ymd').'.csv"','Cache-Control'=>'no-store',
            'X-Content-Type-Options'=>'nosniff']);
    }

    public function detail(int $id): array
    {
        $actor = $this->actor();
        $task = $this->task($actor, $id);
        $submissions = $this->db->table('ws_submissions as s')->join('zp_user as u', 'u.id', '=', 's.user_id')
            ->leftJoin('ws_reviews as r', 'r.submission_id', '=', 's.id')
            ->where('s.task_id', $id)->select('s.*', 'u.firstname as author', 'r.decision', 'r.comment',
                'r.user_id as reviewer_id', 'r.created_at as reviewed_at')->orderByDesc('s.id')->get();
        foreach ($submissions as $submission) {
            $submission->links = json_decode($submission->links_json, true);
            $submission->files = [];
            foreach (json_decode($submission->files_json, true) as $fileId) {
                $file = $this->files->getFile((int) $fileId);
                if ($file && $file['module'] === 'ticket' && (int) $file['moduleId'] === $id) {
                    $submission->files[] = ['id' => (int) $fileId, 'name' => $file['realName']];
                }
            }
            unset($submission->links_json, $submission->files_json);
        }
        $audit = $this->db->table('ws_audit as a')->leftJoin('zp_user as u', 'u.id', '=', 'a.actor_id')
            ->where('a.project_id', $task->projectId)->where(function ($q) use ($id) {
                $q->where(function ($inner) use ($id) { $inner->where('a.entity', 'task')->where('a.entity_id', $id); })
                    ->orWhere(function ($sub) use ($id) { $sub->where('a.entity', 'submission')->whereIn('a.entity_id', $this->db->table('ws_submissions')->where('task_id', $id)->select('id')); });
            })->select('a.action', 'a.before_json', 'a.after_json', 'a.created_at', 'u.firstname as actor')
            ->orderByDesc('a.id')->limit(100)->get();
        return ['task' => $task, 'submissions' => $submissions, 'audit' => $audit,
            'origin'=>$this->db->table('ws_task_origins')->where('task_id',$id)->select('source_type','source_path')->first(),
            'can_manage' => $this->leader($actor, (int) $task->projectId),
            'can_submit' => (int) $task->editorId === $actor['id'] || $this->leader($actor, (int) $task->projectId)];
    }
}
