<?php
namespace Leantime\Domain\Workshop;
use Illuminate\Database\ConnectionInterface;
use League\Csv\Reader;
/** CSV parsing is delegated to the installed League CSV library. No credentials or account activation in imports. */
final class Roster
{
 public function __construct(private ConnectionInterface $db){}
 public function listing(): array
 {
  $rows=$this->db->table('ws_roster as r')->join('zp_projects as p','p.id','=','r.project_id')->select('r.student_no','r.name','r.project_id','r.role','r.revision','p.name as project_name')->orderBy('r.student_no')->orderBy('r.project_id')->limit(1000)->get()->all();
  return ['rows'=>$rows,'total'=>$this->db->table('ws_roster')->count(),'people'=>$this->db->table('ws_roster')->distinct()->count('student_no')];
 }
 public function preview(string $csv, bool $lock=false): array
 {
  if(strlen($csv)>1048576||!mb_check_encoding($csv,'UTF-8'))throw new WorkshopException('请使用 UTF-8 CSV，文件不超过1MB。');
  $csv=preg_replace('/^\xEF\xBB\xBF/','',$csv);
  if(str_contains($csv,"\0"))throw new WorkshopException('文件含无效字符，请重新另存为 UTF-8 CSV。');
  $reader=Reader::createFromString($csv);$reader->setHeaderOffset(0);
  try{$headers=$reader->getHeader();}catch(\Throwable){throw new WorkshopException('无法识别表头，请使用名单模板。');}
  $aliases=['学号'=>'student_no','姓名'=>'name','项目编号'=>'project_id','项目名称'=>'project_name','项目'=>'project_name','项目角色'=>'role','student_no'=>'student_no','name'=>'name','project_id'=>'project_id','project_name'=>'project_name','role'=>'role'];
  $mapping=[];
  foreach($headers as $h){$key=$aliases[trim($h)]??null;if(!$key||in_array($key,$mapping,true))throw new WorkshopException('模板需含学号、姓名、项目名称（或项目编号）、项目角色四列，表头不能重复。');$mapping[$h]=$key;}
  if(count($mapping)!==4||!in_array('student_no',$mapping,true)||!in_array('name',$mapping,true)||!in_array('role',$mapping,true)||(!in_array('project_id',$mapping,true)&&!in_array('project_name',$mapping,true)))throw new WorkshopException('缺少必填列，请下载名单模板。');
  $query=$this->db->table('ws_roster')->orderBy('id');if($lock)$query->lockForUpdate();$old=$query->get()->keyBy(fn($r)=>$r->student_no.':'.$r->project_id);
  $projects=$this->db->table('ws_projects as w')->join('zp_projects as p','p.id','=','w.project_id')->select('w.project_id','w.archived_at','p.name')->get()->keyBy('project_id');
  $people=$this->db->table('ws_people as w')->join('zp_user as u','u.id','=','w.user_id')->select('w.user_id','w.student_no','w.status','w.email_verified_at','u.status as core_status','u.firstname','u.lastname')->get()->keyBy(fn($r)=>strtoupper($r->student_no));
  $memberQuery=$this->db->table('ws_memberships')->orderBy('user_id')->orderBy('project_id');if($lock)$memberQuery->lockForUpdate();$memberSnapshot=$memberQuery->get();
  $reader->setHeaderOffset(null);
  $rows=[];$errors=[];$seen=[];$names=[];$counts=['new'=>0,'update'=>0,'unchanged'=>0];
  try{foreach($reader->getRecords() as $offset=>$raw){
   if($offset===0)continue;
   if(count($rows)>=1000)throw new WorkshopException('每次最多导入1000条项目成员关系，请分批导入。');
   $extra=count($raw)!==4;
   $row=[];foreach($mapping as $h=>$key)$row[$key]=trim((string)($raw[array_search($h,$headers,true)]??''));
   $line=$offset+1;$number=strtoupper($row['student_no']);$name=$row['name'];$project=$row['project_id']??'';
   $projectError=null;
   if(isset($row['project_name'])){
    $matches=$projects->filter(fn($p)=>!$p->archived_at&&$p->name===$row['project_name'])->values();
    if(count($matches)===1)$project=(string)$matches[0]->project_id;
    else $projectError=count($matches)>1?'项目名称存在重名，请改用项目编号':'项目名称不存在或已归档，请先建立项目并核对名称';
   }
   $role=['组长'=>'leader','组员'=>'member','leader'=>'leader','member'=>'member'][$row['role']]??'';
   $reasons=$extra?['每行必须四列，请检查分隔符和引号']:[];
   if(!preg_match('/^[a-zA-Z0-9_-]{3,64}$/D',$number))$reasons[]='学号需为3–64位字母、数字、下划线或连字符';
   if($name===''||mb_strlen($name)>60||preg_match('/[\x00-\x1F]/u',$name))$reasons[]='姓名不能为空、超过60字或含控制字符';
   if($projectError)$reasons[]=$projectError;
   elseif(!ctype_digit($project)||!isset($projects[(int)$project])||$projects[(int)$project]->archived_at)$reasons[]='项目编号不存在或已归档';
   if(!$role)$reasons[]='项目角色仅可填写组长或组员';
   $key=$number.':'.(int)$project;
   if(isset($seen[$key]))$reasons[]='同一学号与项目重复（前见第'.$seen[$key].'行）';$seen[$key]=$line;
   if(isset($names[$number])&&$names[$number]!==$name)$reasons[]='同一学号填写了不同姓名';$names[$number]=$name;
   foreach($old as $existing)if($existing->student_no===$number&&$existing->name!==$name){$reasons[]='与已导入名单姓名冲突；请核实后由管理员处理';break;}
   if(isset($people[$number])&&trim($people[$number]->firstname.' '.$people[$number]->lastname)!==$name)$reasons[]='与已注册账号姓名冲突；不能覆盖他人身份';
   $previous=$old[$key]??null;$change=!$previous?'new':($previous->name!==$name||$previous->role!==$role?'update':'unchanged');$counts[$change]++;
   $rows[]=['line'=>$line,'student_no'=>$number,'name'=>$name,'project_id'=>(int)$project,'project_name'=>$projects[(int)$project]->name??'未知项目','role'=>$role,'change'=>$change,'registered_user_id'=>isset($people[$number])?(int)$people[$number]->user_id:null,'sync_eligible'=>isset($people[$number])&&$people[$number]->status==='approved'&&$people[$number]->email_verified_at&&$people[$number]->core_status==='a','errors'=>$reasons];
   if($reasons)$errors[]=['line'=>$line,'errors'=>$reasons];
  }}catch(WorkshopException $e){throw $e;}catch(\Throwable){throw new WorkshopException('CSV格式错误，请使用模板并保持每行四列。');}
  if(!$rows)throw new WorkshopException('名单没有数据行。');
  // The digest includes existing roster revisions so stale previews cannot silently overwrite a newer import.
  $digest=hash('sha256',json_encode([$rows,$old->values()->all(),$memberSnapshot->all()],JSON_UNESCAPED_UNICODE|JSON_THROW_ON_ERROR));
  return ['rows'=>$rows,'errors'=>$errors,'counts'=>$counts,'digest'=>$digest,'valid'=>!$errors,'total'=>count($rows),'people'=>count($names)];
 }
 public function save(array $preview, ?callable $audit=null): array
 {
  $now=gmdate('Y-m-d H:i:s');
  foreach($preview['rows'] as $row){
   if($row['change']==='unchanged')continue;
   $key=['student_no'=>$row['student_no'],'project_id'=>$row['project_id']];
   $old=$this->db->table('ws_roster')->where($key)->first();
   $this->db->table('ws_roster')->updateOrInsert($key,['name'=>$row['name'],'role'=>$row['role'],'revision'=>($old->revision??0)+1,'created_at'=>$old->created_at??$now,'updated_at'=>$now]);
   if($audit)$audit($old,['student_no'=>$row['student_no'],'name'=>$row['name'],'project_id'=>$row['project_id'],'role'=>$row['role'],'revision'=>($old->revision??0)+1]);
  }
  return ['message'=>'名单已导入。学生验证邮箱并通过身份审核后，按名单分配项目；既有账号的权限不会自动改变。','counts'=>$preview['counts'],'people'=>$preview['people']];
 }
}
