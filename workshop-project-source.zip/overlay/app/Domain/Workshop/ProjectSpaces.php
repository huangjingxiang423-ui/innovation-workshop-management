<?php
namespace Leantime\Domain\Workshop;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\{Cache,Http};
/** Coordinates existing private Talk rooms and Files group shares; owns no chat/file engine. */
final class ProjectSpaces
{
 public function __construct(private ConnectionInterface $db){}
 private function client(string $cookie,string $token='')
 {
  return Http::baseUrl('http://workshop-collaboration')->withHeaders(['Cookie'=>$cookie,'Accept'=>'application/json','OCS-APIRequest'=>'true','requesttoken'=>$token])->connectTimeout(3)->timeout(12)->withoutRedirecting();
 }
 private function session(array $actor,string $cookie):array
 {
  if(!($actor['owner']??false))throw new WorkshopException('只有账号维护管理员可以建置项目协作空间。',403);
  $binding=$this->db->table('ws_identity_bindings')->where('user_id',$actor['id'])->first();
  try{
   $r=$this->client($cookie)->get('/index.php/apps/workshop_shell/identity');$i=$r->json();
   if(!$r->successful()||!$binding||!is_array($i)||($i['account_administration']??false)!==true||!hash_equals($binding->native_uid,(string)($i['uid']??''))||mb_strtolower($actor['email'])!==mb_strtolower((string)($i['email']??'')))throw new \RuntimeException();
   $r=$this->client($cookie)->get('/csrftoken');$t=$r->json('token');if(!$r->successful()||!is_string($t)||$t==='')throw new \RuntimeException();
   return [(string)$i['uid'],$t];
  }catch(\Throwable){throw new WorkshopException('请使用已绑定的账号维护管理员登录后，再建置项目空间。',403);}
 }
 private function ocs(string $method,string $path,string $cookie,string $token,array $data=[],bool $missing=false):?array
 {
  try{
   $c=$this->client($cookie,$token);$url='/ocs/v2.php'.$path.(str_contains($path,'?')?'&':'?').'format=json';$r=$method==='GET'?$c->get($url):$c->asForm()->send($method,$url,['form_params'=>$data]);$v=$r->json();
   if($missing&&$r->status()===404)return null;
   if($r->status()===412||($r->status()===403&&($v['ocs']['meta']['message']??'')==='Password confirmation is required'))throw new WorkshopException('原生服务要求管理员重新确认密码，请先完成维护确认，再返回继续建置。',428);
   if(!$r->successful()||!is_array($v)||($v['ocs']['meta']['status']??'')!=='ok')throw new WorkshopException('项目空间接口未完成（HTTP '.$r->status().'，业务码 '.(int)($v['ocs']['meta']['statuscode']??0).'，校验类别 '.(str_contains(strtolower((string)($v['ocs']['meta']['message']??'')),'csrf')?'请求校验':(str_contains(strtolower((string)($v['ocs']['meta']['message']??'')),'password')?'维护确认':'权限或服务')).'）。创建进度已保留，请重试核对。',503);
   $result=$v['ocs']['data']??[];if(!is_array($result))throw new WorkshopException('项目空间接口返回格式待核对，创建进度已保留。',503);return $result;
  }catch(WorkshopException $e){throw $e;}catch(\Throwable){throw new WorkshopException('项目空间服务结果待核对。已保存创建进度，请稍后重试核对，不要手工重复创建。',503);}
 }
 private function mark(int $project,array $fields):void
 {
  $this->db->table('ws_project_spaces')->where('project_id',$project)->update($fields+['updated_at'=>gmdate('Y-m-d H:i:s')]);
 }
 public function status(int $project,bool $canPrepare=false):array
 {
  $r=$this->db->table('ws_project_spaces')->where('project_id',$project)->first();
  if(!$r)return ['status'=>$this->db->table('ws_native_project_groups')->where('project_id',$project)->exists()?'legacy':'absent','can_prepare'=>$canPrepare];
  $ready=$r->status==='ready';return ['origin'=>$r->origin??'managed','status'=>$r->status,'can_prepare'=>$canPrepare,'chat_url'=>$ready?'/call/'.rawurlencode($r->room_token):null,'files_url'=>$ready?'/f/'.(int)$r->folder_id:null];
 }
 private function folder(object $row,string $cookie,string $token):?int
 {
  $path='/remote.php/dav/files/'.rawurlencode($row->owner_uid).'/'.rawurlencode($row->folder_path);
  try{$r=$this->client($cookie,$token)->withHeaders(['Depth'=>'0','Content-Type'=>'application/xml'])->send('PROPFIND',$path,['body'=>'<?xml version="1.0"?><d:propfind xmlns:d="DAV:" xmlns:oc="http://owncloud.org/ns"><d:prop><oc:fileid/><d:resourcetype/></d:prop></d:propfind>']);}catch(\Throwable){throw new WorkshopException('资料目录响应超时，创建进度已保留。',503);}
  if($r->status()===404)return null;
  $xml=$r->body();if($r->status()!==207||strlen($xml)>1048576||stripos($xml,'<!DOCTYPE')!==false||stripos($xml,'<!ENTITY')!==false)throw new WorkshopException('未能核对项目资料目录。',503);
  $previous=libxml_use_internal_errors(true);try{$doc=simplexml_load_string($xml,\SimpleXMLElement::class,LIBXML_NONET);if($doc===false)throw new \RuntimeException();$doc->registerXPathNamespace('d','DAV:');$doc->registerXPathNamespace('oc','http://owncloud.org/ns');$ids=$doc->xpath('//d:propstat[contains(d:status," 200 ")]/d:prop/oc:fileid');$collection=$doc->xpath('//d:propstat[contains(d:status," 200 ")]/d:prop/d:resourcetype/d:collection');if(count($ids)!==1||count($collection)!==1||!ctype_digit((string)$ids[0]))throw new \RuntimeException();return (int)$ids[0];}catch(\Throwable){throw new WorkshopException('项目资料目录格式待维护人员核对。',503);}finally{libxml_clear_errors();libxml_use_internal_errors($previous);}
 }
 private function checkShare(object $row,string $cookie,string $token):bool
 {
  $shares=$this->ocs('GET','/apps/files_sharing/api/v1/shares?path='.rawurlencode('/'.$row->folder_path),$cookie,$token);
  $found=false;
  foreach($shares as $s){
   if((string)($s['path']??'')!=='/'.$row->folder_path)continue;
   if((int)($s['share_type']??-1)!==1||($s['share_with']??'')!==$row->native_group||(int)($s['permissions']??0)!==7||(string)($s['uid_owner']??'')!==$row->owner_uid||(int)($s['file_source']??0)!==(int)$row->folder_id)throw new WorkshopException('项目目录存在额外或不一致的共享，请维护人员核对；不会修改既有共享。',409);
   $found=true;
  }
  return $found;
 }
 /** Registers pointers only. Native resources and ACLs are read, never changed. */
 public function registerLegacy(array $actor,int $project,array $input,string $cookie,callable $guard):array
 {
  $guard();if(!($actor['owner']??false))throw new WorkshopException('只有账号维护管理员可以登记已有项目资源。',403);
  $folder=$input['folder_path']??null;$room=$input['room_token']??null;
  if(!is_string($folder)||!is_string($room))throw new WorkshopException('请填写已有目录名称和群聊编号。');
  $folder=trim($folder);$room=trim($room);
  if($folder===''||mb_strlen($folder)>190||strpbrk($folder,chr(47).chr(92))!==false||preg_match('~[\x00-\x1f]~u',$folder)||in_array($folder,['.','..'],true)||!preg_match('/^[a-zA-Z0-9]{4,64}$/D',$room))throw new WorkshopException('请填写根目录中的项目资料夹名称和有效的已有群聊编号。');
  [$uid,$token]=$this->session($actor,$cookie);$lock=Cache::lock('workshop-project-space:'.$project,120);if(!$lock->get())throw new WorkshopException('该项目资源正在核对，请稍后重试。',429);
  try{
   $mapping=$this->db->table('ws_native_project_groups')->where('project_id',$project)->first();
   if(!$mapping||!$mapping->native_group||mb_strtolower($mapping->native_group)==='admin')throw new WorkshopException('请先登记并核对旧项目群组，不能按名称猜测资源归属。',409);
   $existing=$this->db->table('ws_project_spaces')->where('project_id',$project)->first();
   if($existing&&(($existing->origin??'managed')!=='legacy'||$existing->owner_uid!==$uid||$existing->folder_path!==$folder||$existing->room_token!==$room))throw new WorkshopException('项目已有其他资源登记，不会覆盖或替换现有入口。',409);
   $row=(object)['owner_uid'=>$uid,'native_group'=>$mapping->native_group,'folder_path'=>$folder,'folder_id'=>null];
   $id=$this->folder($row,$cookie,$token);if(!$id)throw new WorkshopException('当前保管账号下没有该项目资料夹。',409);$row->folder_id=$id;
   if(!$this->checkShare($row,$cookie,$token))throw new WorkshopException('资料夹未按该项目登记群组共享；本次不会替你改变共享权限。',409);
   $nativeRoom=$this->ocs('GET','/apps/spreed/api/v4/room/'.rawurlencode($room),$cookie,$token);
   if(($nativeRoom['token']??'')!==$room||(int)($nativeRoom['type']??0)!==2||!is_string($nativeRoom['name']??null)||mb_strlen($nativeRoom['name'])>190)throw new WorkshopException('提供的资源不是可登记的私有项目群聊。',409);
   $group=$this->ocs('GET','/cloud/groups/'.rawurlencode($mapping->native_group),$cookie,$token);$members=$group['users']??null;
   if(!is_array($members))throw new WorkshopException('未取得项目组的实际成员，不能完成归属核对。',503);
   $allowed=$this->db->table('ws_people as p')->join('zp_user as u','u.id','=','p.user_id')->join('ws_identity_bindings as b','b.user_id','=','p.user_id')->where('p.status','approved')->whereNotNull('p.email_verified_at')->whereRaw("LOWER(u.status) = 'a'")->where(function($q)use($project){$q->whereIn('p.workshop_role',['teacher','manager'])->orWhereExists(function($sub)use($project){$sub->selectRaw('1')->from('ws_memberships as m')->whereColumn('m.user_id','p.user_id')->where('m.project_id',$project)->where('m.active',1);});})->pluck('b.native_uid')->all();
   if(array_diff($members,array_merge([$uid],$allowed)))throw new WorkshopException('旧项目组含未获本项目授权的账号，请先人工核对，现有权限不会被本次修改。',409);
   $people=$this->ocs('GET','/apps/spreed/api/v4/room/'.rawurlencode($room).'/participants',$cookie,$token);$hasGroup=false;
   foreach($people as $p){$type=$p['actorType']??'';$member=$p['actorId']??'';if($type==='groups'&&$member===$mapping->native_group){$hasGroup=true;continue;}if($type==='users'&&($member===$uid||in_array($member,$members,true)))continue;throw new WorkshopException('已有群聊包含其他项目组或额外参与者，不能接作本项目专属入口。',409);}
   if(!$hasGroup)throw new WorkshopException('群聊未关联本项目登记群组，不能仅凭名称接入。',409);
   $guard();
   $this->db->transaction(function()use($actor,$project,$mapping,$uid,$folder,$room,$nativeRoom,$id){
    $fresh=$this->db->table('ws_native_project_groups')->where('project_id',$project)->lockForUpdate()->first();if(!$fresh||$fresh->native_group!==$mapping->native_group)throw new WorkshopException('核对期间项目群组登记已变化，请重新核对。',409);
    $old=$this->db->table('ws_project_spaces')->where('project_id',$project)->lockForUpdate()->first();
    $data=['project_id'=>$project,'native_group'=>$mapping->native_group,'owner_uid'=>$uid,'folder_path'=>$folder,'folder_id'=>$id,'room_name'=>$nativeRoom['name'],'room_token'=>$room,'group_attempted'=>1,'folder_attempted'=>1,'room_attempted'=>1,'origin'=>'legacy','status'=>'ready','last_error'=>null,'updated_at'=>gmdate('Y-m-d H:i:s')];
    if($old){if(($old->origin??'managed')!=='legacy'||$old->owner_uid!==$uid||$old->native_group!==$mapping->native_group||$old->folder_path!==$folder||$old->room_token!==$room||(int)$old->folder_id!==$id)throw new WorkshopException('资源登记已变化，不会覆盖现有入口。',409);$this->mark($project,['status'=>'ready','last_error'=>null]);}
    else $this->db->table('ws_project_spaces')->insert($data+['created_at'=>gmdate('Y-m-d H:i:s')]);
    $this->db->table('ws_audit')->insert(['actor_id'=>$actor['id'],'project_id'=>$project,'action'=>'project.legacy_links_verified','entity'=>'project','entity_id'=>$project,'before_json'=>null,'after_json'=>json_encode(['native_writes'=>false,'private_chat'=>true,'group_files'=>true]),'created_at'=>gmdate('Y-m-d H:i:s')]);
   });
   return $this->status($project,true)+['message'=>'已有项目聊天与资料入口已核对接通，未移动文件或更改原生权限。'];
  }finally{$lock->release();}
 }
 /** Read-only, explicitly partial ACL inventory through existing native APIs. */
 public function audit(array $actor,int $project,string $cookie,callable $guard):array
 {
  $guard();[$uid,$token]=$this->session($actor,$cookie);
  $row=$this->db->table('ws_project_spaces')->where('project_id',$project)->first();
  if(!$row||$row->status!=='ready')throw new WorkshopException('请先核对并登记本项目的聊天与资料入口。',409);
  if(!hash_equals((string)$row->owner_uid,$uid))throw new WorkshopException('请由登记的资料保管账号读取共享权限。',403);
  $findings=[];$read=function($path)use($cookie,$token,$guard){$guard();return $this->ocs('GET',$path,$cookie,$token);};
  $group=$read('/cloud/groups/'.rawurlencode($row->native_group));$members=$group['users']??null;
  if(!is_array($members))throw new WorkshopException('未取得项目组成员，不能完成只读核对。',503);
  $allowed=$this->db->table('ws_people as p')->join('zp_user as u','u.id','=','p.user_id')->join('ws_identity_bindings as b','b.user_id','=','p.user_id')->where('p.status','approved')->whereNotNull('p.email_verified_at')->whereRaw("LOWER(u.status) = 'a'")->where(function($q)use($project){$q->whereIn('p.workshop_role',['teacher','manager'])->orWhereExists(function($sub)use($project){$sub->selectRaw('1')->from('ws_memberships as m')->whereColumn('m.user_id','p.user_id')->where('m.project_id',$project)->where('m.active',1);});})->pluck('b.native_uid')->all();
  $extra=count(array_diff($members,array_merge([$uid],$allowed)));if($extra)$findings[]=['area'=>'项目组','message'=>'有 '.$extra.' 个成员不在当前项目授权名单内，请先核对人员同步。'];
  $path='/apps/files_sharing/api/v1/shares?path='.rawurlencode('/'.$row->folder_path);
  $shares=$read($path);$outgoing=$read('/apps/files_sharing/api/v1/shares');$children=[];$prefix='/'.$row->folder_path.'/';
  foreach($outgoing as $share){
   if(!is_array($share))throw new WorkshopException('共享清单格式异常，本次核对未完成。',503);
   $sharePath=$share['path']??null;if(!is_string($sharePath)||!str_starts_with($sharePath,$prefix))continue;
   $relative=substr($sharePath,strlen($prefix));if($relative===''||str_contains($relative,chr(0))||array_intersect(explode('/',$relative),['.','..','']))throw new WorkshopException('共享路径格式异常，本次核对未完成。',503);
   $children[]=['path'=>mb_substr($relative,0,500),'file_id'=>ctype_digit((string)($share['file_source']??''))&&(int)$share['file_source']>0?(int)$share['file_source']:null];
  }
  $expected=false;$rootExtra=0;
  foreach($shares as $share){
   if(($share['path']??'')==='/'.$row->folder_path&&(int)($share['share_type']??-1)===1&&($share['share_with']??'')===$row->native_group&&(int)($share['permissions']??0)===7&&($share['uid_owner']??'')===$uid&&(int)($share['file_source']??0)===(int)$row->folder_id){$expected=true;continue;}
   $rootExtra++;
  }
  if(!$expected)$findings[]=['area'=>'项目资料夹','message'=>'未确认预期的项目组共享（读取、新建、修改），请在原生共享设置核对。'];
  if($rootExtra)$findings[]=['area'=>'项目资料夹','message'=>'发现 '.$rootExtra.' 条额外或不一致的共享；直接个人共享或公开链接可能不随项目组退出而收回。'];
  if(count($children))$findings[]=['area'=>'项目目录各层级共享','message'=>'保管账号发出的共享清单中发现 '.count($children).' 条项目目录内单独共享，请逐项核对；本次不自动删除。','resources'=>array_slice($children,0,50),'truncated'=>count($children)>50];
  $room=$read('/apps/spreed/api/v4/room/'.rawurlencode($row->room_token));
  if(($room['token']??'')!==$row->room_token||(int)($room['type']??0)!==2)$findings[]=['area'=>'项目聊天','message'=>'未确认登记的私有群聊，请核对群聊访问设置。'];
  $participants=$read('/apps/spreed/api/v4/room/'.rawurlencode($row->room_token).'/participants');$hasGroup=false;$direct=0;$outsiders=0;
  foreach($participants as $person){$type=$person['actorType']??'';$id=$person['actorId']??'';if($type==='groups'&&$id===$row->native_group){$hasGroup=true;continue;}if($type==='users'&&$id===$uid)continue;if($type==='users'&&in_array($id,$allowed,true))$direct++;else $outsiders++;}
  if(!$hasGroup)$findings[]=['area'=>'项目聊天','message'=>'未发现登记的项目组参与者，不能依赖项目组同步回收群聊访问。'];
  if($direct)$findings[]=['area'=>'项目聊天','message'=>'有 '.$direct.' 条当前授权成员的账号参与记录；接口未区分邀请来源，请在原生群聊中核对，不能据此认定为额外直邀。'];
  if($outsiders)$findings[]=['area'=>'项目聊天','message'=>'发现 '.$outsiders.' 个额外参与者或其他项目组，请在原生群聊成员设置核对。'];
  $guard();$fresh=$this->db->table('ws_project_spaces')->where('project_id',$project)->first();
  foreach(['native_group','owner_uid','folder_path','folder_id','room_token'] as $key)if(!$fresh||$fresh->$key!==$row->$key)throw new WorkshopException('核对期间项目资源登记变化，请重新读取。',409);
  return ['project_id'=>$project,'checked_at'=>gmdate('Y-m-d H:i:s'),'scope'=>'项目组、资料根目录及保管账号发出的项目目录各层级共享、群聊参与者；不含其他成员自行转共享、外部客户端缓存。','partial'=>true,'findings'=>$findings,'message'=>$findings?'发现需人工核对的授权，尚未修改任何共享。':'本次读取范围内未发现额外授权；不代表完整权限审计通过。'];
 }
 public function prepare(array $actor,int $project,string $title,string $cookie,callable $guard):array
 {
  $guard();[$uid,$token]=$this->session($actor,$cookie);
  $lock=Cache::lock('workshop-project-space:'.$project,300);if(!$lock->get())throw new WorkshopException('该项目空间正在建置，请稍后查看。',429);
  $started=false;
  try{
   $row=$this->db->table('ws_project_spaces')->where('project_id',$project)->first();
   if($row&&($row->origin??'managed')==='legacy')throw new WorkshopException('旧资源仅登记入口，请使用已有资源核对流程；不会自动重建或修改它。',409);
   if(!$row){
    if($this->db->table('ws_native_project_groups')->where('project_id',$project)->exists())throw new WorkshopException('该项目已有历史协作空间；需核对旧资源后迁移，不能重复建置。',409);
    $code=bin2hex(random_bytes(10));$name=mb_substr(preg_replace('/[\/\\\\\x00-\x1f]/u',' ',$title),0,55).' · P'.$project;$now=gmdate('Y-m-d H:i:s');
    $this->db->table('ws_project_spaces')->insert(['project_id'=>$project,'native_group'=>'ws_project_'.$code,'owner_uid'=>$uid,'folder_path'=>$name,'room_name'=>$name,'status'=>'pending','created_at'=>$now,'updated_at'=>$now]);
    $row=$this->db->table('ws_project_spaces')->where('project_id',$project)->first();
   }
   $wasReady=$row->status==='ready';
   if(!hash_equals($row->owner_uid,$uid))throw new WorkshopException('请由原项目空间保管账号继续核对，不能改到其他账号名下。',409);
   // Re-check every resource on explicit retry; a ready label alone is not an ACL proof.
   $this->mark($project,['status'=>'pending','last_error'=>null]);$started=true;
   $guard();$group=$this->ocs('GET','/cloud/groups/'.rawurlencode($row->native_group),$cookie,$token,[],true);
   if($group!==null&&!$row->group_attempted)throw new WorkshopException('预留项目组已存在，需人工核对归属。',409);
   if($group===null){$this->mark($project,['group_attempted'=>1]);$this->ocs('POST','/cloud/groups',$cookie,$token,['groupid'=>$row->native_group,'displayname'=>$row->room_name]);$group=$this->ocs('GET','/cloud/groups/'.rawurlencode($row->native_group),$cookie,$token);}
   if(!is_array($group['users']??null))throw new WorkshopException('项目组创建结果不一致。',409);
   // Follow the native group-only sharing policy; the existing custodian already owns the folder.
   if(!in_array($uid,$group['users'],true)){
    $guard();$this->ocs('POST','/cloud/users/'.rawurlencode($uid).'/groups',$cookie,$token,['groupid'=>$row->native_group]);
    $group=$this->ocs('GET','/cloud/groups/'.rawurlencode($row->native_group),$cookie,$token);
    if(!in_array($uid,$group['users']??[],true))throw new WorkshopException('项目资料保管账号的项目组关系尚未核对。',503);
   }

   $allowed=$this->db->table('ws_people as p')->join('zp_user as u','u.id','=','p.user_id')->join('ws_identity_bindings as b','b.user_id','=','p.user_id')->where('p.status','approved')->whereNotNull('p.email_verified_at')->whereRaw("LOWER(u.status) = 'a'")->where(function($q)use($project){$q->whereIn('p.workshop_role',['teacher','manager'])->orWhereExists(function($sub)use($project){$sub->selectRaw('1')->from('ws_memberships as m')->whereColumn('m.user_id','p.user_id')->where('m.project_id',$project)->where('m.active',1);});})->pluck('b.native_uid')->all();
   if(array_diff($group['users'],array_merge([$uid],$allowed)))throw new WorkshopException('项目组存在未获本项目授权的账号，请维护人员核对；不会自动扩大授权。',409);
   $guard();$folder=$this->folder($row,$cookie,$token);
   if($folder!==null&&!$row->folder_attempted)throw new WorkshopException('预留资料目录已存在，需人工核对归属。',409);
   if($folder===null){
    $this->mark($project,['folder_attempted'=>1]);$path='/remote.php/dav/files/'.rawurlencode($uid).'/'.rawurlencode($row->folder_path);
    try{$r=$this->client($cookie,$token)->send('MKCOL',$path);if($r->status()!==201)throw new \RuntimeException();}catch(\Throwable){throw new WorkshopException('资料目录创建结果待核对，请稍后重试核对。',503);}
    $folder=$this->folder($row,$cookie,$token);
   }
   if(!$folder||($row->folder_id&&(int)$row->folder_id!==$folder))throw new WorkshopException('项目资料目录编号不一致，需人工核对。',409);
   $row->folder_id=$folder;$this->mark($project,['folder_id'=>$folder]);
   if(!$this->checkShare($row,$cookie,$token)){$guard();$this->ocs('POST','/apps/files_sharing/api/v1/shares',$cookie,$token,['path'=>'/'.$row->folder_path,'shareType'=>1,'shareWith'=>$row->native_group,'permissions'=>7]);if(!$this->checkShare($row,$cookie,$token))throw new WorkshopException('资料共享尚未核对成功。',503);}
   $guard();$room=null;
   if($row->room_token)$room=$this->ocs('GET','/apps/spreed/api/v4/room/'.rawurlencode($row->room_token),$cookie,$token);
   else{
    $rooms=$this->ocs('GET','/apps/spreed/api/v4/room',$cookie,$token);$matches=array_values(array_filter($rooms,fn($r)=>($r['name']??'')===$row->room_name));
    if(count($matches)>1||($matches&&!$row->room_attempted))throw new WorkshopException('预留聊天名称已有记录，请人工核对归属。',409);
    if($matches)$room=$matches[0];
    elseif($row->room_attempted)throw new WorkshopException('此前聊天创建结果不确定，需维护人员核对，不能重复创建。',409);
    else{$this->mark($project,['room_attempted'=>1]);$room=$this->ocs('POST','/apps/spreed/api/v4/room',$cookie,$token,['roomType'=>2,'roomName'=>$row->room_name,'source'=>'groups','invite'=>$row->native_group]);}
   }
   $roomToken=(string)($room['token']??'');
   if(!preg_match('/^[a-zA-Z0-9]{4,64}$/D',$roomToken)||(int)($room['type']??0)!==2||($room['name']??'')!==$row->room_name)throw new WorkshopException('项目聊天不是预期的私有群聊，请人工核对。',409);
   $this->mark($project,['room_token'=>$roomToken]);
   $participants=$this->ocs('GET','/apps/spreed/api/v4/room/'.$roomToken.'/participants',$cookie,$token);
   $users=$group['users']??$this->ocs('GET','/cloud/groups/'.rawurlencode($row->native_group).'/users',$cookie,$token)['users']??[];
   if(!is_array($users))throw new WorkshopException('无法核对项目聊天成员。',503);
   $hasGroup=false;
   foreach($participants as $p){$type=$p['actorType']??'';$id=$p['actorId']??'';
    if($type==='groups'&&$id===$row->native_group){$hasGroup=true;continue;}
    if($type==='users'&&($id===$uid||in_array($id,$users,true)))continue;
    throw new WorkshopException('项目聊天存在额外参与者，请人工核对；不会移除未知成员。',409);
   }
   if(!$hasGroup)throw new WorkshopException('项目聊天尚未关联指定项目组。',409);
   $guard();
   $this->db->transaction(function()use($project,$actor,$row,$wasReady){
    $locked=$this->db->table('ws_project_spaces')->where('project_id',$project)->lockForUpdate()->first();if(!$locked||$locked->native_group!==$row->native_group)throw new WorkshopException('项目空间登记已变化。',409);
    $mapping=$this->db->table('ws_native_project_groups')->where('project_id',$project)->first();if($mapping&&$mapping->native_group!==$row->native_group)throw new WorkshopException('项目组登记冲突。',409);
    $now=gmdate('Y-m-d H:i:s');$this->db->table('ws_native_project_groups')->insertOrIgnore(['project_id'=>$project,'native_group'=>$row->native_group,'source'=>'workshop-project-space','created_at'=>$now,'updated_at'=>$now]);
    $people=$this->db->table('ws_people as p')->join('ws_identity_bindings as b','b.user_id','=','p.user_id')->where(function($q)use($project){$q->whereIn('p.workshop_role',['teacher','manager'])->orWhereExists(function($sub)use($project){$sub->selectRaw('1')->from('ws_memberships as m')->whereColumn('m.user_id','p.user_id')->where('m.project_id',$project)->where('m.active',1);});})->pluck('p.user_id');
    if(!$wasReady){$sync=new ProjectGroupSync($this->db);foreach($people as $id)$sync->queue((int)$id);}
    $this->mark($project,['status'=>'ready','last_error'=>null]);$this->db->table('ws_audit')->insert(['actor_id'=>$actor['id'],'project_id'=>$project,'action'=>'project.space_verified','entity'=>'project','entity_id'=>$project,'before_json'=>null,'after_json'=>json_encode(['private_chat'=>true,'group_files'=>true,'file_permissions'=>7]),'created_at'=>$now]);
   });
   return $this->status($project,true)+['message'=>'项目私有聊天与共享资料已建置核对，请完成成员权限同步后使用。'];
  }catch(\Throwable $e){if($started)$this->mark($project,['status'=>'pending','last_error'=>'reconciliation_required']);throw $e;}finally{$lock->release();}
 }
}
