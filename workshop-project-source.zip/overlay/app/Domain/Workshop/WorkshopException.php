<?php

namespace Leantime\Domain\Workshop;

final class WorkshopException extends \RuntimeException
{
    public function __construct(string $message, public readonly int $status = 422)
    {
        parent::__construct($message);
    }
}
