<?php
namespace Leantime\Domain\Workshop;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Cache;

/** Only maps an approved workshop identity to native Employee Checkin. No attendance rules invented. */
final class Attendance
{
 private array $config=[];
 public function __construct(private ConnectionInterface $db)
 {
  if(is_readable('/run/workshop-attendance/config.json')){
   try{$this->config=json_decode(file_get_contents('/run/workshop-attendance/config.json'),true,32,JSON_THROW_ON_ERROR)?:[];}catch(\Throwable){}
  }
 }
 private function employee(array $actor): ?array
 {
  $employee=$this->config['employees'][(string)$actor['id']]??null;
  if(!is_array($employee)||empty($employee['id']))return null;
  return $employee;
 }
 private function call(string $method,string $path,array $data=[]): array
 {
  if(($this->config['base_url']??'')!=='http://workshop-attendance:8000/api/'||empty($this->config['api_key'])||empty($this->config['api_secret']))throw new WorkshopException('考勤服务尚未接入，请联系管理员。',409);
  try{
   $client=Http::connectTimeout(3)->timeout(12)->acceptJson()->withHeaders(['Host'=>'workshop.localhost','Authorization'=>'token '.$this->config['api_key'].':'.$this->config['api_secret']]);
   $response=$method==='GET'?$client->get($this->config['base_url'].$path,$data):$client->post($this->config['base_url'].$path,$data);
   if(!$response->successful())throw new \RuntimeException('upstream failed');
   $body=$response->json();if(!is_array($body)||!isset($body['data']))throw new \RuntimeException('invalid response');
   return $body['data'];
  }catch(\Throwable){throw new WorkshopException($method === 'GET' ? '考勤服务暂不可用，读取未完成，请稍后重试。' : '考勤服务暂不可用，保存结果待确认。请重试同一次操作，系统会核对记录并防止重复写入。',503);}
 }
 private function records(string $employee,array $extra=[],int $limit=50): array
 {
  return $this->call('GET','resource/Employee%20Checkin',['fields'=>json_encode(['name','employee','log_type','time','device_id']),
   'filters'=>json_encode(array_merge([['employee','=',$employee]],$extra)),'order_by'=>'time desc, creation desc','limit_page_length'=>$limit]);
 }
 private function clean(array $record): array
 {return ['id'=>(string)$record['name'],'event_type'=>(string)$record['log_type'],'time'=>(string)$record['time']];}
 public function state(array $actor): array
 {
  $employee=$this->employee($actor);if(!$employee)return ['connected'=>false,'message'=>'你的工坊账号尚未绑定考勤档案，请联系管理员。'];
  $records=$this->records($employee['id']);$last=$records[0]??null;
  $today=(new \DateTimeImmutable('now',new \DateTimeZone('Asia/Shanghai')))->format('Y-m-d');
  $anomaly=$last&&$last['log_type']==='IN'&&substr($last['time'],0,10)!==$today;
  return ['connected'=>true,'employee_name'=>$employee['name'],'records'=>array_map($this->clean(...),$records),
   'checked_in'=>$last&&$last['log_type']==='IN','needs_correction'=>$anomaly,'timezone'=>'Asia/Shanghai','rules_pending'=>true,'correction_source'=>$anomaly?$this->clean($last):null,
   'weekly_summaries'=>$this->weeklySummaries($employee['id']),'message'=>$anomaly?'有跨日未签退记录，请提交补签退申请；审核完成前不计算这段出勤时长。':'签到时间由服务器记录，当前试用不自动计算正式出勤结果。'];
 }
 private function weeklySummaries(string $employee): array
 {
  $now=new \DateTimeImmutable('now',new \DateTimeZone('Asia/Shanghai'));$monday=$now->modify('monday this week')->setTime(0,0);$start=$monday->modify('-7 days');
  $rows=$this->records($employee,[['time','>=',$start->format('Y-m-d H:i:s')],['time','<=',$now->format('Y-m-d H:i:s')]],1001);
  $prior=$this->records($employee,[['time','<',$start->format('Y-m-d H:i:s')]],2);
  $complete=count($rows)<=1000;
  $all=array_merge($rows,$prior);
  return [AttendanceSummary::build($all,$monday,$now,$complete),AttendanceSummary::build($all,$start,$now,$complete)];
 }
 private function reportPeople(array $actor):array
 {
  if(!($actor['owner']??false)&&!in_array($actor['role']??'',['teacher','manager'],true))throw new WorkshopException('只有老师或总负责人可以查询工坊考勤记录。',403);
  $mapping=$this->config['employees']??[];$ids=[];$seen=[];
  foreach($mapping as $id=>$employee){if(!ctype_digit((string)$id)||!is_array($employee)||!is_string($employee['id']??null)||$employee['id']==='')continue;if(isset($seen[$employee['id']]))throw new WorkshopException('考勤档案存在重复绑定，请维护管理员核对后再查询。',409);$seen[$employee['id']]=true;$ids[]=(int)$id;}
  $rows=$this->db->table('zp_user as u')->leftJoin('ws_people as p','p.user_id','=','u.id')->whereIn('u.id',$ids)->select('u.id','u.firstname','u.lastname','p.student_no')->orderBy('u.firstname')->get();$result=[];
  foreach($rows as $row)$result[]=['user_id'=>(int)$row->id,'name'=>trim($row->firstname.' '.$row->lastname),'student_no'=>(string)($row->student_no??''),'employee'=>$mapping[(string)$row->id]['id']];
  return $result;
 }
 public function reportMetadata(array $actor):array
 {
  $people=$this->reportPeople($actor);foreach($people as &$person)unset($person['employee']);unset($person);
  return ['report_people'=>$people,'report_week'=>(new \DateTimeImmutable('now',new \DateTimeZone('Asia/Shanghai')))->modify('monday this week')->format('Y-m-d')];
 }
 public function report(array $actor,string $date,int $user=0,int $page=1,bool $export=false):array
 {
  $people=$this->reportPeople($actor);$zone=new \DateTimeZone('Asia/Shanghai');
  if($date==='')$date=(new \DateTimeImmutable('now',$zone))->format('Y-m-d');
  $day=\DateTimeImmutable::createFromFormat('!Y-m-d',$date,$zone);
  if(!$day||$day->format('Y-m-d')!==$date)throw new WorkshopException('请选择有效日期。');
  if($page<1||$page>1000||$user<0)throw new WorkshopException('查询页码或人员无效。');
  $monday=$day->modify('monday this week');$end=$monday->modify('+7 days');$index=[];
  foreach($people as $person)if(!$user||$person['user_id']===$user)$index[$person['employee']]=$person;
  if($user&&!$index)throw new WorkshopException('该人员没有已登记的考勤绑定。',404);
  $limit=$export?5001:51;$raw=$index?$this->call('GET','resource/Employee%20Checkin',['fields'=>json_encode(['name','employee','log_type','time']), 'filters'=>json_encode([['employee','in',array_keys($index)],['time','>=',$monday->format('Y-m-d H:i:s')],['time','<',$end->format('Y-m-d H:i:s')]]),'order_by'=>'time desc, name desc','limit_start'=>$export?0:($page-1)*50,'limit_page_length'=>$limit]):[];
  if(count($raw)>$limit)throw new WorkshopException('原生记录分页结果异常，请稍后重试。',503);
  if($export&&count($raw)>5000)throw new WorkshopException('本周记录超过5000条，请选择具体人员后导出，避免导出不完整结果。',409);
  $more=!$export&&count($raw)>50;$records=[];
  foreach(array_slice($raw,0,$export?5000:50) as $record){
   if(!is_array($record)||!isset($index[$record['employee']??''])||!is_string($record['time']??null)||!is_string($record['name']??null)||!is_string($record['log_type']??null))throw new WorkshopException('原生考勤记录范围或格式异常，本次查询未完成。',503);
   $time=\DateTimeImmutable::createFromFormat('!Y-m-d H:i:s',substr($record['time'],0,19),$zone);
   if(!$time||$time->format('Y-m-d H:i:s')!==substr($record['time'],0,19)||$time<$monday||$time>=$end)throw new WorkshopException('原生考勤记录日期范围异常，本次查询未完成。',503);
   $person=$index[$record['employee']];$records[]=['id'=>$record['name'],'user_id'=>$person['user_id'],'name'=>$person['name'],'student_no'=>$person['student_no'],'event_type'=>$record['log_type'],'time'=>$record['time']];
  }
  $corrections=$this->db->table('ws_attendance_corrections')->where('status','approved')->whereIn('native_record_id',array_column($records,'id'))->pluck('native_record_id')->all();
  foreach($records as &$record)$record['corrected']=in_array($record['id'],$corrections,true);unset($record);
  return ['start'=>$monday->format('Y-m-d'),'end'=>$end->modify('-1 day')->format('Y-m-d'),'timezone'=>'Asia/Shanghai','page'=>$page,'has_more'=>$more,'records'=>$records,'user_id'=>$user];
 }
 public function exportReport(array $actor,string $date,int $user):\Symfony\Component\HttpFoundation\Response
 {
  $report=$this->report($actor,$date,$user,1,true);$file=fopen('php://temp','w+');fwrite($file,"\xEF\xBB\xBF");
  fputcsv($file,['姓名','学员编号','操作','记录时间（北京时间）','是否审核补正','原生记录编号'],',','"','');
  foreach($report['records'] as $record){$row=[$record['name'],$record['student_no'],['IN'=>'签到','OUT'=>'签退'][$record['event_type']]??'未知类型',$record['time'],$record['corrected']?'是':'否',$record['id']];$row=array_map(static function($v){$v=(string)$v;return preg_match('/^[\s\x00-\x1f]*[=+@-]/u',$v)?"'".$v:$v;},$row);fputcsv($file,$row,',','"','');}
  rewind($file);$content=stream_get_contents($file);fclose($file);
  return new \Symfony\Component\HttpFoundation\Response($content,200,['Content-Type'=>'text/csv; charset=utf-8','Content-Disposition'=>'attachment; filename="workshop-checkins-'.$report['start'].'.csv"','Cache-Control'=>'no-store','X-Content-Type-Options'=>'nosniff']);
 }
 public function appendApprovedCheckout(array $request): array
 {
  if(($request['status']??'')!=='processing')throw new WorkshopException('补正尚未获准同步。',409);
  $employee=$this->employee(['id'=>$request['user_id']]);if(!$employee)throw new WorkshopException('申请人的考勤档案尚未绑定。',409);
  $device='WS-CORR-'.substr(hash('sha256',(string)$request['id'].'|'.$request['user_id'].'|'.$request['source_record_id']),0,28);
  $found=$this->records($employee['id'],[['time','=',$request['requested_time']],['log_type','=','OUT'],['device_id','=',$device]],1);
  if($found)return $this->clean($found[0]);
  $records=$this->records($employee['id'],[],1);$last=$records[0]??null;
  if(!$last||$last['name']!==$request['source_record_id']||$last['log_type']!=='IN'||$last['time']!==$request['source_time']||$request['requested_time']<=$last['time'])throw new WorkshopException('原始考勤已发生变化，请联系审核人核对，不会覆盖历史。',409);
  $now=(new \DateTimeImmutable('now',new \DateTimeZone('Asia/Shanghai')))->format('Y-m-d H:i:s');
  if($request['requested_time']>$now)throw new WorkshopException('补正时间不能晚于服务器当前时间。',409);
  return $this->clean($this->call('POST','resource/Employee%20Checkin',['employee'=>$employee['id'],'log_type'=>'OUT','time'=>$request['requested_time'],'device_id'=>$device,'skip_auto_attendance'=>1]));
 }
 public function record(array $actor,array $data,string $key): array
 {
  $employee=$this->employee($actor);if(!$employee)throw new WorkshopException('你的账号尚未绑定考勤档案，请联系管理员。',409);
  $kind=$data['event_type']??'';
  if(!in_array($kind,['IN','OUT'],true)||array_diff(array_keys($data),['event_type']))throw new WorkshopException('请使用签到或签退按钮；不能指定他人或修改服务器时间。');
  if(!preg_match('/^[a-zA-Z0-9_-]{16,80}$/D',$key))throw new WorkshopException('缺少有效操作编号，请刷新后重试。');
  $lock=Cache::lock('workshop-attendance-'.$actor['id'],90);
  if(!$lock->get())throw new WorkshopException('上一次考勤操作正在核对，请稍后重试。',409);
  try{
   $hash=hash('sha256',$employee['id'].'|'.$kind);
   // The intent is committed independently of the native HTTP write, so timeout/restart retries retain their timestamp.
   $request=$this->db->transaction(function()use($actor,$employee,$kind,$key,$hash){
    $payload=['employee'=>$employee['id'],'log_type'=>$kind,'time'=>(new \DateTimeImmutable('now',new \DateTimeZone('Asia/Shanghai')))->format('Y-m-d H:i:s'),
     'device_id'=>'WS-'.substr(hash('sha256',$actor['id'].'|'.$key),0,32),'skip_auto_attendance'=>1];
    $now=gmdate('Y-m-d H:i:s');
    $this->db->table('ws_bridge_requests')->insertOrIgnore(['user_id'=>$actor['id'],'request_key'=>$key,'operation'=>'attendance','request_hash'=>$hash,'payload_json'=>json_encode($payload),'created_at'=>$now,'updated_at'=>$now]);
    $request=$this->db->table('ws_bridge_requests')->where('user_id',$actor['id'])->where('request_key',$key)->lockForUpdate()->first();
    if(!$request||$request->operation!=='attendance'||!hash_equals($request->request_hash,$hash))throw new WorkshopException('同一操作编号不能用于不同考勤内容。',409);
    return $request;
   });
   if($request->response_json!==null)return json_decode($request->response_json,true,flags:JSON_THROW_ON_ERROR);
   $payload=json_decode($request->payload_json,true,flags:JSON_THROW_ON_ERROR);
   $found=$this->records($employee['id'],[['time','=',$payload['time']],['log_type','=',$kind],['device_id','=',$payload['device_id']]],1);
   if($found){$record=$found[0];}else{
    $records=$this->records($employee['id'],[],1);$last=$records[0]??null;
    if($last&&$last['time']>$payload['time'])throw new WorkshopException('这次操作之后已有新的考勤记录，请刷新后核对；不会补写旧时间。',409);
    if($kind==='IN'&&$last&&$last['log_type']==='IN')throw new WorkshopException('你已有未签退的记录，请先签退；跨日漏签请联系管理员补正。',409);
    if($kind==='OUT'&&(!$last||$last['log_type']!=='IN'))throw new WorkshopException('没有待签退的签到记录，不能重复签退。',409);
    if($last&&$last['log_type']==='IN'&&substr($last['time'],0,10)!==substr($payload['time'],0,10))throw new WorkshopException('发现跨日未签退，请联系管理员补正，避免产生错误出勤时长。',409);
    $record=$this->call('POST','resource/Employee%20Checkin',$payload);
   }
   return $this->db->transaction(function()use($actor,$key,$kind,$record){
    $request=$this->db->table('ws_bridge_requests')->where('user_id',$actor['id'])->where('request_key',$key)->lockForUpdate()->first();
    if($request->response_json!==null)return json_decode($request->response_json,true,flags:JSON_THROW_ON_ERROR);
    $result=['message'=>$kind==='IN'?'签到已记录。':'签退已记录。','record'=>$this->clean($record)];$now=gmdate('Y-m-d H:i:s');
    $this->db->table('ws_bridge_requests')->where('id',$request->id)->update(['response_json'=>json_encode($result,JSON_UNESCAPED_UNICODE),'updated_at'=>$now]);
    $this->db->table('ws_audit')->insert(['actor_id'=>$actor['id'],'project_id'=>null,'action'=>'attendance.recorded','entity'=>'attendance','entity_id'=>null,'before_json'=>null,'after_json'=>json_encode($result['record'],JSON_UNESCAPED_UNICODE),'created_at'=>$now]);
    return $result;
   });
  }finally{$lock->release();}
 }
}
