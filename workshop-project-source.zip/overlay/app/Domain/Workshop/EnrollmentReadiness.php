<?php
namespace Leantime\Domain\Workshop;
use Illuminate\Database\ConnectionInterface;
/** Read-only onboarding diagnostics. A verified roster account is not a native invitation or ACL sync. */
final class EnrollmentReadiness
{
 public function __construct(private ConnectionInterface $db){}
 public function report(bool $coreMailReady,array $native):array
 {
  $rows=$this->db->table('ws_people as w')->join('zp_user as u','u.id','=','w.user_id')->leftJoin('ws_identity_bindings as b','b.user_id','=','w.user_id')->select('w.user_id','w.status','w.workshop_role','w.email_verified_at','u.status as account_status','b.user_id as bound')->get();
  $members=$this->db->table('ws_memberships')->where('active',1)->pluck('user_id')->map(fn($v)=>(int)$v)->all();
  $counts=array_fill_keys(['inactive','awaiting_review','awaiting_email','awaiting_project','awaiting_account','bound'],0);$people=[];
  foreach($rows as $p){
   $status=in_array($p->status,['suspended','rejected'],true)?'inactive':(!$p->email_verified_at?'awaiting_email':($p->status!=='approved'?'awaiting_review':(strtolower((string)$p->account_status)!=='a'?'inactive':(!in_array($p->workshop_role,['teacher','manager'],true)&&!in_array((int)$p->user_id,$members,true)?'awaiting_project':($p->bound?'bound':'awaiting_account')))));
   $counts[$status]++;$people[]=['user_id'=>(int)$p->user_id,'status'=>$status];
  }
  $checks=[['id'=>'registration_mail','label'=>'注册验证与找回密码发信','ready'=>$coreMailReady],['id'=>'invitation_mail','label'=>'消息与资料账号邀请发信','ready'=>($native['invitation_mail_ready']??false)===true],['id'=>'native_administrator','label'=>'当前统一登录账号具备账号维护权限','ready'=>($native['account_administration']??false)===true]];
  return ['counts'=>$counts,'people'=>$people,'checks'=>$checks,'native_available'=>($native['available']??false)===true,'account_provisioning_available'=>false,'project_acl_sync_available'=>false,'project_group_sync_available'=>$this->db->table('ws_native_project_groups')->exists(),'pending_group_sync_count'=>$this->db->table('ws_native_access_sync')->where('status','pending')->count(),'message'=>'这是开通准备检查，不会创建账号、发信或调整权限。已绑定只代表登录身份已关联，不能据此认定项目群聊和资料权限已完成同步。'];
 }
}
