<?php
namespace Leantime\Domain\Workshop;
/** A manual reference, never an assertion that meeting content belongs to the target project. */
final class MeetingReference
{
 public static function path(mixed $value):string
 {
  if(!is_string($value)||strlen($value)>1800||preg_match('/[\x00-\x20\x7f]/',$value))throw new WorkshopException('组会来源地址无效。');
  $parts=parse_url($value);if(!$parts||isset($parts['scheme'])||isset($parts['host'])||isset($parts['fragment']))throw new WorkshopException('仅支持工坊内部组会页面作为来源。');
  $path=$parts['path']??'';$decoded=rawurldecode($path);
  if(!str_starts_with($path,'/apps/collectives/')||trim(substr($path,18),'/')===''||strpbrk($decoded,chr(92).chr(0).chr(10).chr(13))!==false||in_array('..',explode('/',$decoded),true)||str_contains($decoded,'%'))throw new WorkshopException('请选择具体的内部组会页面。');
  $query=$parts['query']??'';if($query!==''&&!preg_match('/^fileId=[1-9][0-9]{0,18}$/D',$query))throw new WorkshopException('组会来源不能包含分享凭证或其他参数。');
  return $path.($query!==''?'?'.$query:'');
 }
}
