<?php
namespace Leantime\Domain\Workshop;
use Illuminate\Database\ConnectionInterface;
use Illuminate\Support\Facades\{Http,Cache,RateLimiter};
/** Reuses native create-user, activation invitation and group APIs; no passwords or native admin credentials are stored here. */
final class AccountEnrollment
{
 public function __construct(private ConnectionInterface $db){}
 private function person(int $id):object
 {
  $p=$this->db->table('ws_people as w')->join('zp_user as u','u.id','=','w.user_id')->where('w.user_id',$id)->select('w.*','u.username as email','u.firstname as name','u.status as account_status')->first();
  if(!$p||$p->status!=='approved'||!$p->email_verified_at||strtolower((string)$p->account_status)!=='a')throw new WorkshopException('须先验证邮箱、审核身份并启用账号。',409);
  $ids=in_array($p->workshop_role,['teacher','manager'],true)?$this->db->table('ws_projects')->pluck('project_id')->all():$this->db->table('ws_memberships')->where('user_id',$id)->where('active',1)->pluck('project_id')->all();
  if(!$ids||$this->db->table('ws_native_project_groups')->whereIn('project_id',$ids)->count()!==count(array_unique($ids)))throw new WorkshopException('请先分配项目，并完成这些项目的聊天资料群组登记。',409);
  return $p;
 }
 private function client(string $cookie,string $token=''){return Http::baseUrl('http://workshop-collaboration')->asForm()->withHeaders(['Cookie'=>$cookie,'Accept'=>'application/json','OCS-APIRequest'=>'true','requesttoken'=>$token])->connectTimeout(3)->timeout(20)->withoutRedirecting();}
 private function authorization(array $actor,string $cookie,bool $requireMail):string
 {
  if(!($actor['owner']??false))throw new WorkshopException('只有账号维护管理员可以开通统一账号。',403);
  try{$r=$this->client($cookie)->get('/index.php/apps/workshop_shell/identity');$n=$r->json();$binding=$this->db->table('ws_identity_bindings')->where('user_id',$actor['id'])->first();if(!$r->successful()||!$binding||!is_array($n)||($n['account_administration']??false)!==true||!hash_equals($binding->native_uid,(string)($n['uid']??''))||mb_strtolower((string)($n['email']??''))!==mb_strtolower($actor['email']))throw new \RuntimeException();}catch(\Throwable){throw new WorkshopException('请使用已绑定的账号维护管理员统一登录。',403);}
  if($requireMail&&(config('workshop.test_mail',false)||($n['invitation_mail_ready']??false)!==true))throw new WorkshopException('尚未配置正式发信服务，不能创建可能收不到激活邀请的新账号。',409);
  try{$r=$this->client($cookie)->get('/csrftoken');$token=$r->json('token');if(!$r->successful()||!is_string($token)||$token==='')throw new \RuntimeException();return $token;}catch(\Throwable){throw new WorkshopException('无法取得原生操作凭证，请重新统一登录。',503);}
 }
 private function api(string $method,string $path,string $cookie,string $token,array $data=[]):array
 {
  try{$r=$this->client($cookie,$token)->send($method,'/ocs/v2.php/cloud'.$path.'?format=json',['form_params'=>$data]);$v=$r->json();if(!$r->successful()||!is_array($v)||($v['ocs']['meta']['status']??'')!=='ok')throw new \RuntimeException();return $v['ocs']['data']??[];}catch(\Throwable){throw new WorkshopException('原生服务未确认操作结果，请检查开通状态；系统不会盲目重复创建账号或发信。',503);}
 }
 private function audit(array $actor,int $user,string $action,array $data):void{$this->db->table('ws_audit')->insert(['actor_id'=>$actor['id'],'project_id'=>null,'action'=>$action,'entity'=>'person','entity_id'=>$user,'before_json'=>null,'after_json'=>json_encode($data,JSON_UNESCAPED_UNICODE),'created_at'=>gmdate('Y-m-d H:i:s')]);}
 public function open(array $actor,int $user,string $cookie,callable $guard):array
 {
  $guard();if(!($actor['owner']??false))throw new WorkshopException('只有账号维护管理员可以开通统一账号。',403);
  $lock=Cache::lock('workshop-account-enrollment:'.$user,180);if(!$lock->get())throw new WorkshopException('该成员的账号正在开通，请稍后核对。',429);
  try{
   $person=$this->person($user);$row=$this->db->table('ws_account_enrollments')->where('user_id',$user)->first();$binding=$this->db->table('ws_identity_bindings')->where('user_id',$user)->first();
   if($binding&&!$row)throw new WorkshopException('已有统一身份绑定，不能重新创建或按邮箱替换。',409);
   if($row&&in_array($row->status,['creating','creation_uncertain'],true))throw new WorkshopException('此前创建结果待人工核对，不会重复建号或按邮箱认领账号。',409);
   if($row&&($row->email!==$person->email||$row->name!==$person->name))throw new WorkshopException('成员核验信息已变化，请人工核对原开通记录。',409);
   $token=$this->authorization($actor,$cookie,!$row);
   if(!$row){
    $uid='ws_'.bin2hex(random_bytes(24));$now=gmdate('Y-m-d H:i:s');$guard();$this->db->table('ws_account_enrollments')->insert(['user_id'=>$user,'native_uid'=>$uid,'email'=>$person->email,'name'=>$person->name,'status'=>'creating','mail_status'=>'unconfirmed','auth_mode'=>'core','created_by'=>$actor['id'],'created_at'=>$now,'updated_at'=>$now]);
    try{$created=$this->api('POST','/users',$cookie,$token,['userid'=>$uid,'email'=>$person->email,'displayName'=>$person->name,'password'=>'','quota'=>'500 MB','language'=>'zh_CN']);if(($created['id']??null)!==$uid)throw new WorkshopException('账号创建回执与预留身份不符，需人工核对。',503);}catch(\Throwable $e){$this->db->table('ws_account_enrollments')->where('user_id',$user)->update(['status'=>'creation_uncertain','updated_at'=>gmdate('Y-m-d H:i:s')]);throw $e;}
    $this->db->table('ws_account_enrollments')->where('user_id',$user)->update(['status'=>'created','updated_at'=>gmdate('Y-m-d H:i:s')]);$this->audit($actor,$user,'collaboration.account_created',['mail_status'=>'unconfirmed']);$row=$this->db->table('ws_account_enrollments')->where('user_id',$user)->first();
   }
   $guard();$fresh=$this->person($user);if($fresh->email!==$row->email||$fresh->name!==$row->name)throw new WorkshopException('开通期间人员核验信息已变化，请人工核对。',409);
   $this->db->transaction(function()use($actor,$user,$row,$guard){$guard();$existing=$this->db->table('ws_identity_bindings')->where('user_id',$user)->lockForUpdate()->first();if($existing&&!hash_equals($existing->native_uid,$row->native_uid))throw new WorkshopException('已有不同身份绑定，不能覆盖。',409);$now=gmdate('Y-m-d H:i:s');$this->db->table('ws_identity_bindings')->insertOrIgnore(['user_id'=>$user,'native_uid'=>$row->native_uid,'bound_by'=>$actor['id'],'created_at'=>$now,'updated_at'=>$now]);$bound=$this->db->table('ws_identity_bindings')->where('user_id',$user)->first();if(!$bound||!hash_equals($bound->native_uid,$row->native_uid))throw new WorkshopException('固定身份绑定未确认。',409);$this->db->table('ws_account_enrollments')->where('user_id',$user)->update(['status'=>'awaiting_permissions','auth_mode'=>'native','updated_at'=>$now]);(new ProjectGroupSync($this->db))->queue($user);$this->audit($actor,$user,'collaboration.identity_bound',['authentication'=>'native_only']);});
   (new ProjectGroupSync($this->db))->synchronize($actor,$user,$cookie,$guard);
   $this->db->transaction(function()use($actor,$user,$row,$guard){$guard();$current=$this->person($user);$sync=$this->db->table('ws_native_access_sync')->where('user_id',$user)->lockForUpdate()->first();if(!$sync||$sync->status!=='verified'||$current->email!==$row->email||$current->name!==$row->name)throw new WorkshopException('开通期间人员或项目权限已变化，请继续核对后再完成。',409);$this->db->table('ws_account_enrollments')->where('user_id',$user)->update(['status'=>'ready','updated_at'=>gmdate('Y-m-d H:i:s')]);});
   return ['message'=>'统一账号已创建并完成登记项目群组核对。邀请是否送达尚未确认，请学员检查邮箱；需要时可明确重发邀请。开通后使用统一登录设置的密码。','status'=>'ready','mail_status'=>$row->mail_status,'user_id'=>$user];
  }finally{$lock->release();}
 }
 public function resend(array $actor,int $user,string $cookie,callable $guard):array
 {
  $guard();$person=$this->person($user);$row=$this->db->table('ws_account_enrollments')->where('user_id',$user)->first();$bound=$this->db->table('ws_identity_bindings')->where('user_id',$user)->first();if(!$row||!$bound||$row->status!=='ready'||!hash_equals($bound->native_uid,$row->native_uid)||$row->email!==$person->email)throw new WorkshopException('请先完成并核对统一账号开通。',409);
  $token=$this->authorization($actor,$cookie,true);$native=$this->api('GET','/users/'.rawurlencode($row->native_uid),$cookie,$token);if(mb_strtolower(trim((string)($native['email']??'')))!==mb_strtolower(trim($person->email)))throw new WorkshopException('消息与资料邮箱和工坊核验邮箱不一致，不能发送激活邀请，请先核对身份。',409);$key='workshop-invitation:'.$user;if(RateLimiter::tooManyAttempts($key,1))throw new WorkshopException('邀请操作间隔至少5分钟，请先检查邮箱。',429);RateLimiter::hit($key,300);$guard();
  $this->db->table('ws_account_enrollments')->where('user_id',$user)->update(['mail_status'=>'unconfirmed','updated_at'=>gmdate('Y-m-d H:i:s')]);
  $this->api('POST','/users/'.rawurlencode($row->native_uid).'/welcome',$cookie,$token);
  $this->db->table('ws_account_enrollments')->where('user_id',$user)->update(['mail_status'=>'accepted','updated_at'=>gmdate('Y-m-d H:i:s')]);$this->audit($actor,$user,'collaboration.invitation_accepted',['delivery_confirmed'=>false]);return ['message'=>'原生邮件服务已接受邀请重发；这不代表已经送达，请学员检查收件箱和垃圾邮件。','mail_status'=>'accepted'];
 }
}
