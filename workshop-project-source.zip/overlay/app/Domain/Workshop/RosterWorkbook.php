<?php
namespace Leantime\Domain\Workshop;

/** Bounded adapter to the pinned OpenSpout reader; existing Roster validates all business rows. */
final class RosterWorkbook
{
 public static function loadLibrary(): void
 {
  if(class_exists(\OpenSpout\Reader\XLSX\Reader::class))return;
  $loader=new \Composer\Autoload\ClassLoader();$loader->addPsr4('OpenSpout\\',__DIR__.'/ThirdParty/OpenSpout/src');$loader->register();
 }
 public function csv(string $path): string
 {
  if(!is_file($path)||filesize($path)>2097152)throw new WorkshopException('Excel 文件请控制在2MB以内。');
  $zip=new \ZipArchive();if($zip->open($path)!==true)throw new WorkshopException('无法读取 Excel 文件，请上传未加密的 .xlsx。');
  try{
   if($zip->numFiles>200||$zip->locateName('[Content_Types].xml')===false||$zip->locateName('xl/workbook.xml')===false)throw new WorkshopException('文件不是受支持的 Excel 工作簿。');
   $expanded=0;
   for($i=0;$i<$zip->numFiles;$i++){
    $entry=$zip->statIndex($i);$name=$entry['name'];$expanded+=$entry['size'];
    if($expanded>20971520||$entry['size']>8388608||str_contains($name,'..')||str_starts_with($name,'/')||str_contains($name,'\\'))throw new WorkshopException('Excel 内容过大或包含异常路径，请单独保存名单表后重试。');
    if(str_contains(strtolower($name),'vbaproject')||str_starts_with($name,'xl/externalLinks/'))throw new WorkshopException('名单不支持宏或外部链接，请另存为不含宏、公式和外部链接的 .xlsx。');
    if(preg_match('/\.(xml|rels)$/i',$name)){$xml=$zip->getFromIndex($i);if($xml===false||preg_match('/<!\s*(DOCTYPE|ENTITY)/i',$xml))throw new WorkshopException('Excel 内容格式异常，请重新另存为 .xlsx。');}
   }
  }finally{$zip->close();}
  self::loadLibrary();$options=new \OpenSpout\Reader\XLSX\Options();$options->SHOULD_PRESERVE_EMPTY_ROWS=true;
  $reader=new \OpenSpout\Reader\XLSX\Reader($options);$stream=fopen('php://temp','w+b');$sheets=0;$dataRows=0;$totalRows=0;$studentColumn=null;
  try{
   $reader->open($path);
   foreach($reader->getSheetIterator() as $sheet){
    $hasData=false;
    foreach($sheet->getRowIterator() as $row){
     if(++$totalRows>1200)throw new WorkshopException('每次最多1000条项目关系，请删除多余空行并分批导入。');
     $cells=$row->getCells();while($cells&&($cells[array_key_last($cells)]->getValue()===null||$cells[array_key_last($cells)]->getValue()===''))array_pop($cells);
     if(!$cells)continue;
     if(!$hasData){$hasData=true;if(++$sheets>1)throw new WorkshopException('请将本次名单单独保存为一个工作表，避免遗漏其他工作表。');}
     if(count($cells)!==4)throw new WorkshopException('名单每行需为学号、姓名、项目名称（或编号）、项目角色四列；请去除额外列。');
     $values=[];
     foreach($cells as $column=>$cell){
      if($cell instanceof \OpenSpout\Common\Entity\Cell\FormulaCell)throw new WorkshopException('名单含公式，请复制并粘贴为值后重试；系统不会执行公式。');
      $value=$cell->getValue();if(!is_string($value)&&!is_int($value)&&!is_float($value)&&$value!==null)throw new WorkshopException('名单含日期、错误值或其他非文本内容，请检查格式。');
      if($dataRows>0&&$column===$studentColumn&&!is_string($value))throw new WorkshopException('第'.$totalRows.'行学号不是文本。请将学号作为文本重新填写，避免前导零丢失；只改显示格式不能恢复已丢失的零。');
      if(is_string($value)&&strlen($value)>4096)throw new WorkshopException('单元格内容过长，请仅保留名单字段。');
      $values[]=(string)($value??'');
     }
     if($dataRows===0){foreach($values as $column=>$value)if(in_array(trim($value),['学号','student_no'],true))$studentColumn=$column;}
     if(++$dataRows>1001)throw new WorkshopException('每次最多导入1000条项目成员关系，请分批导入。');
     fputcsv($stream,$values,',','"','');
    }
   }
   rewind($stream);$csv=stream_get_contents($stream);if(!$csv||strlen($csv)>1048576)throw new WorkshopException('名单为空或转换后超过1MB，请分批导入。');return $csv;
  }catch(WorkshopException $e){throw $e;}catch(\Throwable){throw new WorkshopException('无法解析 Excel 文件，请上传未加密、格式完整的 .xlsx。');}
  finally{$reader->close();fclose($stream);}
 }
}
