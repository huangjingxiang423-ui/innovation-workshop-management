<?php

namespace Leantime\Domain\Oidc\Controllers;

use GuzzleHttp\Exception\GuzzleException;
use Illuminate\Http\Exceptions\HttpResponseException;
use Leantime\Core\Controller\Controller;
use Leantime\Core\Controller\Frontcontroller;
use Leantime\Domain\Oidc\Services\Oidc as OidcService;
use Symfony\Component\HttpFoundation\Response;

class Callback extends Controller
{
    private OidcService $oidc;

    public function init(OidcService $oidc): void
    {
        $this->oidc = $oidc;
    }

    /**
     * @throws GuzzleException|HttpResponseException
     */
    public function get($params): Response
    {
        $code = $_GET['code'] ?? null;
        $state = $_GET['state'] ?? null;
        $error = $_GET['error'] ?? null;
        // An OAuth denial has no code. Validate its state, then return a normal
        // login notice instead of raising an undefined-key error before the try block.
        if (is_string($error) && $error !== '') {
            $stored = (string) session('oidc.state');
            $valid = is_string($state) && $stored !== '' && hash_equals($stored, $state);
            if ($valid) {
                session()->forget(['oidc.state', 'oidc.nonce', 'oidc.mobile', 'oidc.mobileRedirect', 'oidc.mobileChallenge']);
            }
            $message = !$valid ? '登录请求已失效，请重新发起统一登录。'
                : ($error === 'access_denied' ? '已取消本次统一登录，未授权进入工坊。你可以重新登录。' : '统一登录未完成，请稍后重新发起。');
            $this->tpl->setNotification($message, 'info', 'oidc_error');
            return Frontcontroller::redirect(BASE_URL.'/auth/login');
        }
        if (!is_string($code) || $code === '' || !is_string($state) || $state === '') {
            $this->tpl->setNotification('登录请求不完整，请重新发起统一登录。', 'info', 'oidc_error');
            return Frontcontroller::redirect(BASE_URL.'/auth/login');
        }

        try {
            return $this->oidc->callback($code, $state);
        } catch (\Exception $e) {
            $this->tpl->setNotification($e->getMessage(), 'danger', 'oidc_error');

            return Frontcontroller::redirect(BASE_URL.'/auth/login');
        }
    }
}
