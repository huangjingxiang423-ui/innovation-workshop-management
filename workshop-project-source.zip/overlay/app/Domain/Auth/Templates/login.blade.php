@extends($layout)
@section('content')

@if (config('workshop.enabled', false))
<link rel="stylesheet" href="{{ BASE_URL }}/workshop-assets/auth.css?v=20261023product1">
@endif
@dispatchEvent('beforePageHeaderOpen')
<div class="pageheader">
    @dispatchEvent('afterPageHeaderOpen')
    <div class="pagetitle">
        <h1>{{ config('workshop.enabled', false) ? '创新工坊登录' : __('headlines.login') }}</h1>
    </div>
    @dispatchEvent('beforePageHeaderClose')
</div>
@dispatchEvent('afterPageHeaderClose')

<div class="regcontent">
    @dispatchEvent('afterRegcontentOpen')
    {!! $tpl->displayInlineNotification() !!}

    @if (config('workshop.enabled', false) && $oidcEnabled)
        <p>已开通消息与资料的账号可使用统一登录；通过注册审核的学员也可使用下方邮箱密码登录。</p>
        <x-global::forms.button tag="a" :link="BASE_URL . '/oidc/login'" contentRole="primary" style="width:100%;">使用工坊账号登录</x-global::forms.button>
        <p style="margin-top:16px;"><a href="{{ BASE_URL }}/workshop/register">首次使用？申请加入工坊</a></p><details style="margin-top:24px;"><summary>邮箱密码登录（学员 / 管理员）</summary><p>使用注册时填写的本人邮箱和密码。账号须完成邮箱验证与身份审核；消息和资料还需完成统一账号开通。</p>
    @endif

    @if ($noLoginForm === false)
        <form id="login" action="{{ BASE_URL }}/auth/login" method="post">
            @csrf
            @dispatchEvent('afterFormOpen')
        <input type="hidden" name="redirectUrl" value="{{ $redirectUrl }}" />

        <div class="">
            <label for="username">{{ __('label.email') }}</label>
            <x-global::forms.text-input name="username" id="username" placeholder="{{ __($inputPlaceholder) }}" value="" />
        </div>
        <div class="">
            <label for="password">{{ __('label.password') }}</label>
            <x-global::forms.text-input type="password" name="password" id="password" autocomplete="off" placeholder="{{ __('input.placeholders.enter_password') }}" value="" />
            <div class="forgotPwContainer">
                <a href="{{ BASE_URL }}/auth/resetPw" class="forgotPw">{!! __('links.forgot_password') !!}</a>
            </div>
        </div>
            @dispatchEvent('beforeSubmitButton')
        <div class="">
            <x-global::forms.button tag="input" inputType="submit" name="login" contentRole="primary" :labelText="__('buttons.login')" />
        </div>
        <div>
        </div>
            @dispatchEvent('beforeFormClose')

    </form>
    @else
        {!! __('text.no_login_form') !!}<br /><br />
    @endif

    @if (config('workshop.enabled', false) && $oidcEnabled)
        </details>
    @endif

    @if ($oidcEnabled && !config('workshop.enabled', false))

        @dispatchEvent('beforeOidcButton')

        <div class="">
            @if ($noLoginForm === false)
                <div style="margin-top:20px; border-bottom:1px solid #ccc; with:100%; height:10px; overflow:show; text-align:center; margin-bottom:40px;">
                    <p style="text-align:center; display:inline-block; background:var(--secondary-background); padding:0px 5px;">{!! __('label.or_login_with') !!}</p>
                </div>
            @endif
            <x-global::forms.button tag="a" :link="BASE_URL . '/oidc/login'" contentRole="primary" style="width:100%;">{!! __('buttons.oidclogin') !!}</x-global::forms.button>
        </div>
    @endif

    @dispatchEvent('beforeRegcontentClose')
</div>

@endsection
